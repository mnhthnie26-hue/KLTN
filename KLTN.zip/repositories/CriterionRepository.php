<?php
/**
 * CriterionRepository
 */

declare(strict_types=1);

class CriterionRepository extends BaseRepository
{
    protected string $table = 'criteria';

    public function getByKpi(int $kpiId): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT c.*, cc.name AS category_name
             FROM criteria c
             LEFT JOIN criterion_categories cc ON c.category_id = cc.id
             WHERE c.kpi_id = ? AND c.deleted_at IS NULL
             ORDER BY c.sort_order, c.id',
            [$kpiId]
        );
    }

    public function getTotalWeight(int $kpiId): float
    {
        $result = Database::getInstance()->fetchValue(
            'SELECT COALESCE(SUM(weight), 0) FROM criteria WHERE kpi_id = ? AND deleted_at IS NULL',
            [$kpiId]
        );
        return (float)$result;
    }

    public function softDelete(int $id): int
    {
        return $this->update($id, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'status' => 0,
        ]);
    }

    public function getStats(): array
    {
        $db = Database::getInstance();
        return [
            'total'  => (int)$db->fetchValue('SELECT COUNT(*) FROM criteria WHERE deleted_at IS NULL'),
            'active' => (int)$db->fetchValue('SELECT COUNT(*) FROM criteria WHERE deleted_at IS NULL AND status = 1'),
        ];
    }
}