<?php
/**
 * KpiRepository
 */

declare(strict_types=1);

class KpiRepository extends BaseRepository
{
    protected string $table = 'kpis';

    public function getWithGroup(int $kpiId): ?array
    {
        return Database::getInstance()->fetchOne(
            'SELECT k.*, kg.name AS group_name, kg.code AS group_code
             FROM kpis k
             INNER JOIN kpi_groups kg ON k.kpi_group_id = kg.id
             WHERE k.id = ?',
            [$kpiId]
        );
    }

    public function getAllWithGroup(): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT k.*, kg.name AS group_name, kg.code AS group_code,
                    (SELECT COUNT(*) FROM criteria c WHERE c.kpi_id = k.id AND c.deleted_at IS NULL) AS criteria_count
             FROM kpis k
             INNER JOIN kpi_groups kg ON k.kpi_group_id = kg.id
             WHERE k.deleted_at IS NULL
             ORDER BY kg.sort_order, k.sort_order, k.id'
        );
    }

    public function getByGroup(int $groupId): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT * FROM kpis WHERE kpi_group_id = ? AND deleted_at IS NULL ORDER BY sort_order, id',
            [$groupId]
        );
    }

    public function softDelete(int $id): int
    {
        return $this->update($id, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'status' => 0,
        ]);
    }

    public function getStats(): array
    {
        $db = Database::getInstance();
        return [
            'total'    => (int)$db->fetchValue('SELECT COUNT(*) FROM kpis WHERE deleted_at IS NULL'),
            'active'   => (int)$db->fetchValue('SELECT COUNT(*) FROM kpis WHERE deleted_at IS NULL AND status = 1'),
            'groups'   => (int)$db->fetchValue('SELECT COUNT(*) FROM kpi_groups WHERE deleted_at IS NULL'),
        ];
    }
}