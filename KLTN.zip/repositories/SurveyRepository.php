<?php
/**
 * SurveyRepository
 */

declare(strict_types=1);

class SurveyRepository extends BaseRepository
{
    protected string $table = 'surveys';

    public function getWithKpi(int $id): ?array
    {
        return Database::getInstance()->fetchOne(
            'SELECT s.*, k.name AS kpi_name, k.code AS kpi_code, u.full_name AS creator_name
             FROM surveys s
             LEFT JOIN kpis k ON s.kpi_id = k.id
             INNER JOIN users u ON s.created_by = u.id
             WHERE s.id = ?',
            [$id]
        );
    }

    public function getList(int $page, int $perPage, array $filters): array
    {
        $db = Database::getInstance();
        $where = ['s.deleted_at IS NULL'];
        $params = [];

        if (!empty($filters['search'])) {
            $where[] = '(s.code LIKE ? OR s.title LIKE ?)';
            $term = '%' . $filters['search'] . '%';
            $params[] = $term;
            $params[] = $term;
        }
        if (!empty($filters['status'])) {
            $where[] = 's.status = ?';
            $params[] = $filters['status'];
        }
        if (!empty($filters['kpi_id'])) {
            $where[] = 's.kpi_id = ?';
            $params[] = (int)$filters['kpi_id'];
        }

        $whereSql = implode(' AND ', $where);
        $total = (int)$db->fetchValue("SELECT COUNT(*) FROM surveys s WHERE {$whereSql}", $params);
        $offset = ($page - 1) * $perPage;

        $items = $db->fetchAll(
            "SELECT s.*, k.name AS kpi_name, u.full_name AS creator_name,
                    (SELECT COUNT(*) FROM survey_questions WHERE survey_id = s.id) AS question_count,
                    (SELECT COUNT(*) FROM survey_responses WHERE survey_id = s.id AND status = 'submitted') AS response_count
             FROM surveys s
             LEFT JOIN kpis k ON s.kpi_id = k.id
             INNER JOIN users u ON s.created_by = u.id
             WHERE {$whereSql}
             ORDER BY s.created_at DESC
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return [
            'items' => $items,
            'total' => $total,
            'pagination' => paginate($total, $page, $perPage),
        ];
    }

    public function getQuestions(int $surveyId): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY sort_order, id',
            [$surveyId]
        );
    }

    public function getQuestionOptions(int $questionId): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT * FROM survey_options WHERE question_id = ? ORDER BY sort_order, id',
            [$questionId]
        );
    }

    public function getQuestionsWithOptions(int $surveyId): array
    {
        $questions = $this->getQuestions($surveyId);
        foreach ($questions as &$q) {
            $q['options'] = $this->getQuestionOptions((int)$q['id']);
        }
        return $questions;
    }

    public function softDelete(int $id): int
    {
        return $this->update($id, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'status' => 'archived',
        ]);
    }

    public function publish(int $id): void
    {
        $this->update($id, [
            'status' => 'published',
            'published_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function close(int $id): void
    {
        $this->update($id, [
            'status' => 'closed',
            'closed_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function getStats(): array
    {
        $db = Database::getInstance();
        return [
            'total'     => (int)$db->fetchValue('SELECT COUNT(*) FROM surveys WHERE deleted_at IS NULL'),
            'draft'     => (int)$db->fetchValue("SELECT COUNT(*) FROM surveys WHERE deleted_at IS NULL AND status = 'draft'"),
            'published' => (int)$db->fetchValue("SELECT COUNT(*) FROM surveys WHERE deleted_at IS NULL AND status = 'published'"),
            'closed'    => (int)$db->fetchValue("SELECT COUNT(*) FROM surveys WHERE deleted_at IS NULL AND status = 'closed'"),
            'responses' => (int)$db->fetchValue("SELECT COUNT(*) FROM survey_responses WHERE status = 'submitted'"),
        ];
    }
}