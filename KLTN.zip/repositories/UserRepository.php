<?php
/**
 * UserRepository
 */

declare(strict_types=1);

class UserRepository extends BaseRepository
{
    protected string $table = 'users';

    /**
     * Get users with pagination, search, filter
     */
    public function getUsers(int $page = 1, int $perPage = 20, array $filters = []): array
    {
        $offset = ($page - 1) * $perPage;
        $where = ['u.deleted_at IS NULL'];
        $params = [];

        if (!empty($filters['search'])) {
            $where[] = '(u.username LIKE ? OR u.email LIKE ? OR u.full_name LIKE ? OR u.phone LIKE ?)';
            $term = '%' . $filters['search'] . '%';
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
            $params[] = $term;
        }

        if (!empty($filters['user_type'])) {
            $where[] = 'u.user_type = ?';
            $params[] = $filters['user_type'];
        }

        if (isset($filters['status']) && $filters['status'] !== '') {
            $where[] = 'u.status = ?';
            $params[] = (int)$filters['status'];
        }

        if (!empty($filters['faculty_id'])) {
            $where[] = 'u.faculty_id = ?';
            $params[] = (int)$filters['faculty_id'];
        }

        if (!empty($filters['department_id'])) {
            $where[] = 'u.department_id = ?';
            $params[] = (int)$filters['department_id'];
        }

        $whereSql = implode(' AND ', $where);

        $countSql = "SELECT COUNT(*) FROM users u WHERE {$whereSql}";
        $total = (int)Database::getInstance()->fetchValue($countSql, $params);

        $sql = "SELECT u.id, u.username, u.email, u.full_name, u.phone, u.user_type, u.status,
                       u.faculty_id, u.department_id, u.student_code, u.lecturer_code, u.class_name,
                       u.position, u.last_login_at, u.created_at,
                       f.name AS faculty_name, d.name AS department_name
                FROM users u
                LEFT JOIN faculties f ON u.faculty_id = f.id
                LEFT JOIN departments d ON u.department_id = d.id
                WHERE {$whereSql}
                ORDER BY u.created_at DESC
                LIMIT {$perPage} OFFSET {$offset}";

        $items = Database::getInstance()->fetchAll($sql, $params);

        return [
            'items' => $items,
            'total' => $total,
            'pagination' => paginate($total, $page, $perPage),
        ];
    }

    public function getByUsername(string $username): ?array
    {
        return $this->findBy('username', $username);
    }

    public function getByEmail(string $email): ?array
    {
        return $this->findBy('email', $email);
    }

    public function getWithRoles(int $id): ?array
    {
        $user = $this->find($id);
        if (!$user) return null;

        $user['roles'] = Database::getInstance()->fetchAll(
            'SELECT r.* FROM roles r
             INNER JOIN user_roles ur ON r.id = ur.role_id
             WHERE ur.user_id = ?',
            [$id]
        );

        $user['role_ids'] = array_column($user['roles'], 'id');
        return $user;
    }

    public function createUser(array $data, array $roleIds = []): int
    {
        return Database::getInstance()->transaction(function() use ($data, $roleIds) {
            $userId = $this->create($data);

            foreach ($roleIds as $roleId) {
                Database::getInstance()->insert('user_roles', [
                    'user_id' => $userId,
                    'role_id' => (int)$roleId,
                ]);
            }

            return $userId;
        });
    }

    public function updateUser(int $id, array $data, ?array $roleIds = null): int
    {
        return Database::getInstance()->transaction(function() use ($id, $data, $roleIds) {
            $result = $this->update($id, $data);

            if ($roleIds !== null) {
                Database::getInstance()->delete('user_roles', 'user_id = :uid', ['uid' => $id]);
                foreach ($roleIds as $roleId) {
                    Database::getInstance()->insert('user_roles', [
                        'user_id' => $id,
                        'role_id' => (int)$roleId,
                    ]);
                }
            }

            return $result;
        });
    }

    public function softDelete(int $id): int
    {
        return $this->update($id, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'status' => 0,
        ]);
    }

    public function lock(int $id, int $duration = 86400): void
    {
        $this->update($id, [
            'status' => 0,
            'locked_until' => date('Y-m-d H:i:s', time() + $duration),
        ]);
    }

    public function unlock(int $id): void
    {
        $this->update($id, [
            'status' => 1,
            'locked_until' => null,
            'failed_login_count' => 0,
        ]);
    }

    public function updatePassword(int $id, string $newPassword): void
    {
        $this->update($id, [
            'password' => password_hash($newPassword, PASSWORD_BCRYPT),
            'must_change_password' => 0,
        ]);
    }

    public function getStats(): array
    {
        $db = Database::getInstance();
        return [
            'total'      => (int)$db->fetchValue('SELECT COUNT(*) FROM users WHERE deleted_at IS NULL'),
            'admin'      => (int)$db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND user_type = 'admin'"),
            'manager'    => (int)$db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND user_type = 'manager'"),
            'lecturer'   => (int)$db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND user_type = 'lecturer'"),
            'student'    => (int)$db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND user_type = 'student'"),
            'active'     => (int)$db->fetchValue('SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND status = 1'),
            'locked'     => (int)$db->fetchValue('SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND status = 0'),
        ];
    }
}