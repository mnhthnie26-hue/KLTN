<?php
/**
 * BaseRepository - Common CRUD operations
 */

declare(strict_types=1);

abstract class BaseRepository
{
    protected Database $db;
    protected string $table;
    protected string $primaryKey = 'id';

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function find(int $id): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM `{$this->table}` WHERE `{$this->primaryKey}` = ? LIMIT 1",
            [$id]
        );
    }

    public function findBy(string $field, $value): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM `{$this->table}` WHERE `{$field}` = ? LIMIT 1",
            [$value]
        );
    }

    public function findAll(array $conditions = [], string $orderBy = null, int $limit = 0, int $offset = 0): array
    {
        $sql = "SELECT * FROM `{$this->table}`";
        $params = [];

        if (!empty($conditions)) {
            $where = [];
            foreach ($conditions as $col => $val) {
                // Support 'col LIKE' as a special key for substring search.
                if (is_string($col) && str_ends_with($col, ' LIKE')) {
                    $realCol = trim(substr($col, 0, -5));
                    $where[] = "`{$realCol}` LIKE ?";
                } else {
                    $where[] = "`{$col}` = ?";
                }
                $params[] = $val;
            }
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }

        if ($orderBy) {
            $sql .= " ORDER BY {$orderBy}";
        }

        if ($limit > 0) {
            $sql .= " LIMIT {$limit} OFFSET {$offset}";
        }

        return $this->db->fetchAll($sql, $params);
    }

    public function create(array $data): int
    {
        return $this->db->insert($this->table, $data);
    }

    public function update(int $id, array $data): int
    {
        return $this->db->update($this->table, $data, "{$this->primaryKey} = :id", ['id' => $id]);
    }

    public function delete(int $id): int
    {
        return $this->db->delete($this->table, "{$this->primaryKey} = :id", ['id' => $id]);
    }

    public function count(array $conditions = []): int
    {
        $sql = "SELECT COUNT(*) FROM `{$this->table}`";
        $params = [];

        if (!empty($conditions)) {
            $where = [];
            foreach ($conditions as $col => $val) {
                if (is_string($col) && str_ends_with($col, ' LIKE')) {
                    $realCol = trim(substr($col, 0, -5));
                    $where[] = "`{$realCol}` LIKE ?";
                } else {
                    $where[] = "`{$col}` = ?";
                }
                $params[] = $val;
            }
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }

        return (int)$this->db->fetchValue($sql, $params);
    }

    public function paginate(int $page = 1, int $perPage = 20, array $conditions = [], string $orderBy = null): array
    {
        $offset = ($page - 1) * $perPage;
        $total = $this->count($conditions);

        $items = $this->findAll($conditions, $orderBy, $perPage, $offset);

        return [
            'items' => $items,
            'total' => $total,
            'pagination' => paginate($total, $page, $perPage),
        ];
    }
}