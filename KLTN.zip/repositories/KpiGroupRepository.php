<?php
/**
 * KpiGroupRepository
 */

declare(strict_types=1);

class KpiGroupRepository extends BaseRepository
{
    protected string $table = 'kpi_groups';

    public function getAllActive(): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT * FROM kpi_groups WHERE deleted_at IS NULL AND status = 1 ORDER BY sort_order, id'
        );
    }

    public function getWithKpiCount(int $id): ?array
    {
        $group = $this->find($id);
        if (!$group) return null;
        $group['kpi_count'] = (int)Database::getInstance()->fetchValue(
            'SELECT COUNT(*) FROM kpis WHERE kpi_group_id = ? AND deleted_at IS NULL',
            [$id]
        );
        return $group;
    }

    public function softDelete(int $id): int
    {
        return $this->update($id, [
            'deleted_at' => date('Y-m-d H:i:s'),
            'status' => 0,
        ]);
    }
}