<?php
/**
 * RoleRepository
 */

declare(strict_types=1);

class RoleRepository extends BaseRepository
{
    protected string $table = 'roles';

    public function getWithPermissions(int $roleId): ?array
    {
        $role = $this->find($roleId);
        if (!$role) return null;

        $perms = $this->db->fetchAll(
            'SELECT p.* FROM permissions p
             INNER JOIN role_permissions rp ON p.id = rp.permission_id
             WHERE rp.role_id = ?',
            [$roleId]
        );

        $role['permissions'] = $perms;
        $role['permission_ids'] = array_column($perms, 'id');
        return $role;
    }

    public function getUserRoles(int $userId): array
    {
        return $this->db->fetchAll(
            'SELECT r.* FROM roles r
             INNER JOIN user_roles ur ON r.id = ur.role_id
             WHERE ur.user_id = ? AND r.status = 1',
            [$userId]
        );
    }

    public function assignToUser(int $userId, int $roleId): void
    {
        try {
            $this->db->insert('user_roles', [
                'user_id' => $userId,
                'role_id' => $roleId,
            ]);
        } catch (Throwable $e) {
            // Duplicate (1062) is expected when re-granting a role. Anything else is a real bug.
            if ((int)$e->getCode() !== 1062) {
                ErrorLog::error('[RoleRepository::assignToUser] insert failed', [
                    'uid' => $userId, 'rid' => $roleId,
                ], $e);
            }
        }
    }

    public function removeFromUser(int $userId, int $roleId): void
    {
        $this->db->delete('user_roles', 'user_id = :uid AND role_id = :rid', [
            'uid' => $userId,
            'rid' => $roleId,
        ]);
    }

    public function syncUserRoles(int $userId, array $roleIds): void
    {
        $this->db->beginTransaction();
        try {
            $this->db->delete('user_roles', 'user_id = :uid', ['uid' => $userId]);
            foreach ($roleIds as $roleId) {
                $this->db->insert('user_roles', [
                    'user_id' => $userId,
                    'role_id' => (int)$roleId,
                ]);
            }
            $this->db->commit();
        } catch (Exception $e) {
            $this->db->rollback();
            throw $e;
        }
    }
}