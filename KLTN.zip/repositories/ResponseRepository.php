<?php
/**
 * ResponseRepository
 */

declare(strict_types=1);

class ResponseRepository extends BaseRepository
{
    protected string $table = 'survey_responses';

    public function getBySurvey(int $surveyId, int $page = 1, int $perPage = 20, array $filters = []): array
    {
        $where = ['r.survey_id = ?'];
        $params = [$surveyId];

        if (!empty($filters['status'])) {
            $where[] = 'r.status = ?';
            $params[] = $filters['status'];
        }

        $whereSql = implode(' AND ', $where);
        $total = (int)Database::getInstance()->fetchValue("SELECT COUNT(*) FROM survey_responses r WHERE {$whereSql}", $params);
        $offset = ($page - 1) * $perPage;

        $items = Database::getInstance()->fetchAll(
            "SELECT r.*, u.full_name AS respondent_name, u.username AS respondent_username
             FROM survey_responses r
             LEFT JOIN users u ON r.respondent_id = u.id
             WHERE {$whereSql}
             ORDER BY r.submitted_at DESC
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return [
            'items' => $items,
            'total' => $total,
            'pagination' => paginate($total, $page, $perPage),
        ];
    }

    public function getAnswers(int $responseId): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT sa.*, sq.question_text, sq.question_type, sq.criterion_id
             FROM survey_answers sa
             INNER JOIN survey_questions sq ON sa.question_id = sq.id
             WHERE sa.response_id = ?
             ORDER BY sq.sort_order, sq.id',
            [$responseId]
        );
    }

    public function hasResponded(int $surveyId, int $userId): bool
    {
        $count = (int)Database::getInstance()->fetchValue(
            "SELECT COUNT(*) FROM survey_responses WHERE survey_id = ? AND respondent_id = ? AND status = 'submitted'",
            [$surveyId, $userId]
        );
        return $count > 0;
    }

    public function getCompletedCount(int $surveyId): int
    {
        return (int)Database::getInstance()->fetchValue(
            "SELECT COUNT(*) FROM survey_responses WHERE survey_id = ? AND status = 'submitted'",
            [$surveyId]
        );
    }
}