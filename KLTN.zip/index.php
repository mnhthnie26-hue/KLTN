<?php
/**
 * Application Entry Point
 */
declare(strict_types=1);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


// Define ROOT_PATH immediately so autoloader can use it
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', __DIR__);
}

// Load config FIRST (defines constants and error handling)
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/constants.php';
require_once __DIR__ . '/core/bootstrap.php';

// Composer-style class autoloader (if used)
if (file_exists(__DIR__ . '/vendor/autoload.php')) {
    require_once __DIR__ . '/vendor/autoload.php';
}

// Autoload classes (uses ROOT_PATH from config)
spl_autoload_register(function (string $class): void {
    // PSR-4 style: namespace -> folder mapping
    // Api\AuthController  -> api/v1/AuthController.php
    // Core\Request        -> core/Request.php
    // Controller\User     -> controllers/User.php
    $namespaceMap = [
        'Api\\'        => ROOT_PATH . '/api/v1/',
        'Core\\'       => ROOT_PATH . '/core/',
        'Middleware\\' => ROOT_PATH . '/middleware/',
        'Service\\'    => ROOT_PATH . '/services/',
        'Repository\\' => ROOT_PATH . '/repositories/',
    ];

    foreach ($namespaceMap as $prefix => $baseDir) {
        if (str_starts_with($class, $prefix)) {
            $relative = substr($class, strlen($prefix));
            $file = $baseDir . str_replace('\\', '/', $relative) . '.php';
            if (file_exists($file)) {
                require_once $file;
                return;
            }
        }
    }

    // Fallback: search non-namespaced class names in core/controllers/services/repositories/middleware
    $directories = [
        ROOT_PATH . '/core/',
        ROOT_PATH . '/controllers/',
        ROOT_PATH . '/services/',
        ROOT_PATH . '/repositories/',
        ROOT_PATH . '/middleware/',
    ];

    foreach ($directories as $dir) {
        $file = $dir . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

// Initialize core
require_once __DIR__ . '/core/Database.php';
require_once __DIR__ . '/core/Request.php';
require_once __DIR__ . '/core/Response.php';
require_once __DIR__ . '/core/Router.php';
require_once __DIR__ . '/core/View.php';
require_once __DIR__ . '/core/Security.php';
require_once __DIR__ . '/core/CSRF.php';
require_once __DIR__ . '/core/Session.php';
require_once __DIR__ . '/core/Validator.php';
require_once __DIR__ . '/core/Logger.php';
require_once __DIR__ . '/core/Auth.php';
require_once __DIR__ . '/core/Permission.php';
require_once __DIR__ . '/core/TokenManager.php';
require_once __DIR__ . '/core/helpers.php';

// Ensure storage directories exist with proper permissions
$storageDirs = [
    __DIR__ . '/storage/logs',
    __DIR__ . '/storage/exports',
    __DIR__ . '/storage/cache',
    __DIR__ . '/storage/uploads',
];
foreach ($storageDirs as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}

// Define APP_SECRET if not set
if (!defined('APP_SECRET')) {
    define('APP_SECRET', getenv('APP_SECRET') ?: 'CHANGE-THIS-SECRET-IN-PRODUCTION-' . md5(__DIR__));
}

// Define BASE_PATH from SCRIPT_NAME so the router supports both the domain root and subfolders.
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
$basePath = rtrim(str_replace('/index.php', '', dirname($scriptName)), '/');
if (!defined('BASE_PATH')) {
    define('BASE_PATH', $basePath);
}

// Load web routes
$request = new Request();
$response = new Response();
$router = new Router();
require_once __DIR__ . '/routes/web.php';

// Dispatch
try {
    $router->dispatch($request, $response);
} catch (Throwable $e) {
    ErrorLog::critical('[web-dispatch] uncaught', [], $e);

    if (APP_DEBUG) {
        echo '<pre>' . htmlspecialchars($e->getMessage() . "\n\n" . $e->getTraceAsString()) . '</pre>';
    } else {
        if (str_starts_with($request->path(), '/api/')) {
            $response->error('Internal server error', ['message' => $e->getMessage()], 500)->send();
        } else {
            http_response_code(500);
            if (file_exists(__DIR__ . '/views/errors/500.php')) {
                // Include the 500 page directly (no layout) so it works even if DB/helpers fail.
                // The 500.php file is self-contained HTML.
                $__error_data = ['error' => $e->getMessage()];
                include __DIR__ . '/views/errors/500.php';
            } else {
                echo '<h1>500 - Server Error</h1>';
                if (APP_DEBUG) {
                    echo '<pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
                }
            }
        }
    }
}
