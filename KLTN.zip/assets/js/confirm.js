/**
 * Confirm - hộp thoại xác nhận (thay thế confirm()/alert() mặc định của trình duyệt)
 *
 * JS:    Confirm.ask({ title, message, confirmText, cancelText, type }).then(function (ok) { ... });
 *        type: 'danger' (mặc định) | 'warning' | 'info' | 'success'
 * HTML:  <form data-confirm="Xóa KPI này?" data-confirm-title="Xóa KPI" data-confirm-text="Xóa" data-confirm-type="danger">
 *        <button data-confirm="...">  (nút submit hoặc nút thường)
 *        <a href="..." data-confirm="...">  (liên kết, ví dụ Đăng xuất)
 *        <button type="button" data-confirm="..." data-confirm-remove=".question-block">  (xóa phần tử DOM)
 */
(function () {
    'use strict';

    var ICONS = {
        danger:  '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4a1 1 0 0 1 1-1h6a1 1 0 0 1 1 1v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/></svg>',
        warning: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/></svg>',
        info:    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></svg>',
        success: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M8 12.5l3 3 5-6"/></svg>'
    };
    var DEFAULT_TITLE = { danger: 'Xác nhận xóa', warning: 'Xác nhận thao tác', info: 'Xác nhận', success: 'Xác nhận' };
    var DEFAULT_OK = { danger: 'Xóa', warning: 'Đồng ý', info: 'Đồng ý', success: 'Đồng ý' };

    var open = null; // { close }

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function ask(opts) {
        if (typeof opts === 'string') opts = { message: opts };
        opts = opts || {};
        var type = ICONS[opts.type] ? opts.type : 'danger';
        if (open) open.close(false);

        return new Promise(function (resolve) {
            var prevFocus = document.activeElement;
            var overlay = document.createElement('div');
            overlay.className = 'cf-overlay';
            overlay.innerHTML =
                '<div class="cf-dialog cf-' + type + '" role="alertdialog" aria-modal="true" aria-labelledby="cf-title" aria-describedby="cf-msg">' +
                    '<div class="cf-icon">' + ICONS[type] + '</div>' +
                    '<h3 class="cf-title" id="cf-title">' + esc(opts.title || DEFAULT_TITLE[type]) + '</h3>' +
                    '<p class="cf-message" id="cf-msg">' + esc(opts.message || 'Bạn có chắc chắn muốn thực hiện thao tác này?') + '</p>' +
                    (opts.detail ? '<p class="cf-detail">' + esc(opts.detail) + '</p>' : '') +
                    '<div class="cf-actions">' +
                        '<button type="button" class="cf-btn cf-btn-cancel">' + esc(opts.cancelText || 'Hủy') + '</button>' +
                        '<button type="button" class="cf-btn cf-btn-ok">' + esc(opts.confirmText || DEFAULT_OK[type]) + '</button>' +
                    '</div>' +
                '</div>';
            document.body.appendChild(overlay);
            document.documentElement.classList.add('cf-lock');

            var dialog = overlay.querySelector('.cf-dialog');
            var okBtn = overlay.querySelector('.cf-btn-ok');
            var cancelBtn = overlay.querySelector('.cf-btn-cancel');
            var done = false;

            function close(result) {
                if (done) return;
                done = true;
                open = null;
                document.removeEventListener('keydown', onKey, true);
                overlay.classList.add('cf-leave');
                setTimeout(function () {
                    overlay.remove();
                    if (!document.querySelector('.cf-overlay')) document.documentElement.classList.remove('cf-lock');
                    if (prevFocus && prevFocus.focus && document.body.contains(prevFocus)) prevFocus.focus();
                }, 150);
                resolve(!!result);
            }
            function onKey(e) {
                if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(false); }
                else if (e.key === 'Tab') { // giữ focus trong hộp thoại
                    e.preventDefault();
                    (document.activeElement === okBtn ? cancelBtn : okBtn).focus();
                }
            }
            open = { close: close };
            document.addEventListener('keydown', onKey, true);
            okBtn.addEventListener('click', function () { close(true); });
            cancelBtn.addEventListener('click', function () { close(false); });
            overlay.addEventListener('mousedown', function (e) { if (e.target === overlay) close(false); });
            // Mặc định focus vào "Hủy" với thao tác nguy hiểm để tránh bấm nhầm
            (type === 'danger' ? cancelBtn : okBtn).focus();
            dialog.addEventListener('animationend', function () {}, { once: true });
        });
    }

    window.Confirm = { ask: ask };

    function optsFrom(el) {
        return {
            message: el.getAttribute('data-confirm'),
            title: el.getAttribute('data-confirm-title') || undefined,
            confirmText: el.getAttribute('data-confirm-text') || undefined,
            cancelText: el.getAttribute('data-confirm-cancel') || undefined,
            type: el.getAttribute('data-confirm-type') || guessType(el),
            detail: el.getAttribute('data-confirm-detail') || undefined
        };
    }
    function guessType(el) {
        if (el.classList.contains('btn-danger') || /xóa|xoá/i.test(el.getAttribute('data-confirm') || '')) return 'danger';
        if (el.classList.contains('btn-success')) return 'success';
        return 'warning';
    }

    var approved = new WeakSet();

    // Gửi form: form[data-confirm] hoặc nút submit[data-confirm]
    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (approved.has(form)) { approved.delete(form); return; }
        var sub = e.submitter;
        var src = sub && sub.hasAttribute('data-confirm') ? sub : (form.hasAttribute('data-confirm') ? form : null);
        if (!src) return;
        e.preventDefault();
        ask(optsFrom(src)).then(function (ok) {
            if (!ok) return;
            approved.add(form);
            if (form.requestSubmit) { try { form.requestSubmit(sub || undefined); return; } catch (err) {} }
            form.submit();
        });
    }, true);

    // Nút thường / liên kết có data-confirm (không nằm trong form data-confirm)
    document.addEventListener('click', function (e) {
        var el = e.target.closest ? e.target.closest('[data-confirm]') : null;
        if (!el || el.tagName === 'FORM') return;
        if ((el.type === 'submit' || el.tagName === 'INPUT') && el.form) return; // đã xử lý ở sự kiện submit
        e.preventDefault();
        ask(optsFrom(el)).then(function (ok) {
            if (!ok) return;
            var sel = el.getAttribute('data-confirm-remove');
            if (sel) { var t = el.closest(sel); if (t) t.remove(); return; }
            if (el.tagName === 'A' && el.href) { window.location.href = el.href; return; }
            if (el.form) { approved.add(el.form); el.form.requestSubmit ? el.form.requestSubmit(el) : el.form.submit(); }
        });
    }, true);
})();
