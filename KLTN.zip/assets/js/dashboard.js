/**
 * Dashboard Charts
 */
(function() {
    'use strict';

    function initCharts() {
        if (typeof Chart === 'undefined') {
            // Load Chart.js dynamically
            const script = document.createElement('script');
            script.src = 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js';
            script.onload = renderCharts;
            document.head.appendChild(script);
        } else {
            renderCharts();
        }
    }

    const PALETTE = ['#6366f1', '#3bb273', '#ec9f3a', '#e5539b', '#38bdf8', '#8b5cf6', '#ef4444', '#14b8a6'];

    function gradient(ctx, from, to) {
        const g = ctx.createLinearGradient(0, 0, 0, 300);
        g.addColorStop(0, from);
        g.addColorStop(1, to);
        return g;
    }

    // Biểu đồ chưa có dữ liệu: hiện thông báo thay vì khung trắng
    function showEmpty(canvas, text) {
        const box = canvas && canvas.parentElement;
        if (box) box.innerHTML = '<div class="chart-empty">' + (text || 'Chưa có dữ liệu để hiển thị') + '</div>';
    }
    function rowsOf(res) { const d = (res && res.data) || res; return Array.isArray(d) ? d : []; }

    function renderCharts() {
        const data = window.dashboardData || {};
        const chartUrl = data.chartDataUrl || '/analysis/dashboard-data';
        if (typeof Chart !== 'undefined') {
            Chart.defaults.font.family = '"Be Vietnam Pro", -apple-system, "Segoe UI", Roboto, Arial, sans-serif';
            Chart.defaults.color = '#6b738c';
            Chart.defaults.plugins.legend.labels.usePointStyle = true;
            Chart.defaults.plugins.tooltip.backgroundColor = '#141827';
            Chart.defaults.plugins.tooltip.padding = 10;
            Chart.defaults.plugins.tooltip.cornerRadius = 8;
        }
        const grid = { color: 'rgba(107, 115, 140, 0.14)' };

        // KPI scores bar chart
        const kpiCtx = document.getElementById('chartKpiScores');
        if (kpiCtx && (!data.kpiScores || !data.kpiScores.length)) showEmpty(kpiCtx);
        else if (kpiCtx) {
            new Chart(kpiCtx, {
                type: 'bar',
                data: {
                    labels: data.kpiScores.map(k => k.kpi_name),
                    datasets: [{
                        label: 'Điểm trung bình',
                        data: data.kpiScores.map(k => Math.round((parseFloat(k.avg_score) || 0) * 100) / 100),
                        backgroundColor: data.kpiScores.map((k, i) => PALETTE[i % PALETTE.length]),
                        borderRadius: 6,
                        maxBarThickness: 44
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true, max: 100, grid: grid }, x: { grid: { display: false } } }
                }
            });
        }

        // Distribution
        const distCtx = document.getElementById('chartDistribution');
        if (distCtx) {
            ajax.get(chartUrl, { type: 'distribution' })
                .then(res => {
                    if (!rowsOf(res).length) return showEmpty(distCtx);
                    new Chart(distCtx, {
                        type: 'doughnut',
                        data: {
                            labels: (res.data || res).map(d => d.classification || 'Khác'),
                            datasets: [{
                                data: (res.data || res).map(d => parseInt(d.count)),
                                backgroundColor: ['#3bb273', '#6366f1', '#ec9f3a', '#ef4444', '#98a0b8'],
                                borderColor: '#fff',
                                borderWidth: 3,
                                hoverOffset: 8
                            }]
                        },
                        options: { responsive: true, maintainAspectRatio: false, cutout: '62%', plugins: { legend: { position: 'bottom' } } }
                    });
                })
                .catch(() => { /* lỗi tải: để trống */ });
        }

        // Trend
        const trendCtx = document.getElementById('chartTrend');
        if (trendCtx) {
            ajax.get(chartUrl, { type: 'trend' })
                .then(res => {
                    const d = rowsOf(res);
                    if (!d.length) return showEmpty(trendCtx);
                    new Chart(trendCtx, {
                        type: 'line',
                        data: {
                            labels: d.map(x => x.month),
                            datasets: [{
                                label: 'Điểm TB',
                                data: d.map(x => Math.round((parseFloat(x.avg_score) || 0) * 100) / 100),
                                borderColor: '#6366f1',
                                backgroundColor: gradient(trendCtx.getContext('2d'), 'rgba(99, 102, 241, 0.22)', 'rgba(99, 102, 241, 0.02)'),
                                pointBackgroundColor: '#6366f1',
                                pointBorderColor: '#fff',
                                pointBorderWidth: 2,
                                pointRadius: 3,
                                borderWidth: 2,
                                tension: 0.35,
                                fill: true
                            }]
                        },
                        options: {
                            responsive: true,
                            maintainAspectRatio: false,
                            scales: { y: { beginAtZero: true, max: 100, grid: grid }, x: { grid: { display: false } } }
                        }
                    });
                })
                .catch(() => { /* lỗi tải: để trống */ });
        }

        // Completion rate
        const compCtx = document.getElementById('chartCompletion');
        if (compCtx && (!data.completionRate || !data.completionRate.length)) showEmpty(compCtx);
        else if (compCtx) {
            const rates = data.completionRate.map(s => {
                const total = parseInt(s.total) || 0;
                const completed = parseInt(s.completed) || 0;
                return total > 0 ? Math.round((completed / total) * 1000) / 10 : 0;
            });
            new Chart(compCtx, {
                type: 'bar',
                data: {
                    labels: data.completionRate.map(s => s.title.substring(0, 20) + (s.title.length > 20 ? '...' : '')),
                    datasets: [{
                        label: 'Tỷ lệ hoàn thành (%)',
                        data: rates,
                        backgroundColor: data.completionRate.map((s, i) => PALETTE[(i + 2) % PALETTE.length]),
                        borderRadius: 6,
                        maxBarThickness: 44
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { display: false } },
                    scales: { y: { beginAtZero: true, max: 100, grid: grid }, x: { grid: { display: false } } }
                }
            });
        }
    }

    document.addEventListener('DOMContentLoaded', initCharts);
})();