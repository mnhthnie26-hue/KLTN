/**
 * Main JavaScript — điều hướng dashboard, tìm kiếm, thu gọn sidebar, responsive helpers
 */
(function () {
    'use strict';

    var DESKTOP = 1025; // >= px: sidebar cố định; nhỏ hơn: ngăn kéo

    function ready(fn) {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn);
    }

    ready(function () {
        var root = document.documentElement;
        var header = document.getElementById('appHeader');
        var sidebar = document.getElementById('appSidebar');
        var backdrop = document.getElementById('sidebarBackdrop');
        var sidebarToggle = document.getElementById('sidebarToggle');
        var isDesktop = function () { return window.innerWidth >= DESKTOP; };

        /* ---------- Sidebar: ngăn kéo (mobile) / thu gọn (desktop) ---------- */
        function setDrawer(open) {
            if (!sidebar) return;
            sidebar.classList.toggle('show', open);
            if (backdrop) backdrop.classList.toggle('show', open);
            if (sidebarToggle) sidebarToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
            document.body.style.overflow = open && !isDesktop() ? 'hidden' : '';
        }

        function setCollapsed(collapsed) {
            root.classList.toggle('sidebar-collapsed', collapsed);
            try { localStorage.setItem('sidebarCollapsed', collapsed ? '1' : '0'); } catch (e) { /* bỏ qua */ }
            if (sidebarToggle) sidebarToggle.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
            // Cho Chart.js tính lại kích thước sau khi layout đổi
            setTimeout(function () { window.dispatchEvent(new Event('resize')); }, 260);
        }

        if (sidebarToggle && sidebar) {
            if (isDesktop()) sidebarToggle.setAttribute('aria-expanded', root.classList.contains('sidebar-collapsed') ? 'false' : 'true');
            sidebarToggle.addEventListener('click', function () {
                if (isDesktop()) setCollapsed(!root.classList.contains('sidebar-collapsed'));
                else setDrawer(!sidebar.classList.contains('show'));
            });
            if (backdrop) backdrop.addEventListener('click', function () { setDrawer(false); });
            // Chạm vào liên kết trong ngăn kéo thì đóng lại
            sidebar.addEventListener('click', function (e) {
                if (!isDesktop() && e.target.closest('a')) setDrawer(false);
            });
        }

        window.addEventListener('resize', function () {
            if (isDesktop()) setDrawer(false);
            else root.classList.remove('sidebar-collapsed');
        });

        /* ---------- Nhóm menu (đóng/mở) ---------- */
        document.querySelectorAll('.menu-group-toggle').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var group = btn.closest('.menu-group');
                // Sidebar đang thu gọn: bấm vào nhóm sẽ mở rộng sidebar để thấy menu con
                if (isDesktop() && root.classList.contains('sidebar-collapsed')) {
                    setCollapsed(false);
                    group.classList.add('open');
                    btn.setAttribute('aria-expanded', 'true');
                    return;
                }
                var open = !group.classList.contains('open');
                group.classList.toggle('open', open);
                btn.setAttribute('aria-expanded', open ? 'true' : 'false');
            });
        });

        /* ---------- Tìm menu trong sidebar ---------- */
        var menuSearch = document.getElementById('menuSearch');
        if (menuSearch) {
            menuSearch.addEventListener('input', function () {
                var q = normalize(menuSearch.value);
                document.querySelectorAll('.sidebar-menu > li').forEach(function (li) {
                    if (li.classList.contains('menu-group')) {
                        var any = false;
                        li.querySelectorAll('.submenu li').forEach(function (sub) {
                            var hit = !q || normalize(sub.textContent).indexOf(q) > -1;
                            sub.classList.toggle('is-hidden', !hit);
                            if (hit) any = true;
                        });
                        var groupHit = !q || normalize(li.querySelector('.menu-label').textContent).indexOf(q) > -1;
                        if (groupHit && q) { li.querySelectorAll('.submenu li').forEach(function (s) { s.classList.remove('is-hidden'); }); any = true; }
                        li.classList.toggle('is-hidden', !any);
                        if (q && any) li.classList.add('open');
                    } else {
                        li.classList.toggle('is-hidden', !!q && normalize(li.textContent).indexOf(q) === -1);
                    }
                });
            });
        }

        /* ---------- Tìm nhanh chức năng trên header (nhấn "/" để focus) ---------- */
        var gInput = document.getElementById('globalSearch');
        var gList = document.getElementById('searchResults');
        var searchToggle = document.getElementById('searchToggle');
        var entries = [];
        document.querySelectorAll('.sidebar-menu a[href]').forEach(function (a) {
            var group = a.closest('.menu-group');
            entries.push({
                label: a.textContent.replace(/\s+/g, ' ').trim(),
                href: a.getAttribute('href'),
                group: group ? group.querySelector('.menu-label').textContent.trim() : ''
            });
        });

        function renderResults(q) {
            if (!gList) return;
            var key = normalize(q);
            if (!key) { gList.classList.remove('show'); gInput.setAttribute('aria-expanded', 'false'); return; }
            var hits = entries.filter(function (it) { return normalize(it.label + ' ' + it.group).indexOf(key) > -1; }).slice(0, 8);
            gList.innerHTML = '';
            if (!hits.length) {
                var empty = document.createElement('li');
                empty.className = 'empty';
                empty.textContent = 'Không tìm thấy chức năng phù hợp';
                gList.appendChild(empty);
            }
            hits.forEach(function (it) {
                var li = document.createElement('li');
                li.setAttribute('role', 'option');
                var a = document.createElement('a');
                a.href = it.href;
                a.textContent = it.label;
                if (it.group) { var s = document.createElement('small'); s.textContent = it.group; a.appendChild(s); }
                li.appendChild(a);
                gList.appendChild(li);
            });
            gList.classList.add('show');
            gInput.setAttribute('aria-expanded', 'true');
        }

        if (gInput && gList) {
            gInput.addEventListener('input', function () { renderResults(gInput.value); });
            gInput.addEventListener('keydown', function (e) {
                var links = Array.prototype.slice.call(gList.querySelectorAll('a'));
                var cur = links.findIndex(function (l) { return l.classList.contains('is-focus'); });
                if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    if (!links.length) return;
                    links.forEach(function (l) { l.classList.remove('is-focus'); });
                    cur = e.key === 'ArrowDown' ? (cur + 1) % links.length : (cur - 1 + links.length) % links.length;
                    links[cur].classList.add('is-focus');
                } else if (e.key === 'Enter') {
                    var target = links[cur] || links[0];
                    if (target) { e.preventDefault(); window.location.href = target.href; }
                }
            });
            document.addEventListener('click', function (e) {
                if (!e.target.closest('.header-search')) gList.classList.remove('show');
            });
        }

        if (searchToggle && header) {
            searchToggle.addEventListener('click', function (e) {
                e.stopPropagation();
                var open = !header.classList.contains('search-open');
                header.classList.toggle('search-open', open);
                if (open && gInput) setTimeout(function () { gInput.focus(); }, 60);
            });
        }

        document.addEventListener('keydown', function (e) {
            var tag = (document.activeElement && document.activeElement.tagName) || '';
            if (e.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(tag) && gInput) {
                e.preventDefault();
                if (header && !isDesktop()) header.classList.add('search-open');
                gInput.focus();
            }
        });

        /* ---------- Toàn màn hình ---------- */
        var fs = document.getElementById('fullscreenToggle');
        if (fs) {
            if (!document.fullscreenEnabled) { fs.style.display = 'none'; }
            fs.addEventListener('click', function () {
                if (document.fullscreenElement) document.exitFullscreen();
                else root.requestFullscreen && root.requestFullscreen();
            });
        }

        /* ---------- User menu ---------- */
        var userMenuButton = document.getElementById('userMenuButton');
        var userMenu = document.getElementById('userMenu');
        function setUserMenu(open) {
            if (!userMenu) return;
            userMenu.classList.toggle('show', open);
            if (userMenuButton) userMenuButton.setAttribute('aria-expanded', open ? 'true' : 'false');
        }
        if (userMenuButton && userMenu) {
            userMenuButton.addEventListener('click', function (e) {
                e.stopPropagation();
                setUserMenu(!userMenu.classList.contains('show'));
            });
            document.addEventListener('click', function () { setUserMenu(false); });
        }

        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape') {
                setUserMenu(false);
                setDrawer(false);
                if (gList) gList.classList.remove('show');
                if (header) header.classList.remove('search-open');
            }
        });

        /* ---------- Nút lên đầu trang ---------- */
        var topBtn = document.getElementById('scrollTop');
        if (topBtn) {
            var ticking = false;
            window.addEventListener('scroll', function () {
                if (ticking) return;
                ticking = true;
                window.requestAnimationFrame(function () {
                    topBtn.classList.toggle('show', window.scrollY > 320);
                    ticking = false;
                });
            }, { passive: true });
            topBtn.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
        }

        /* ---------- Bảng: tự bọc để cuộn ngang trên màn hình nhỏ (không hiện thanh cuộn) ---------- */
        document.querySelectorAll('table.table').forEach(function (t) {
            if (t.closest('.table-responsive')) return;
            var wrap = document.createElement('div');
            wrap.className = 'table-responsive';
            t.parentNode.insertBefore(wrap, t);
            wrap.appendChild(t);
        });

    });

    /** Bỏ dấu tiếng Việt + chữ thường để tìm kiếm thân thiện */
    function normalize(str) {
        return String(str || '').toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .replace(/đ/g, 'd').trim();
    }
})();
