/**
 * Chart.js helpers
 */
(function() {
    'use strict';
    // Chart.js loaded dynamically
})();