/**
 * Survey Builder
 */
(function() {
    'use strict';
    // Survey builder handled inline in view for now
})();