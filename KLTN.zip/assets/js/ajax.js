/**
 * AJAX Helper
 */

(function() {
    'use strict';

    window.ajax = {
        /**
         * Make an AJAX request
         */
        request: function(url, options) {
            options = options || {};
            options.url = url;
            options.method = (options.method || 'GET').toUpperCase();

            const csrfToken = document.querySelector('meta[name="csrf-token"]')?.content
                || document.querySelector('input[name="_csrf_token"]')?.value;

            const headers = Object.assign({
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json'
            }, options.headers || {});

            if (csrfToken) {
                headers['X-CSRF-Token'] = csrfToken;
            }

            let body = options.body || null;
            if (body && !(body instanceof FormData) && typeof body === 'object') {
                headers['Content-Type'] = 'application/json';
                body = JSON.stringify(body);
            }

            return fetch(url, {
                method: options.method,
                headers: headers,
                body: body,
                credentials: 'same-origin'
            }).then(function(response) {
                return response.json().then(function(data) {
                    if (!response.ok) {
                        const error = new Error(data.message || 'Request failed');
                        error.status = response.status;
                        error.data = data;
                        throw error;
                    }
                    return data;
                });
            });
        },

        get: function(url, params) {
            if (params) {
                const qs = Object.entries(params)
                    .filter(([k, v]) => v !== undefined && v !== null && v !== '')
                    .map(([k, v]) => encodeURIComponent(k) + '=' + encodeURIComponent(v))
                    .join('&');
                if (qs) url += (url.includes('?') ? '&' : '?') + qs;
            }
            return this.request(url, { method: 'GET' });
        },

        post: function(url, body) {
            return this.request(url, { method: 'POST', body: body || {} });
        },

        put: function(url, body) {
            return this.request(url, { method: 'PUT', body: body || {} });
        },

        delete: function(url) {
            return this.request(url, { method: 'DELETE' });
        }
    };

    // Setup CSRF meta tag if not present
    document.addEventListener('DOMContentLoaded', function() {
        if (!document.querySelector('meta[name="csrf-token"]')) {
            const csrfInput = document.querySelector('input[name="_csrf_token"]');
            if (csrfInput) {
                const meta = document.createElement('meta');
                meta.setAttribute('name', 'csrf-token');
                meta.setAttribute('content', csrfInput.value);
                document.head.appendChild(meta);
            }
        }
    });
})();