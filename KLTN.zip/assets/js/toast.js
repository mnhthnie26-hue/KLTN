/**
 * Toast - thông báo góc trên bên phải (chỉ chữ, không icon)
 * - Chỉ hiển thị 1 thông báo tại một thời điểm.
 * - Tự ẩn sau 2 giây.
 * - Có thông báo mới: thông báo cũ bị gỡ ngay lập tức để hiện thông báo mới.
 *
 * Dùng trong JS:  Toast.success('Đã lưu'); Toast.error('Có lỗi'); Toast.show('warning', '...');
 * Dùng từ PHP:    View::renderPartial('layouts/alerts', ['success' => '...']);
 */
(function () {
    'use strict';

    var DURATION = 2000; // tổng thời gian tồn tại (ms)
    var FADE = 200;      // thời gian mờ dần ở cuối (nằm trong DURATION)
    var TYPES = { success: 1, error: 1, warning: 1, info: 1 };

    var container = null;
    var current = null;
    var timer = null;

    function getContainer() {
        if (container && document.body.contains(container)) return container;
        container = document.createElement('div');
        container.className = 'toast-container';
        document.body.appendChild(container);
        return container;
    }

    function clear() {
        if (timer) { clearTimeout(timer); timer = null; }
        if (current) { current.remove(); current = null; }
    }

    function show(type, message) {
        if (message === undefined || message === null || message === '') return;
        if (!TYPES[type]) type = 'info';

        clear(); // thông báo cũ biến mất ngay

        var el = document.createElement('div');
        el.className = 'toast toast-' + type;
        el.setAttribute('role', type === 'error' ? 'alert' : 'status');

        // Chỉ có chữ: không icon, khung ôm vừa nội dung
        el.textContent = String(message);
        getContainer().appendChild(el);
        current = el;

        timer = setTimeout(function () {
            if (current !== el) return;
            el.classList.add('toast-hide');
            timer = setTimeout(function () {
                if (current === el) { el.remove(); current = null; }
                timer = null;
            }, FADE);
        }, DURATION - FADE);
    }

    window.Toast = {
        show: show,
        success: function (m) { show('success', m); },
        error: function (m) { show('error', m); },
        warning: function (m) { show('warning', m); },
        info: function (m) { show('info', m); }
    };

    // Đọc thông báo do PHP render ra (flash message, lỗi form...)
    function init() {
        var nodes = document.querySelectorAll('script[data-toast]');
        Array.prototype.forEach.call(nodes, function (node) {
            var list;
            try { list = JSON.parse(node.textContent); } catch (e) { return; }
            if (!Array.isArray(list)) return;
            list.forEach(function (t) { show(t.type, t.message); });
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
