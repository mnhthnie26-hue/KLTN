/**
 * Tự lọc — mọi form.filter-form (và form[data-autofilter]) tự gửi khi người dùng chọn / gõ.
 * Không cần nút "Lọc", "Tìm" hay "Xem thống kê".
 */
(function () {
    'use strict';

    var KEY = 'autofilter:focus';
    var DELAY = 400; // ms chờ sau khi ngừng gõ

    function ready(fn) {
        if (document.readyState !== 'loading') fn();
        else document.addEventListener('DOMContentLoaded', fn);
    }

    ready(function () {
        var forms = document.querySelectorAll('form.filter-form, form[data-autofilter]');

        forms.forEach(function (form, idx) {
            var timer = null;

            function submit(field) {
                clearTimeout(timer);
                try {
                    if (field && field.name && (field.type === 'text' || field.type === 'search' || field.tagName === 'TEXTAREA')) {
                        sessionStorage.setItem(KEY, JSON.stringify({
                            form: idx, name: field.name, pos: field.selectionStart
                        }));
                    } else {
                        sessionStorage.removeItem(KEY);
                    }
                } catch (e) { /* bỏ qua */ }
                // Bỏ các ô trống để URL gọn
                form.querySelectorAll('input, select').forEach(function (el) {
                    if (el.name && el.value === '' && el.type !== 'hidden') el.disabled = true;
                });
                form.submit();
            }

            // Chọn trong ô select / ngày / checkbox: lọc ngay
            form.addEventListener('change', function (e) {
                var t = e.target;
                if (t.tagName === 'SELECT' || t.type === 'date' || t.type === 'checkbox' || t.type === 'radio') submit(t);
            });

            // Gõ vào ô chữ: chờ ngừng gõ rồi lọc
            form.addEventListener('input', function (e) {
                var t = e.target;
                if (t.tagName === 'INPUT' && (t.type === 'text' || t.type === 'search' || t.type === 'number') || t.tagName === 'TEXTAREA') {
                    clearTimeout(timer);
                    timer = setTimeout(function () { submit(t); }, DELAY);
                }
            });

            // Enter: lọc ngay (form không còn nút submit)
            form.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && e.target.tagName === 'INPUT') {
                    e.preventDefault();
                    submit(e.target);
                }
            });

            form.addEventListener('submit', function (e) { e.preventDefault(); submit(null); });
        });

        // Sau khi trang tải lại: trả con trỏ về ô đang gõ
        try {
            var saved = JSON.parse(sessionStorage.getItem(KEY) || 'null');
            sessionStorage.removeItem(KEY);
            if (saved && forms[saved.form]) {
                var el = forms[saved.form].querySelector('[name="' + saved.name + '"]');
                if (el) {
                    el.focus();
                    var p = typeof saved.pos === 'number' ? saved.pos : el.value.length;
                    if (el.setSelectionRange) el.setSelectionRange(p, p);
                }
            }
        } catch (e) { /* bỏ qua */ }
    });
})();
