/**
 * Tiện ích biểu mẫu mật khẩu (đăng nhập + đổi mật khẩu)
 * - Hiện/ẩn mật khẩu:      <button data-toggle-password="id-input">
 * - Cảnh báo Caps Lock:    <p data-caps-hint hidden>
 * - Trạng thái đang gửi:   <form data-auth-form>
 * - Độ mạnh mật khẩu mới:  <input data-pw-strength> + [data-pw-meter] + [data-pw-label]
 * - Kiểm tra khớp mật khẩu: <input data-pw-confirm="id-mat-khau-moi"> + [data-pw-match]
 * Không tự focus vào bất kỳ ô nhập nào.
 */
(function () {
    'use strict';

    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-toggle-password]');
        if (!btn) return;
        var input = document.getElementById(btn.getAttribute('data-toggle-password'));
        if (!input) return;
        var show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        btn.classList.toggle('is-on', show);
        btn.setAttribute('aria-pressed', show ? 'true' : 'false');
        btn.setAttribute('aria-label', show ? 'Ẩn mật khẩu' : 'Hiện mật khẩu');
    });

    function caps(e) {
        var t = e.target;
        if (!t || t.type !== 'password' || !e.getModifierState) return;
        var scope = t.closest('.field') || document;
        var hint = scope.querySelector('[data-caps-hint]');
        if (hint) hint.hidden = !e.getModifierState('CapsLock');
    }
    document.addEventListener('keydown', caps);
    document.addEventListener('keyup', caps);

    document.addEventListener('submit', function (e) {
        var form = e.target;
        if (!form.matches || !form.matches('[data-auth-form]') || e.defaultPrevented) return;
        var btn = form.querySelector('[type="submit"]');
        if (!btn) return;
        btn.classList.add('is-loading');
        btn.setAttribute('aria-busy', 'true');
        setTimeout(function () { btn.disabled = true; }, 0);
    });

    // Độ mạnh mật khẩu
    var LEVELS = ['Rất yếu', 'Yếu', 'Trung bình', 'Khá', 'Mạnh'];
    function score(v) {
        if (!v) return -1;
        var s = 0;
        if (v.length >= 8) s++;
        if (v.length >= 12) s++;
        if (/[a-z]/.test(v) && /[A-Z]/.test(v)) s++;
        if (/\d/.test(v)) s++;
        if (/[^A-Za-z0-9]/.test(v)) s++;
        return Math.min(s, 4);
    }
    function refreshMatch() {
        var conf = document.querySelector('[data-pw-confirm]');
        var out = document.querySelector('[data-pw-match]');
        if (!conf || !out) return;
        var main = document.getElementById(conf.getAttribute('data-pw-confirm'));
        if (!main || !conf.value) { out.textContent = ''; out.className = 'field-hint'; return; }
        var ok = main.value === conf.value;
        out.textContent = ok ? 'Mật khẩu khớp.' : 'Mật khẩu xác nhận chưa khớp.';
        out.className = 'field-hint ' + (ok ? 'is-ok' : 'is-bad');
    }
    document.addEventListener('input', function (e) {
        var t = e.target;
        if (t.matches && t.matches('[data-pw-strength]')) {
            var sc = score(t.value);
            var meter = document.querySelector('[data-pw-meter]');
            var label = document.querySelector('[data-pw-label]');
            if (meter) meter.setAttribute('data-level', String(sc + 1));
            if (label) label.textContent = sc < 0 ? '' : 'Độ mạnh: ' + LEVELS[sc];
        }
        if (t.matches && (t.matches('[data-pw-strength]') || t.matches('[data-pw-confirm]'))) refreshMatch();
    });
})();
