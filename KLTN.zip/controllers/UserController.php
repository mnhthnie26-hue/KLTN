<?php
/**
 * UserController
 */

declare(strict_types=1);

class UserController
{
    private UserService $userService;
    private RoleRepository $roleRepo;

    public function __construct()
    {
        $this->userService = new UserService();
        $this->roleRepo = new RoleRepository();
    }

    public function index($params, Request $request, Response $response): void
    {
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 20;

        $filters = [
            'search'        => trim($request->query('search', '')),
            'user_type'     => $request->query('user_type', ''),
            'status'        => $request->query('status', ''),
            'faculty_id'    => $request->query('faculty_id', ''),
            'department_id' => $request->query('department_id', ''),
        ];

        $result = $this->userService->listUsers($page, $perPage, $filters);

        $faculties = Database::getInstance()->fetchAll('SELECT id, name FROM faculties WHERE status = 1 ORDER BY name');
        $roles = $this->roleRepo->findAll(['status' => 1], 'sort_order ASC');

        $data = [
            'pageTitle'   => 'Quản lý Người dùng',
            'user'        => Auth::user(),
            'users'       => $result['items'],
            'pagination'  => $result['pagination'],
            'filters'     => $filters,
            'faculties'   => $faculties,
            'roles'       => $roles,
            'success'     => Session::flash('success'),
            'error'       => Session::flash('error'),
        ];

        echo View::render('users/index', $data);
    }

    public function show($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $user = $this->userService->getUser($id);

        if (!$user) {
            Session::flash('error', 'Người dùng không tồn tại');
            $response->redirect(url('users'))->send();
            return;
        }

        $data = [
            'pageTitle' => 'Chi tiết Người dùng',
            'user'      => Auth::user(),
            'targetUser'=> $user,
        ];

        echo View::render('users/view', $data);
    }

    public function create($params, Request $request, Response $response): void
    {
        $faculties = Database::getInstance()->fetchAll('SELECT id, name FROM faculties WHERE status = 1 ORDER BY name');
        $departments = Database::getInstance()->fetchAll('SELECT id, name, faculty_id FROM departments WHERE status = 1 ORDER BY name');
        $roles = $this->roleRepo->findAll(['status' => 1], 'sort_order ASC');

        $data = [
            'pageTitle'   => 'Tạo Người dùng',
            'user'        => Auth::user(),
            'faculties'   => $faculties,
            'departments' => $departments,
            'roles'       => $roles,
            'old'         => Session::flash('form_data') ?? [],
            'csrf_token'  => Session::csrfToken(),
        ];

        echo View::render('users/form', $data);
    }

    public function store($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('users/create'))->send();
            return;
        }

        $roleIds = array_map('intval', (array)$request->post('roles', []));
        $result = $this->userService->createUser($request->post(), $roleIds);

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            Session::flash('form_data', $request->post());
            $response->redirect(url('users/create'))->send();
            return;
        }

        Session::flash('success', $result['message']);
        $response->redirect(url('users'))->send();
    }

    public function edit($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $user = $this->userService->getUser($id);

        if (!$user) {
            Session::flash('error', 'Người dùng không tồn tại');
            $response->redirect(url('users'))->send();
            return;
        }

        $faculties = Database::getInstance()->fetchAll('SELECT id, name FROM faculties WHERE status = 1 ORDER BY name');
        $departments = Database::getInstance()->fetchAll('SELECT id, name, faculty_id FROM departments WHERE status = 1 ORDER BY name');
        $roles = $this->roleRepo->findAll(['status' => 1], 'sort_order ASC');

        $data = [
            'pageTitle'   => 'Sửa Người dùng',
            'user'        => Auth::user(),
            'targetUser'  => $user,
            'faculties'   => $faculties,
            'departments' => $departments,
            'roles'       => $roles,
            'csrf_token'  => Session::csrfToken(),
        ];

        echo View::render('users/form', $data);
    }

    public function update($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('users'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $roleIds = array_map('intval', (array)$request->post('roles', []));

        $result = $this->userService->updateUser($id, $request->post(), $roleIds);

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            $response->redirect(url('users/' . $id . '/edit'))->send();
            return;
        }

        Session::flash('success', $result['message']);
        $response->redirect(url('users'))->send();
    }

    public function destroy($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('users'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->userService->deleteUser($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('users'))->send();
    }

    public function resetPassword($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('users'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $newPassword = $request->post('new_password', '');

        if (strlen($newPassword) < (int)getSetting('security.password_min_length', 6)) {
            Session::flash('error', 'Mật khẩu phải có ít nhất ' . (int)getSetting('security.password_min_length', 6) . ' ký tự');
            $response->redirect(url('users/' . $id . '/edit'))->send();
            return;
        }

        $result = Auth::resetPassword($id, $newPassword);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('users'))->send();
    }

    public function lock($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('users'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->userService->lockUser($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('users'))->send();
    }

    public function unlock($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('users'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->userService->unlockUser($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('users'))->send();
    }
}