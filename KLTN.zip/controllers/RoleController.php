<?php
/**
 * RoleController
 */

declare(strict_types=1);

class RoleController
{
    private RoleRepository $roleRepo;

    public function __construct()
    {
        $this->roleRepo = new RoleRepository();
    }

    public function index($params, Request $request, Response $response): void
    {
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 20;
        $search = trim($request->query('search', ''));

        // Search the roles table by name/display_name (LIKE search).
        $allRoles = $this->roleRepo->findAll([], 'sort_order ASC, id ASC');
        if ($search !== '') {
            $needle = mb_strtolower($search);
            $allRoles = array_values(array_filter($allRoles, function ($r) use ($needle) {
                return str_contains(mb_strtolower((string)($r['name'] ?? '')), $needle)
                    || str_contains(mb_strtolower((string)($r['display_name'] ?? '')), $needle);
            }));
        }
        $total = count($allRoles);
        $offset = ($page - 1) * $perPage;
        $roles = array_slice($allRoles, $offset, $perPage);

        $data = [
            'pageTitle'  => 'Quản lý Vai trò',
            'user'       => Auth::user(),
            'roles'      => $roles,
            'pagination' => paginate($total, $page, $perPage),
            'search'     => $search,
            'success'    => Session::flash('success'),
            'error'      => Session::flash('error'),
        ];

        echo View::render('roles/index', $data);
    }

    public function create($params, Request $request, Response $response): void
    {
        $data = [
            'pageTitle' => 'Tạo Vai trò',
            'user'      => Auth::user(),
            'permissions' => Permission::getAllGrouped(),
            'csrf_token' => Session::csrfToken(),
        ];

        echo View::render('roles/form', $data);
    }

    public function store($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('roles/create'))->send();
            return;
        }

        $validator = Validator::make($request->post(), [
            'name'         => 'required|string|max:50|unique:roles,name',
            'display_name' => 'required|string|max:150',
            'description'  => 'string',
            'sort_order'   => 'integer',
        ]);

        if ($validator->fails()) {
            Session::flash('error', 'Vui lòng kiểm tra lại thông tin');
            Session::flash('form_data', $request->post());
            $response->redirect(url('roles/create'))->send();
            return;
        }

        $roleId = $this->roleRepo->create([
            'name'         => Security::sanitize($request->post('name')),
            'display_name' => Security::sanitize($request->post('display_name')),
            'description'  => Security::sanitize($request->post('description', '')),
            'sort_order'   => (int)$request->post('sort_order', 0),
            'is_system'    => 0,
            'status'       => 1,
        ]);

        // Sync permissions
        $permissionIds = (array)$request->post('permissions', []);
        if (!empty($permissionIds)) {
            Permission::syncRolePermissions($roleId, array_map('intval', $permissionIds));
        }

        Logger::getInstance()->audit(AUDIT_CREATE, 'roles', Auth::id(), $roleId, null, ['name' => $request->post('name')], 'Tạo vai trò');

        Session::flash('success', 'Đã tạo vai trò thành công');
        $response->redirect(url('roles'))->send();
    }

    public function edit($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $role = $this->roleRepo->getWithPermissions($id);

        if (!$role) {
            Session::flash('error', 'Vai trò không tồn tại');
            $response->redirect(url('roles'))->send();
            return;
        }

        $data = [
            'pageTitle'   => 'Sửa Vai trò',
            'user'        => Auth::user(),
            'role'        => $role,
            'permissions' => Permission::getAllGrouped(),
            'rolePermIds' => $role['permission_ids'],
            'csrf_token'  => Session::csrfToken(),
        ];

        echo View::render('roles/form', $data);
    }

    public function update($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('roles'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $role = $this->roleRepo->find($id);

        if (!$role) {
            Session::flash('error', 'Vai trò không tồn tại');
            $response->redirect(url('roles'))->send();
            return;
        }

        $this->roleRepo->update($id, [
            'display_name' => Security::sanitize($request->post('display_name')),
            'description'  => Security::sanitize($request->post('description', '')),
            'sort_order'   => (int)$request->post('sort_order', 0),
        ]);

        $permissionIds = (array)$request->post('permissions', []);
        Permission::syncRolePermissions($id, array_map('intval', $permissionIds));

        Logger::getInstance()->audit(AUDIT_UPDATE, 'roles', Auth::id(), $id, $role, $request->post(), 'Cập nhật vai trò');

        Session::flash('success', 'Đã cập nhật vai trò');
        $response->redirect(url('roles'))->send();
    }

    public function destroy($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('roles'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $role = $this->roleRepo->find($id);

        if (!$role) {
            Session::flash('error', 'Vai trò không tồn tại');
            $response->redirect(url('roles'))->send();
            return;
        }

        if ((int)$role['is_system'] === 1) {
            Session::flash('error', 'Không thể xóa vai trò hệ thống');
            $response->redirect(url('roles'))->send();
            return;
        }

        $this->roleRepo->delete($id);
        Logger::getInstance()->audit(AUDIT_DELETE, 'roles', Auth::id(), $id, $role, null, 'Xóa vai trò');

        Session::flash('success', 'Đã xóa vai trò');
        $response->redirect(url('roles'))->send();
    }

    public function permissions($params, Request $request, Response $response): void
    {
        $data = [
            'pageTitle'   => 'Phân quyền',
            'user'        => Auth::user(),
            'roles'       => $this->roleRepo->findAll([], 'sort_order ASC'),
            'permissions' => Permission::getAllGrouped(),
            'csrf_token'  => Session::csrfToken(),
            'success'     => Session::flash('success'),
            'error'       => Session::flash('error'),
        ];

        echo View::render('roles/permissions', $data);
    }
}