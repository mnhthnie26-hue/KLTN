<?php
/**
 * ReportController
 */

declare(strict_types=1);

class ReportController
{
    private ReportService $service;

    public function __construct()
    {
        $this->service = new ReportService();
    }

    public function index($params, Request $request, Response $response): void
    {
        $exports = $this->service->listExports(Auth::id());
        $surveys = Database::getInstance()->fetchAll('SELECT id, title FROM surveys WHERE deleted_at IS NULL ORDER BY title');
        $kpis = Database::getInstance()->fetchAll('SELECT id, name FROM kpis WHERE deleted_at IS NULL ORDER BY name');

        $data = [
            'pageTitle' => 'Báo cáo',
            'user'      => Auth::user(),
            'exports'   => $exports,
            'surveys'   => $surveys,
            'kpis'      => $kpis,
            'csrf_token'=> Session::csrfToken(),
            'success'   => Session::flash('success'),
            'error'     => Session::flash('error'),
        ];

        echo View::render('reports/index', $data);
    }

    public function export($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('reports'))->send();
            return;
        }

        $type = $request->post('report_type', '');
        $format = $request->post('format', 'csv');
        $params = $request->post();

        $data = $this->service->getReportData($type, $params);
        $headers = $this->service->getReportHeaders($type);

        if (empty($data)) {
            Session::flash('error', 'Không có dữ liệu để xuất');
            $response->redirect(url('reports'))->send();
            return;
        }

        $filename = $type . '_' . date('Ymd_His') . '.' . ($format === 'excel' ? 'xls' : $format);
        $filePath = '';

        try {
            switch ($format) {
                case 'csv':
                    $filePath = $this->service->exportToCSV($data, $headers, $filename);
                    break;
                case 'excel':
                    $filePath = $this->service->exportToExcel($data, $headers, $filename);
                    break;
                case 'pdf':
                    $filePath = $this->service->exportToPDF($data, $headers, ucfirst($type), $filename);
                    break;
                case 'print':
                    $this->renderPrint($data, $headers, ucfirst($type));
                    return;
                default:
                    $filePath = $this->service->exportToCSV($data, $headers, $filename);
            }

            $this->service->recordExport(Auth::id(), $type, $format, $filePath);

            // Auto download
            $this->downloadFile($filePath, $filename);
        } catch (Throwable $e) {
            ErrorLog::error('[ReportController::export] failed', ['type' => $type ?? null], $e);
            Session::flash('error', 'Có lỗi khi xuất báo cáo');
            $response->redirect(url('reports'))->send();
        }
    }

    public function download($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $export = Database::getInstance()->fetchOne(
            'SELECT * FROM report_exports WHERE id = ?', [$id]
        );

        if (!$export || (int)$export['requested_by'] !== Auth::id()) {
            http_response_code(403);
            echo 'Không có quyền truy cập';
            return;
        }

        if (!file_exists($export['file_path'])) {
            http_response_code(404);
            echo 'File không tồn tại';
            return;
        }

        $this->downloadFile($export['file_path'], basename($export['file_path']));
    }

    private function downloadFile(string $filePath, string $filename): void
    {
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $mimeMap = [
            'csv'  => 'text/csv',
            'xls'  => 'application/vnd.ms-excel',
            'pdf'  => 'application/pdf',
            'html' => 'text/html',
        ];

        header('Content-Type: ' . ($mimeMap[$ext] ?? 'application/octet-stream'));
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . filesize($filePath));
        readfile($filePath);
        exit;
    }

    private function renderPrint(array $data, array $headers, string $title): void
    {
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>';
        $html .= '<style>body{font-family:Arial;font-size:12px;padding:20px;}table{width:100%;border-collapse:collapse;}th,td{border:1px solid #ddd;padding:6px;}th{background:#f3f4f6;}@media print{.no-print{display:none;}}</style>';
        $html .= '</head><body>';
        $html .= '<h1>' . htmlspecialchars($title) . '</h1>';
        $html .= '<p>Ngày xuất: ' . date('d/m/Y H:i') . ' | Người xuất: ' . htmlspecialchars(Auth::user()['full_name']) . '</p>';
        $html .= '<table><thead><tr>';
        foreach ($headers as $h) {
            $html .= '<th>' . htmlspecialchars($h) . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        foreach ($data as $row) {
            $html .= '<tr>';
            foreach ($headers as $h) {
                $html .= '<td>' . htmlspecialchars($row[$h] ?? '') . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table>';
        $html .= '<div class="no-print" style="margin-top:20px;"><button onclick="window.print()">In</button> <button onclick="window.close()">Đóng</button></div>';
        $html .= '</body></html>';

        echo $html;
        exit;
    }
}