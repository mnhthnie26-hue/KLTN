<?php
/**
 * KpiGroupController
 */

declare(strict_types=1);

class KpiGroupController
{
    private KpiGroupRepository $repo;

    public function __construct()
    {
        $this->repo = new KpiGroupRepository();
    }

    public function index($params, Request $request, Response $response): void
    {
        $groups = Database::getInstance()->fetchAll(
            'SELECT kg.*, (SELECT COUNT(*) FROM kpis k WHERE k.kpi_group_id = kg.id AND k.deleted_at IS NULL) AS kpi_count
             FROM kpi_groups kg
             WHERE kg.deleted_at IS NULL
             ORDER BY kg.sort_order, kg.id'
        );

        $data = [
            'pageTitle' => 'Quản lý Nhóm KPI',
            'user'      => Auth::user(),
            'groups'    => $groups,
            'success'   => Session::flash('success'),
            'error'     => Session::flash('error'),
        ];

        echo View::render('kpis/groups', $data);
    }

    public function create($params, Request $request, Response $response): void
    {
        $data = [
            'pageTitle'  => 'Tạo Nhóm KPI',
            'user'       => Auth::user(),
            'old'        => Session::flash('form_data') ?? [],
            'csrf_token' => Session::csrfToken(),
        ];
        echo View::render('kpis/group-form', $data);
    }

    public function store($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('kpi-groups/create'))->send();
            return;
        }

        $validator = Validator::make($request->post(), [
            'code' => 'required|string|max:50|unique:kpi_groups,code',
            'name' => 'required|string|max:200',
        ]);

        if ($validator->fails()) {
            Session::flash('error', 'Vui lòng kiểm tra dữ liệu');
            Session::flash('form_data', $request->post());
            $response->redirect(url('kpi-groups/create'))->send();
            return;
        }

        try {
            $id = $this->repo->create([
                'code'        => Security::sanitize($request->post('code')),
                'name'        => Security::sanitize($request->post('name')),
                'description' => Security::sanitize($request->post('description', '')),
                'sort_order'  => (int)($request->post('sort_order', 0)),
                'status'      => 1,
            ]);

            Logger::getInstance()->audit(AUDIT_CREATE, 'kpi_group', Auth::id(), $id, null, $request->post(), 'Tạo nhóm KPI');
            Session::flash('success', 'Đã tạo nhóm KPI');
            $response->redirect(url('kpi-groups'))->send();
        } catch (Throwable $e) {
            ErrorLog::error('[KpiGroupController::store] create failed', $request->post(), $e);
            Session::flash('error', 'Có lỗi xảy ra');
            $response->redirect(url('kpi-groups/create'))->send();
        }
    }

    public function edit($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $group = $this->repo->find($id);

        if (!$group) {
            Session::flash('error', 'Nhóm KPI không tồn tại');
            $response->redirect(url('kpi-groups'))->send();
            return;
        }

        $data = [
            'pageTitle'  => 'Sửa Nhóm KPI',
            'user'       => Auth::user(),
            'group'      => $group,
            'csrf_token' => Session::csrfToken(),
        ];
        echo View::render('kpis/group-form', $data);
    }

    public function update($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('kpi-groups'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $group = $this->repo->find($id);
        if (!$group) {
            Session::flash('error', 'Nhóm KPI không tồn tại');
            $response->redirect(url('kpi-groups'))->send();
            return;
        }

        $this->repo->update($id, [
            'name'        => Security::sanitize($request->post('name')),
            'description' => Security::sanitize($request->post('description', '')),
            'sort_order'  => (int)($request->post('sort_order', 0)),
            'status'      => (int)($request->post('status', 1)),
        ]);

        Logger::getInstance()->audit(AUDIT_UPDATE, 'kpi_group', Auth::id(), $id, $group, $request->post(), 'Cập nhật nhóm KPI');
        Session::flash('success', 'Đã cập nhật nhóm KPI');
        $response->redirect(url('kpi-groups'))->send();
    }

    public function destroy($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('kpi-groups'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $used = (int)Database::getInstance()->fetchValue('SELECT COUNT(*) FROM kpis WHERE kpi_group_id = ? AND deleted_at IS NULL', [$id]);
        if ($used > 0) {
            Session::flash('error', 'Nhóm đang được sử dụng, không thể xóa');
            $response->redirect(url('kpi-groups'))->send();
            return;
        }

        $this->repo->softDelete($id);
        Logger::getInstance()->audit(AUDIT_DELETE, 'kpi_group', Auth::id(), $id, null, null, 'Xóa nhóm KPI');
        Session::flash('success', 'Đã xóa nhóm KPI');
        $response->redirect(url('kpi-groups'))->send();
    }
}