<?php
/**
 * DashboardController
 */

declare(strict_types=1);

class DashboardController
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index($params, Request $request, Response $response): void
    {
        $user = Auth::user();

        // Get filter values
        $period = $request->query('period', '');
        $kpiId = (int)$request->query('kpi_id', 0);

        // Get statistics
        $stats = $this->getStats();
        $recentSurveys = $this->getRecentSurveys();
        $activeSurveys = $this->getActiveSurveys();
        $recentActivity = Auth::hasPermission('audit.view') ? $this->getRecentActivity() : [];
        $kpiScores = $this->getKpiScores($period, $kpiId);
        $recentEvaluations = $this->getRecentEvaluations();
        $topKpis = $this->getTopKpis();
        $completionRate = $this->getCompletionRate();

        $data = [
            'pageTitle'          => 'Tổng quan',
            'user'               => $user,
            'stats'              => $stats,
            'recentSurveys'      => $recentSurveys,
            'kpiScores'          => $kpiScores,
            'recentEvaluations'  => $recentEvaluations,
            'topKpis'            => $topKpis,
            'activeSurveys'      => $activeSurveys,
            'recentActivity'     => $recentActivity,
            'completionRate'     => $completionRate,
        ];

        echo View::render('dashboard/index', $data);
    }

    public function getChartData($params, Request $request, Response $response): void
    {
        $type = $request->query('type', 'kpi_scores');
        $period = $request->query('period', '');

        header('Content-Type: application/json');

        switch ($type) {
            case 'kpi_scores':
                $data = $this->getKpiScores($period);
                break;
            case 'trend':
                $data = $this->getTrendData();
                break;
            case 'distribution':
                $data = $this->getDistribution();
                break;
            case 'completion':
                $data = $this->getCompletionRate();
                break;
            default:
                $data = [];
        }

        echo json_encode($data);
    }

    private function getStats(): array
    {
        return [
            'total_users'     => (int)$this->db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL"),
            'total_students'  => (int)$this->db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND user_type = 'student'"),
            'total_lecturers' => (int)$this->db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND user_type = 'lecturer'"),
            'total_managers'  => (int)$this->db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND user_type IN ('manager', 'admin')"),
            'total_kpis'      => (int)$this->db->fetchValue("SELECT COUNT(*) FROM kpis WHERE deleted_at IS NULL"),
            'total_criteria'  => (int)$this->db->fetchValue("SELECT COUNT(*) FROM criteria WHERE deleted_at IS NULL"),
            'total_surveys'   => (int)$this->db->fetchValue("SELECT COUNT(*) FROM surveys WHERE deleted_at IS NULL"),
            'active_surveys'  => (int)$this->db->fetchValue("SELECT COUNT(*) FROM surveys WHERE deleted_at IS NULL AND status = 'published'"),
            'total_responses' => (int)$this->db->fetchValue("SELECT COUNT(*) FROM survey_responses WHERE status = 'submitted'"),
            'draft_surveys'   => (int)$this->db->fetchValue("SELECT COUNT(*) FROM surveys WHERE deleted_at IS NULL AND status = 'draft'"),
            'closed_surveys'  => (int)$this->db->fetchValue("SELECT COUNT(*) FROM surveys WHERE deleted_at IS NULL AND status IN ('closed', 'archived')"),
            'total_groups'    => (int)$this->db->fetchValue("SELECT COUNT(*) FROM kpi_groups WHERE deleted_at IS NULL"),
            'total_evals'     => (int)$this->db->fetchValue("SELECT COUNT(*) FROM evaluations"),
            'locked_users'    => (int)$this->db->fetchValue("SELECT COUNT(*) FROM users WHERE deleted_at IS NULL AND status = 0"),
            'avg_quality'     => round((float)($this->db->fetchValue("SELECT AVG(normalized_score) FROM evaluations WHERE normalized_score IS NOT NULL") ?? 0), 2),
        ];
    }

    private function getRecentSurveys(int $limit = 8): array
    {
        return $this->db->fetchAll(
            "SELECT s.id, s.title, s.status, s.created_at,
                    (SELECT COUNT(*) FROM survey_responses WHERE survey_id = s.id AND status = 'submitted') AS response_count
             FROM surveys s
             WHERE s.deleted_at IS NULL
             ORDER BY s.created_at DESC
             LIMIT ?",
            [$limit]
        );
    }

    /** Khảo sát đang mở kèm tiến độ phản hồi và hạn đóng. */
    private function getActiveSurveys(int $limit = 6): array
    {
        return $this->db->fetchAll(
            "SELECT s.id, s.title, s.end_date,
                    (SELECT COUNT(*) FROM survey_responses WHERE survey_id = s.id AND status = 'submitted') AS completed,
                    (SELECT COUNT(*) FROM survey_responses WHERE survey_id = s.id) AS total
             FROM surveys s
             WHERE s.deleted_at IS NULL AND s.status = 'published'
             ORDER BY s.end_date IS NULL, s.end_date ASC, s.created_at DESC
             LIMIT ?",
            [$limit]
        );
    }

    /** Hoạt động mới nhất trong hệ thống (chỉ người có quyền xem nhật ký). */
    private function getRecentActivity(int $limit = 8): array
    {
        return $this->db->fetchAll(
            "SELECT a.action, a.module, a.description, a.created_at, u.full_name AS user_name
             FROM audit_logs a
             LEFT JOIN users u ON u.id = a.user_id
             ORDER BY a.created_at DESC, a.id DESC
             LIMIT ?",
            [$limit]
        );
    }

    private function getKpiScores(string $period = '', int $kpiId = 0, int $limit = 10): array
    {
        $where = '1=1';
        $params = [];
        if ($period) { $where .= ' AND e.period = ?'; $params[] = $period; }
        if ($kpiId) { $where .= ' AND e.kpi_id = ?'; $params[] = $kpiId; }

        return $this->db->fetchAll(
            "SELECT e.kpi_id, k.name AS kpi_name,
                    AVG(e.normalized_score) AS avg_score,
                    COUNT(*) AS eval_count
             FROM evaluations e
             INNER JOIN kpis k ON e.kpi_id = k.id
             WHERE {$where} AND e.normalized_score IS NOT NULL
             GROUP BY e.kpi_id, k.name
             ORDER BY avg_score DESC
             LIMIT ?",
            array_merge($params, [$limit])
        );
    }

    private function getRecentEvaluations(int $limit = 8): array
    {
        return $this->db->fetchAll(
            "SELECT e.*, k.name AS kpi_name
             FROM evaluations e
             LEFT JOIN kpis k ON e.kpi_id = k.id
             ORDER BY e.calculated_at DESC
             LIMIT ?",
            [$limit]
        );
    }

    private function getTopKpis(int $limit = 5): array
    {
        return $this->db->fetchAll(
            "SELECT k.id, k.name, k.code,
                    AVG(e.normalized_score) AS avg_score
             FROM kpis k
             LEFT JOIN evaluations e ON k.id = e.kpi_id
             WHERE k.deleted_at IS NULL
             GROUP BY k.id, k.name, k.code
             HAVING AVG(e.normalized_score) IS NOT NULL
             ORDER BY avg_score DESC
             LIMIT ?",
            [$limit]
        );
    }

    private function getCompletionRate(): array
    {
        return $this->db->fetchAll(
            "SELECT s.id, s.title,
                    (SELECT COUNT(*) FROM survey_responses WHERE survey_id = s.id AND status = 'submitted') AS completed,
                    (SELECT COUNT(*) FROM survey_responses WHERE survey_id = s.id) AS total
             FROM surveys s
             WHERE s.deleted_at IS NULL AND s.status IN ('published', 'closed')
             ORDER BY s.created_at DESC
             LIMIT 5"
        );
    }

    private function getTrendData(): array
    {
        return $this->db->fetchAll(
            "SELECT DATE_FORMAT(calculated_at, '%Y-%m') AS month,
                    AVG(normalized_score) AS avg_score
             FROM evaluations
             WHERE calculated_at IS NOT NULL AND normalized_score IS NOT NULL
             GROUP BY month
             ORDER BY month ASC
             LIMIT 12"
        );
    }

    private function getDistribution(): array
    {
        return $this->db->fetchAll(
            "SELECT classification, COUNT(*) AS count
             FROM evaluations
             WHERE classification IS NOT NULL
             GROUP BY classification"
        );
    }
}