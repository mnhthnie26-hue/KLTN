<?php
/**
 * KpiController
 */

declare(strict_types=1);

class KpiController
{
    private KpiService $kpiService;
    private KpiRepository $kpiRepo;
    private KpiGroupRepository $groupRepo;

    public function __construct()
    {
        $this->kpiService = new KpiService();
        $this->kpiRepo = new KpiRepository();
        $this->groupRepo = new KpiGroupRepository();
    }

    public function index($params, Request $request, Response $response): void
    {
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 20;

        $filters = [
            'search'        => trim($request->query('search', '')),
            'kpi_group_id'  => $request->query('kpi_group_id', ''),
            'status'        => $request->query('status', ''),
        ];

        $result = $this->kpiService->getKpis($page, $perPage, $filters);
        $groups = $this->groupRepo->getAllActive();

        $data = [
            'pageTitle'  => 'Quản lý KPI',
            'user'       => Auth::user(),
            'kpis'       => $result['items'],
            'pagination' => $result['pagination'],
            'filters'    => $filters,
            'groups'     => $groups,
            'success'    => Session::flash('success'),
            'error'      => Session::flash('error'),
        ];

        echo View::render('kpis/index', $data);
    }

    public function show($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $kpi = $this->kpiService->getKpi($id);

        if (!$kpi) {
            Session::flash('error', 'KPI không tồn tại');
            $response->redirect(url('kpis'))->send();
            return;
        }

        $data = [
            'pageTitle'    => 'Chi tiết KPI: ' . $kpi['name'],
            'user'         => Auth::user(),
            'kpi'          => $kpi,
            'weightValid'  => abs($kpi['total_weight'] - 100) < 0.01,
        ];

        echo View::render('kpis/view', $data);
    }

    public function create($params, Request $request, Response $response): void
    {
        $groups = $this->groupRepo->getAllActive();
        $old = Session::flash('form_data') ?? [];

        $data = [
            'pageTitle'  => 'Tạo KPI',
            'user'       => Auth::user(),
            'groups'     => $groups,
            'kpi'        => $old,
            'csrf_token' => Session::csrfToken(),
            'minScore'   => (float)getSetting('score.default_min', 1),
            'maxScore'   => (float)getSetting('score.default_max', 5),
            'step'       => (float)getSetting('score.default_step', 1),
        ];

        echo View::render('kpis/form', $data);
    }

    public function store($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('kpis/create'))->send();
            return;
        }

        $result = $this->kpiService->createKpi($request->post());

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            Session::flash('form_data', $request->post());
            $response->redirect(url('kpis/create'))->send();
            return;
        }

        Session::flash('success', $result['message']);
        $response->redirect(url('kpis/' . $result['id']))->send();
    }

    public function edit($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $kpi = $this->kpiService->getKpi($id);

        if (!$kpi) {
            Session::flash('error', 'KPI không tồn tại');
            $response->redirect(url('kpis'))->send();
            return;
        }

        $groups = $this->groupRepo->getAllActive();

        $data = [
            'pageTitle'  => 'Sửa KPI',
            'user'       => Auth::user(),
            'kpi'        => $kpi,
            'groups'     => $groups,
            'csrf_token' => Session::csrfToken(),
        ];

        echo View::render('kpis/form', $data);
    }

    public function update($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('kpis'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->kpiService->updateKpi($id, $request->post());

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            $response->redirect(url('kpis/' . $id . '/edit'))->send();
            return;
        }

        Session::flash('success', $result['message']);
        $response->redirect(url('kpis/' . $id))->send();
    }

    public function destroy($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('kpis'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->kpiService->deleteKpi($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('kpis'))->send();
    }
}