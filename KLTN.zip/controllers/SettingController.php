<?php
/**
 * SettingController
 */

declare(strict_types=1);

class SettingController
{
    public function index($params, Request $request, Response $response): void
    {
        $db = Database::getInstance();
        $settings = $db->fetchAll('SELECT * FROM system_settings ORDER BY setting_group, setting_key');

        $grouped = [];
        foreach ($settings as $s) {
            $grouped[$s['setting_group']][] = $s;
        }

        $data = [
            'pageTitle'  => 'Cài đặt Hệ thống',
            'user'       => Auth::user(),
            'grouped'    => $grouped,
            'csrf_token' => Session::csrfToken(),
            'success'    => Session::flash('success'),
            'error'      => Session::flash('error'),
        ];

        echo View::render('settings/index', $data);
    }

    public function update($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('settings'))->send();
            return;
        }

        $settings = (array)$request->post('settings', []);

        try {
            $db = Database::getInstance();
            foreach ($settings as $key => $value) {
                $db->update('system_settings', [
                    'setting_value' => $value,
                ], 'setting_key = :k', ['k' => $key]);
            }
            Logger::getInstance()->audit(AUDIT_UPDATE, 'settings', Auth::id(), null, null, $settings, 'Cập nhật cài đặt');
            Session::flash('success', 'Đã lưu cài đặt');
        } catch (Throwable $e) {
            ErrorLog::error('[SettingController::update] save failed', ['keys' => array_keys($settings ?? [])], $e);
            Session::flash('error', 'Có lỗi xảy ra');
        }

        $response->redirect(url('settings'))->send();
    }
}