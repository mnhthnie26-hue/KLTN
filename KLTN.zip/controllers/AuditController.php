<?php
/**
 * AuditController
 */

declare(strict_types=1);

class AuditController
{
    public function index($params, Request $request, Response $response): void
    {
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 50;
        $filters = [
            'user_id'  => $request->query('user_id', ''),
            'action'   => $request->query('action', ''),
            'module'   => $request->query('module', ''),
        ];

        $where = ['1=1'];
        $sqlParams = [];
        if ($filters['user_id']) { $where[] = 'a.user_id = ?'; $sqlParams[] = (int)$filters['user_id']; }
        if ($filters['action']) { $where[] = 'a.action = ?'; $sqlParams[] = $filters['action']; }
        if ($filters['module']) { $where[] = 'a.module = ?'; $sqlParams[] = $filters['module']; }
        $whereSql = implode(' AND ', $where);

        $db = Database::getInstance();
        $total = (int)$db->fetchValue("SELECT COUNT(*) FROM audit_logs a WHERE {$whereSql}", $sqlParams);
        $offset = ($page - 1) * $perPage;

        $logs = $db->fetchAll(
            "SELECT a.*, u.full_name AS user_name, u.username
             FROM audit_logs a
             LEFT JOIN users u ON a.user_id = u.id
             WHERE {$whereSql}
             ORDER BY a.created_at DESC
             LIMIT {$perPage} OFFSET {$offset}",
            $sqlParams
        );

        $actions = $db->fetchAll("SELECT DISTINCT action FROM audit_logs ORDER BY action");
        $modules = $db->fetchAll("SELECT DISTINCT module FROM audit_logs ORDER BY module");

        $data = [
            'pageTitle'  => 'Nhật ký Hoạt động',
            'user'       => Auth::user(),
            'logs'       => $logs,
            'pagination' => paginate($total, $page, $perPage),
            'filters'    => $filters,
            'actions'    => $actions,
            'modules'    => $modules,
        ];

        echo View::render('audit/index', $data);
    }
}