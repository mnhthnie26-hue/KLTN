<?php
/**
 * SurveyController
 */

declare(strict_types=1);

class SurveyController
{
    private SurveyService $service;
    private SurveyRepository $surveyRepo;
    private ResponseRepository $responseRepo;
    private KpiRepository $kpiRepo;

    public function __construct()
    {
        $this->service = new SurveyService();
        $this->surveyRepo = new SurveyRepository();
        $this->responseRepo = new ResponseRepository();
        $this->kpiRepo = new KpiRepository();
    }

    public function index($params, Request $request, Response $response): void
    {
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 20;
        $filters = [
            'search'  => trim($request->query('search', '')),
            'status'  => $request->query('status', ''),
            'kpi_id'  => $request->query('kpi_id', ''),
        ];

        $result = $this->service->list($page, $perPage, $filters);
        $kpis = $this->kpiRepo->getAllWithGroup();

        $data = [
            'pageTitle'  => 'Quản lý Khảo sát',
            'user'       => Auth::user(),
            'surveys'    => $result['items'],
            'pagination' => $result['pagination'],
            'filters'    => $filters,
            'kpis'       => $kpis,
            'success'    => Session::flash('success'),
            'error'      => Session::flash('error'),
        ];

        echo View::render('surveys/index', $data);
    }

    public function show($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $survey = $this->service->get($id);

        if (!$survey) {
            Session::flash('error', 'Khảo sát không tồn tại');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $data = [
            'pageTitle' => 'Khảo sát: ' . $survey['title'],
            'user'      => Auth::user(),
            'survey'    => $survey,
        ];

        echo View::render('surveys/view', $data);
    }

    public function create($params, Request $request, Response $response): void
    {
        $kpis = $this->kpiRepo->getAllWithGroup();
        $data = [
            'pageTitle'  => 'Tạo Khảo sát',
            'user'       => Auth::user(),
            'kpis'       => $kpis,
            'old'        => Session::flash('form_data') ?? [],
            'csrf_token' => Session::csrfToken(),
        ];
        echo View::render('surveys/form', $data);
    }

    public function store($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('surveys/create'))->send();
            return;
        }

        $result = $this->service->create($request->post());

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            Session::flash('form_data', $request->post());
            $response->redirect(url('surveys/create'))->send();
            return;
        }

        Session::flash('success', $result['message']);
        $response->redirect(url('surveys/' . $result['id'] . '/questions'))->send();
    }

    public function edit($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $survey = $this->service->get($id);

        if (!$survey) {
            Session::flash('error', 'Khảo sát không tồn tại');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $kpis = $this->kpiRepo->getAllWithGroup();
        $data = [
            'pageTitle'  => 'Sửa Khảo sát',
            'user'       => Auth::user(),
            'survey'     => $survey,
            'kpis'       => $kpis,
            'csrf_token' => Session::csrfToken(),
        ];
        echo View::render('surveys/form', $data);
    }

    public function update($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->service->update($id, $request->post());

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            $response->redirect(url('surveys/' . $id . '/edit'))->send();
            return;
        }

        Session::flash('success', $result['message']);
        $response->redirect(url('surveys/' . $id))->send();
    }

    public function destroy($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->service->delete($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('surveys'))->send();
    }

    public function publish($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->service->publish($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('surveys/' . $id))->send();
    }

    public function close($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->service->close($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('surveys/' . $id))->send();
    }

    public function preview($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $survey = $this->service->get($id);

        if (!$survey) {
            Session::flash('error', 'Khảo sát không tồn tại');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $data = [
            'pageTitle' => 'Xem trước: ' . $survey['title'],
            'user'      => Auth::user(),
            'survey'    => $survey,
            'preview'   => true,
        ];
        echo View::render('surveys/preview', $data);
    }

    public function duplicate($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->service->duplicate($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        if ($result['success']) {
            $response->redirect(url('surveys/' . $result['id'] . '/edit'))->send();
        } else {
            $response->redirect(url('surveys'))->send();
        }
    }

    public function questions($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $survey = $this->service->get($id);

        if (!$survey) {
            Session::flash('error', 'Khảo sát không tồn tại');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $criteria = [];
        if ($survey['kpi_id']) {
            $criteria = (new CriterionRepository())->getByKpi((int)$survey['kpi_id']);
        }

        $data = [
            'pageTitle'  => 'Câu hỏi: ' . $survey['title'],
            'user'       => Auth::user(),
            'survey'     => $survey,
            'criteria'   => $criteria,
            'csrf_token' => Session::csrfToken(),
            'success'    => Session::flash('success'),
            'error'      => Session::flash('error'),
        ];
        echo View::render('surveys/questions', $data);
    }

    public function saveQuestions($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $questions = $request->post('questions', []);

        // Filter empty questions
        $questions = array_values(array_filter($questions, function($q) {
            return !empty($q['question_text']);
        }));

        $result = $this->service->saveQuestions($id, $questions);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('surveys/' . $id . '/questions'))->send();
    }

    public function results($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $survey = $this->service->get($id);

        if (!$survey) {
            Session::flash('error', 'Khảo sát không tồn tại');
            $response->redirect(url('surveys'))->send();
            return;
        }

        $page = max(1, (int)$request->query('page', 1));
        $responsesResult = $this->responseRepo->getBySurvey($id, $page, 20);

        $data = [
            'pageTitle'  => 'Kết quả: ' . $survey['title'],
            'user'       => Auth::user(),
            'survey'     => $survey,
            'responses'  => $responsesResult['items'],
            'pagination' => $responsesResult['pagination'],
        ];
        echo View::render('surveys/results', $data);
    }

    public function take($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $survey = $this->service->get($id);

        if (!$survey) {
            Session::flash('error', 'Khảo sát không tồn tại');
            $response->redirect(url('dashboard'))->send();
            return;
        }

        if ($survey['status'] !== 'published') {
            Session::flash('error', 'Khảo sát chưa được mở');
            $response->redirect(url('dashboard'))->send();
            return;
        }

        // Check if user already responded
        $userId = Auth::id();
        if ($survey['one_response_per_user'] && $userId && $this->responseRepo->hasResponded($id, $userId)) {
            Session::flash('info', 'Bạn đã tham gia khảo sát này rồi');
            $response->redirect(url('dashboard'))->send();
            return;
        }

        $data = [
            'pageTitle'  => $survey['title'],
            'user'       => Auth::user(),
            'survey'     => $survey,
            'csrf_token' => Session::csrfToken(),
        ];
        echo View::render('surveys/take', $data);
    }

    public function submitResponse($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('dashboard'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $survey = $this->service->get($id);

        if (!$survey || $survey['status'] !== 'published') {
            Session::flash('error', 'Khảo sát không khả dụng');
            $response->redirect(url('dashboard'))->send();
            return;
        }

        $userId = Auth::id();
        $answers = (array)$request->post('answers', []);

        // Anti-duplicate check
        if ($survey['one_response_per_user'] && $userId && $this->responseRepo->hasResponded($id, $userId)) {
            Session::flash('error', 'Bạn đã tham gia khảo sát này rồi');
            $response->redirect(url('dashboard'))->send();
            return;
        }

        // Validate required questions
        foreach ($survey['questions'] as $q) {
            if ((int)$q['is_required'] === 1) {
                $answer = $answers[$q['id']] ?? null;
                if (empty($answer) && $answer !== '0') {
                    Session::flash('error', 'Vui lòng trả lời tất cả câu hỏi bắt buộc: ' . $q['question_text']);
                    $response->redirect(url('survey/' . $id . '/take'))->send();
                    return;
                }
            }
        }

        try {
            $db = Database::getInstance();
            $responseId = $db->transaction(function() use ($db, $survey, $userId, $answers, $request) {
                $rid = $db->insert('survey_responses', [
                    'survey_id'      => $survey['id'],
                    'respondent_id'  => $survey['allow_anonymous'] ? null : $userId,
                    'respondent_type'=> $survey['allow_anonymous'] ? 'anonymous' : (Auth::user()['user_type'] ?? null),
                    'started_at'     => date('Y-m-d H:i:s', time() - 60),
                    'submitted_at'   => date('Y-m-d H:i:s'),
                    'status'         => 'submitted',
                    'ip_address'     => $request->ip(),
                    'user_agent'     => $request->userAgent(),
                ]);

                foreach ($survey['questions'] as $q) {
                    $answer = $answers[$q['id']] ?? null;
                    if (empty($answer) && $answer !== '0' && $answer !== '0.0') continue;

                    $score = null;
                    $optionId = null;
                    $answerText = null;
                    $answerNumber = null;

                    switch ($q['question_type']) {
                        case 'single_choice':
                        case 'rating':
                        case 'scale':
                            $optionId = is_numeric($answer) ? (int)$answer : null;
                            // Find option and its value
                            foreach ($q['options'] as $opt) {
                                if ((int)$opt['id'] === $optionId) {
                                    $score = $opt['option_value'];
                                    $answerNumber = $opt['option_value'];
                                    break;
                                }
                            }
                            break;
                        case 'multiple_choice':
                            $optionIds = (array)$answer;
                            // For multi-choice, sum up the values
                            $multiScore = 0;
                            foreach ($q['options'] as $opt) {
                                if (in_array((string)$opt['id'], array_map('strval', $optionIds), true)) {
                                    $multiScore += (float)($opt['option_value'] ?? 0);
                                }
                            }
                            $score = $multiScore;
                            $optionId = !empty($optionIds) ? (int)reset($optionIds) : null;
                            break;
                        case 'number':
                            $answerNumber = (float)$answer;
                            $score = $answerNumber;
                            break;
                        case 'text':
                        case 'textarea':
                            $answerText = Security::sanitize($answer);
                            break;
                    }

                    $db->insert('survey_answers', [
                        'response_id'    => $rid,
                        'question_id'    => $q['id'],
                        'option_id'      => $optionId,
                        'answer_text'    => $answerText,
                        'answer_number'  => $answerNumber,
                        'score'          => $score,
                    ]);
                }

                return $rid;
            });

            Logger::getInstance()->audit(AUDIT_SUBMIT, 'survey', $userId, $survey['id'], null, ['response_id' => $responseId], 'Submit khảo sát');
            Session::flash('success', 'Cảm ơn bạn đã tham gia khảo sát');
            $response->redirect(url('dashboard'))->send();
        } catch (Throwable $e) {
            ErrorLog::error('[SurveyController::submitResponse] failed', ['sid' => $id], $e);
            Session::flash('error', 'Có lỗi xảy ra, vui lòng thử lại');
            $response->redirect(url('survey/' . $id . '/take'))->send();
        }
    }
}