<?php
/**
 * AuthController - Authentication web pages
 */

declare(strict_types=1);

class AuthController
{
    /**
     * Show login form
     */
    public function showLogin($params, Request $request, Response $response): void
    {
        Session::start();

        if (Auth::check()) {
            $response->redirect(url('dashboard'))->send();
            return;
        }

        $data = [
            'pageTitle'   => 'Đăng nhập',
            'error'       => Session::flash('error'),
            'success'     => Session::flash('success'),
            'old'         => Session::flash('form_data') ?? [],
            'appName'     => APP_NAME,
            'csrf_token'  => Session::csrfToken(),
        ];

        echo View::render('auth/login', $data, 'auth');
    }

    /**
     * Process login
     */
    public function login($params, Request $request, Response $response): void
    {
        Session::start();

        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên làm việc đã hết hạn. Vui lòng thử lại.');
            $response->redirect(url('login'))->send();
            return;
        }

        $username = trim($request->post('username', ''));
        $password = $request->post('password', '');
        $remember = (bool)$request->post('remember', false);

        // Validate
        if ($username === '' || $password === '') {
            Session::flash('error', 'Vui lòng nhập đầy đủ thông tin đăng nhập');
            Session::flash('form_data', ['username' => $username]);
            $response->redirect(url('login'))->send();
            return;
        }

        $result = Auth::attempt($username, $password, $remember);

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            Session::flash('form_data', ['username' => $username]);
            $response->redirect(url('login'))->send();
            return;
        }

        // Reset failed attempts on login_logs
        Session::flash('success', 'Đăng nhập thành công');

        // Redirect to intended page
        $intended = Session::get('redirect_after_login');
        if ($intended && str_starts_with($intended, '/')) {
            Session::forget('redirect_after_login');
            $response->redirect($intended)->send();
            return;
        }

        // Check must_change_password
        if (!empty($result['user']['must_change_password'])) {
            Session::flash('warning', 'Vui lòng đổi mật khẩu mặc định');
            $response->redirect(url('change-password'))->send();
            return;
        }

        $response->redirect(url('dashboard'))->send();
    }

    /**
     * Logout
     */
    public function logout($params, Request $request, Response $response): void
    {
        Session::start();
        Auth::logout();
        Session::flash('success', 'Đã đăng xuất');
        $response->redirect(url('login'))->send();
    }

    /**
     * Show change password form
     */
    public function showChangePassword($params, Request $request, Response $response): void
    {
        Session::start();

        if (!Auth::check()) {
            $response->redirect(url('login'))->send();
            return;
        }

        $data = [
            'pageTitle'   => 'Đổi mật khẩu',
            'error'       => Session::flash('error'),
            'success'     => Session::flash('success'),
            'user'        => Auth::user(),
            'csrf_token'  => Session::csrfToken(),
            'appName'     => APP_NAME,
        ];

        // Hiển thị trong layout dashboard (sidebar + header), không còn là trang riêng
        echo View::render('auth/change-password', $data, 'app');
    }

    /**
     * Process change password
     */
    public function changePassword($params, Request $request, Response $response): void
    {
        Session::start();

        if (!Auth::check()) {
            $response->redirect(url('login'))->send();
            return;
        }

        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên làm việc đã hết hạn. Vui lòng thử lại.');
            $response->redirect(url('change-password'))->send();
            return;
        }

        $currentPassword = $request->post('current_password', '');
        $newPassword = $request->post('new_password', '');
        $confirmPassword = $request->post('confirm_password', '');

        // Validate
        $validator = Validator::make([
            'current_password' => $currentPassword,
            'new_password'     => $newPassword,
            'confirm_password' => $confirmPassword,
        ], [
            'current_password' => 'required',
            'new_password'     => 'required|min:' . (int)getSetting('security.password_min_length', 6),
            'confirm_password' => 'required|same:new_password',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $first = reset($errors);
            $msg = $first[0] ?? null;
            if ($msg === null || $msg === '') {
                $msg = 'Đã có lỗi xảy ra';
            }
            Session::flash('error', $msg);
            $response->redirect(url('change-password'))->send();
            return;
        }

        try {
            $result = Auth::changePassword(Auth::id(), $currentPassword, $newPassword);
        } catch (Throwable $e) {
            ErrorLog::error('[AuthController::changePassword] failed', ['uid' => Auth::id()], $e);
            Session::flash('error', 'Đã có lỗi xảy ra khi đổi mật khẩu. Vui lòng thử lại.');
            $response->redirect(url('change-password'))->send();
            return;
        }

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            $response->redirect(url('change-password'))->send();
            return;
        }

        Session::flash('success', 'Đổi mật khẩu thành công. Vui lòng đăng nhập lại.');

        // Force re-login
        Auth::logout();
        $response->redirect(url('login'))->send();
    }
}