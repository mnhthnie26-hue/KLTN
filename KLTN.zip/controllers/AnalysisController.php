<?php
/**
 * AnalysisController
 */

declare(strict_types=1);

class AnalysisController
{
    private StatisticsService $statsService;
    private AHPService $ahpService;
    private RankingService $rankingService;
    private KpiRepository $kpiRepo;

    public function __construct()
    {
        $this->statsService = new StatisticsService();
        $this->ahpService = new AHPService();
        $this->rankingService = new RankingService();
        $this->kpiRepo = new KpiRepository();
    }

    public function statistics($params, Request $request, Response $response): void
    {
        $surveyId = (int)$request->query('survey_id', 0);
        $kpiId = (int)$request->query('kpi_id', 0);
        $surveys = Database::getInstance()->fetchAll(
            'SELECT id, title, kpi_id FROM surveys WHERE deleted_at IS NULL ORDER BY created_at DESC'
        );
        $kpis = $this->kpiRepo->getAllWithGroup();

        $stats = null;
        if ($surveyId) {
            $stats = $this->statsService->getSurveyStatistics($surveyId);
        }

        $data = [
            'pageTitle' => 'Thống kê',
            'user'      => Auth::user(),
            'surveys'   => $surveys,
            'kpis'      => $kpis,
            'surveyId'  => $surveyId,
            'kpiId'     => $kpiId,
            'stats'     => $stats,
        ];

        echo View::render('analysis/statistics', $data);
    }

    public function ahp($params, Request $request, Response $response): void
    {
        $matrixId = (int)$request->query('matrix_id', 0);
        $kpiId = (int)$request->query('kpi_id', 0);

        $matrices = Database::getInstance()->fetchAll(
            'SELECT m.*, k.name AS kpi_name FROM ahp_matrices m LEFT JOIN kpis k ON k.id = m.kpi_id ORDER BY m.created_at DESC'
        );
        $kpis = $this->kpiRepo->getAllWithGroup();
        $currentMatrix = null;
        $criteria = [];
        $saatyScale = $this->ahpService->getSaatyScale();

        if ($matrixId) {
            $currentMatrix = $this->ahpService->getMatrix($matrixId);
            $criteria = Database::getInstance()->fetchAll(
                'SELECT * FROM criteria WHERE id IN (' . implode(',', array_fill(0, count($currentMatrix['criterion_ids']), '?')) . ') AND deleted_at IS NULL',
                $currentMatrix['criterion_ids']
            );
        } elseif ($kpiId) {
            $criteria = (new CriterionRepository())->getByKpi($kpiId);
        }

        $data = [
            'pageTitle'    => 'Phân tích AHP',
            'user'         => Auth::user(),
            'kpis'         => $kpis,
            'criteria'     => $criteria,
            'matrices'     => $matrices,
            'currentKpiId' => $kpiId,
            'currentMatrix'=> $currentMatrix,
            'saatyScale'   => $saatyScale,
            'csrf_token'   => Session::csrfToken(),
            'success'      => Session::flash('success'),
            'error'        => Session::flash('error'),
        ];

        echo View::render('analysis/ahp', $data);
    }

    public function calculateAhp($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('analysis/ahp'))->send();
            return;
        }

        $name = $request->post('name', '');
        $kpiId = !empty($request->post('kpi_id')) ? (int)$request->post('kpi_id') : null;
        $criteriaIds = (array)$request->post('criteria_ids', []);
        $matrixJson = $request->post('matrix', '[]');
        $matrix = json_decode($matrixJson, true);

        if (empty($name) || count($criteriaIds) < 2 || !is_array($matrix)) {
            Session::flash('error', 'Dữ liệu không hợp lệ');
            $response->redirect(url('analysis/ahp'))->send();
            return;
        }

        try {
            $matrixId = $this->ahpService->saveMatrix($name, $kpiId, array_map('intval', $criteriaIds), $matrix);
            Session::flash('success', 'Đã lưu ma trận AHP');
            $response->redirect(url('analysis/ahp?matrix_id=' . $matrixId))->send();
        } catch (Throwable $e) {
            ErrorLog::error('[AnalysisController::calculateAhp] AHP save failed', ['name' => $name, 'kpi_id' => $kpiId], $e);
            Session::flash('error', 'Lỗi: ' . $e->getMessage());
            $response->redirect(url('analysis/ahp'))->send();
        }
    }

    public function ranking($params, Request $request, Response $response): void
    {
        $period = $request->query('period', '');
        $rankType = $request->query('type', 'overall');

        switch ($rankType) {
            case 'kpi':
                $rankings = $this->rankingService->getRankingByKpi($period);
                break;
            case 'criterion':
                $kpiId = (int)$request->query('kpi_id', 0);
                $rankings = $kpiId ? $this->rankingService->getRankingByCriterion($kpiId) : [];
                break;
            default:
                $rankings = $this->rankingService->getOverallRanking(20, $period);
        }

        $kpis = $this->kpiRepo->getAllWithGroup();
        $periods = Database::getInstance()->fetchAll(
            "SELECT DISTINCT period FROM evaluations WHERE period IS NOT NULL AND period != '' ORDER BY period DESC"
        );

        $data = [
            'pageTitle' => 'Xếp hạng',
            'user'      => Auth::user(),
            'rankings'  => $rankings,
            'rankType'  => $rankType,
            'kpiId'     => (int)$request->query('kpi_id', 0),
            'kpis'      => $kpis,
            'period'    => $period,
            'periods'   => $periods,
        ];

        echo View::render('analysis/ranking', $data);
    }
}