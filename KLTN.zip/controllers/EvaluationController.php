<?php
/**
 * EvaluationController
 */

declare(strict_types=1);

class EvaluationController
{
    private EvaluationService $service;
    private KpiRepository $kpiRepo;

    public function __construct()
    {
        $this->service = new EvaluationService();
        $this->kpiRepo = new KpiRepository();
    }

    public function index($params, Request $request, Response $response): void
    {
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 20;
        $filters = [
            'kpi_id' => $request->query('kpi_id', ''),
            'period' => $request->query('period', ''),
        ];

        $result = $this->service->list($page, $perPage, $filters);
        $kpis = $this->kpiRepo->getAllWithGroup();

        $data = [
            'pageTitle'  => 'Đánh giá Chất lượng',
            'user'       => Auth::user(),
            'evaluations'=> $result['items'],
            'pagination' => $result['pagination'],
            'kpis'       => $kpis,
            'filters'    => $filters,
            'success'    => Session::flash('success'),
            'error'      => Session::flash('error'),
        ];

        echo View::render('evaluations/index', $data);
    }

    public function show($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $evaluation = $this->service->get($id);

        if (!$evaluation) {
            Session::flash('error', 'Đánh giá không tồn tại');
            $response->redirect(url('evaluations'))->send();
            return;
        }

        $data = [
            'pageTitle'  => 'Đánh giá: ' . $evaluation['name'],
            'user'       => Auth::user(),
            'evaluation' => $evaluation,
        ];

        echo View::render('evaluations/view', $data);
    }

    public function create($params, Request $request, Response $response): void
    {
        $kpis = $this->kpiRepo->getAllWithGroup();
        $surveys = Database::getInstance()->fetchAll(
            "SELECT id, title, kpi_id FROM surveys WHERE status = 'closed' AND deleted_at IS NULL AND kpi_id IS NOT NULL ORDER BY title"
        );

        $data = [
            'pageTitle'  => 'Tạo Đánh giá',
            'user'       => Auth::user(),
            'kpis'       => $kpis,
            'surveys'    => $surveys,
            'csrf_token' => Session::csrfToken(),
        ];

        echo View::render('evaluations/form', $data);
    }

    public function store($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('evaluations/create'))->send();
            return;
        }

        $surveyId = (int)$request->post('survey_id', 0);
        $period = $request->post('period', '');

        $result = $this->service->calculateForSurvey($surveyId, $period);

        if (!$result) {
            Session::flash('error', 'Không thể tính điểm. Khảo sát phải liên kết với KPI có tiêu chí.');
            $response->redirect(url('evaluations/create'))->send();
            return;
        }

        Session::flash('success', 'Đã tính điểm thành công. Tổng điểm: ' . round((float)$result['normalized_score'], 2));
        $response->redirect(url('evaluations/' . $result['id']))->send();
    }

    public function calculate($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('evaluations'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $evaluation = $this->service->get($id);
        if (!$evaluation) {
            Session::flash('error', 'Đánh giá không tồn tại');
            $response->redirect(url('evaluations'))->send();
            return;
        }

        $result = $this->service->calculateForSurvey((int)$evaluation['survey_id'], $evaluation['period']);
        if ($result) {
            Session::flash('success', 'Đã tính lại điểm');
            $response->redirect(url('evaluations/' . $result['id']))->send();
        } else {
            Session::flash('error', 'Không thể tính lại');
            $response->redirect(url('evaluations/' . $id))->send();
        }
    }
}