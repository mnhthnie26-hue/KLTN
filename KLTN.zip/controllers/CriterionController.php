<?php
/**
 * CriterionController
 */

declare(strict_types=1);

class CriterionController
{
    private CriterionService $service;
    private KpiRepository $kpiRepo;

    public function __construct()
    {
        $this->service = new CriterionService();
        $this->kpiRepo = new KpiRepository();
    }

    public function index($params, Request $request, Response $response): void
    {
        $page = max(1, (int)$request->query('page', 1));
        $perPage = 30;
        $filters = [
            'search'      => trim($request->query('search', '')),
            'kpi_id'      => $request->query('kpi_id', ''),
            'category_id' => $request->query('category_id', ''),
        ];

        $result = $this->service->list($page, $perPage, $filters);
        $kpis = $this->kpiRepo->getAllWithGroup();

        // Group criteria by KPI
        $grouped = [];
        foreach ($result['items'] as $c) {
            $grouped[$c['kpi_id']]['kpi_name'] = $c['kpi_name'];
            $grouped[$c['kpi_id']]['group_name'] = $c['group_name'];
            $grouped[$c['kpi_id']]['criteria'][] = $c;
        }

        $data = [
            'pageTitle'  => 'Quản lý Tiêu chí',
            'user'       => Auth::user(),
            'grouped'    => $grouped,
            'criteria'   => $result['items'],
            'pagination' => $result['pagination'],
            'filters'    => $filters,
            'kpis'       => $kpis,
            'success'    => Session::flash('success'),
            'error'      => Session::flash('error'),
        ];

        echo View::render('criteria/index', $data);
    }

    public function create($params, Request $request, Response $response): void
    {
        $kpiId = (int)$request->query('kpi_id', 0);
        $kpis = $this->kpiRepo->getAllWithGroup();

        $data = [
            'pageTitle'  => 'Tạo Tiêu chí',
            'user'       => Auth::user(),
            'kpis'       => $kpis,
            'kpiId'      => $kpiId,
            'old'        => Session::flash('form_data') ?? [],
            'csrf_token' => Session::csrfToken(),
        ];
        echo View::render('criteria/form', $data);
    }

    public function store($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('criteria/create'))->send();
            return;
        }

        $result = $this->service->create($request->post());

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            Session::flash('form_data', $request->post());
            $response->redirect(url('criteria/create'))->send();
            return;
        }

        Session::flash('success', $result['message']);
        $response->redirect(url('criteria?kpi_id=' . (int)$request->post('kpi_id')))->send();
    }

    public function edit($params, Request $request, Response $response): void
    {
        $id = (int)($params['id'] ?? 0);
        $criterion = (new CriterionRepository())->find($id);

        if (!$criterion) {
            Session::flash('error', 'Tiêu chí không tồn tại');
            $response->redirect(url('criteria'))->send();
            return;
        }

        $kpis = $this->kpiRepo->getAllWithGroup();
        $data = [
            'pageTitle'  => 'Sửa Tiêu chí',
            'user'       => Auth::user(),
            'kpis'       => $kpis,
            'criterion'  => $criterion,
            'csrf_token' => Session::csrfToken(),
        ];
        echo View::render('criteria/form', $data);
    }

    public function update($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('criteria'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->service->update($id, $request->post());

        if (!$result['success']) {
            Session::flash('error', $result['message']);
            $response->redirect(url('criteria/' . $id . '/edit'))->send();
            return;
        }

        Session::flash('success', $result['message']);
        $response->redirect(url('criteria?kpi_id=' . (int)$request->post('kpi_id')))->send();
    }

    public function destroy($params, Request $request, Response $response): void
    {
        if (!CSRF::verify($request)) {
            Session::flash('error', 'Phiên đã hết hạn');
            $response->redirect(url('criteria'))->send();
            return;
        }

        $id = (int)($params['id'] ?? 0);
        $result = $this->service->delete($id);

        Session::flash($result['success'] ? 'success' : 'error', $result['message']);
        $response->redirect(url('criteria'))->send();
    }
}