<?php
/**
 * Response - HTTP Response wrapper
 */

declare(strict_types=1);

class Response
{
    private int $statusCode = 200;
    private array $headers = [];
    private string $content = '';
    private bool $isJson = false;
    private bool $isRedirect = false;
    private ?string $redirectUrl = null;
    private bool $sent = false;

    public function setStatus(int $code): self
    {
        $this->statusCode = $code;
        return $this;
    }

    public function setHeader(string $key, string $value): self
    {
        $this->headers[$key] = $value;
        return $this;
    }

    public function setContent(string $content): self
    {
        $this->content = $content;
        return $this;
    }

    public function json(array $data, int $status = 200): self
    {
        $this->isJson = true;
        $this->statusCode = $status;
        $this->headers['Content-Type'] = 'application/json; charset=utf-8';
        $this->content = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR);
        return $this;
    }

    public function success($data = null, string $message = 'Success', int $status = 200, array $meta = []): self
    {
        return $this->json([
            'success' => true,
            'message' => $message,
            'data'    => $data,
            'meta'    => empty($meta) ? (object)[] : $meta,
        ], $status);
    }

    public function error(string $message = 'Request failed', $errors = null, int $status = 400, $data = null): self
    {
        return $this->json([
            'success' => false,
            'message' => $message,
            'data'    => $data,
            'errors'  => $errors,
        ], $status);
    }

    /**
     * 204 No Content response (for DELETE etc.).
     */
    public function noContent(int $status = 204): self
    {
        $this->statusCode = $status;
        $this->content = '';
        return $this;
    }

    /**
     * Set a Set-Cookie header.
     *
     * @param array $options Same shape as PHP's setcookie() (expires/path/domain/secure/httponly/samesite)
     */
    public function withCookie(string $name, string $value, array $options = []): self
    {
        $defaults = [
            'expires'  => 0,
            'path'     => '/',
            'domain'   => '',
            'secure'   => APP_ENV === 'production',
            'httponly' => true,
            'samesite' => 'Lax',
        ];
        $opts = array_merge($defaults, $options);
        $parts = [sprintf('%s=%s', $name, rawurlencode($value))];
        if ((int)$opts['expires'] > 0) {
            $parts[] = 'expires=' . gmdate('D, d M Y H:i:s', (int)$opts['expires']) . ' GMT';
        }
        $parts[] = 'path=' . $opts['path'];
        if ($opts['domain'] !== '') $parts[] = 'domain=' . $opts['domain'];
        if ($opts['secure']) $parts[] = 'secure';
        if ($opts['httponly']) $parts[] = 'httponly';
        $parts[] = 'samesite=' . $opts['samesite'];
        $this->headers['Set-Cookie'] = implode('; ', $parts);
        return $this;
    }

    public function redirect(string $url, int $status = 302): self
    {
        $this->isRedirect = true;
        $this->redirectUrl = $url;
        $this->statusCode = $status;
        return $this;
    }

    public function view(string $viewPath, array $data = [], string $layout = 'app'): self
    {
        $content = View::render($viewPath, $data, $layout);
        $this->content = $content;
        return $this;
    }

    public function send(): void
    {
        if ($this->sent) {
            return;
        }
        $this->sent = true;

        if ($this->isRedirect) {
            if (!headers_sent()) {
                http_response_code($this->statusCode);
                header('Location: ' . $this->redirectUrl);
            }
            exit;
        }

        if (!headers_sent()) {
            http_response_code($this->statusCode);
            foreach ($this->headers as $key => $value) {
                header($key . ': ' . $value, true);
            }
        }

        echo $this->content;
    }

    public function status(): int { return $this->statusCode; }
    public function body(): string { return $this->content; }
    public function isSent(): bool { return $this->sent; }
}