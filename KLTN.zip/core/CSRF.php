<?php
/**
 * CSRF Protection
 */

declare(strict_types=1);

class CSRF
{
    public static function token(): string
    {
        Session::start();
        return Session::csrfToken();
    }

    public static function field(): string
    {
        return sprintf('<input type="hidden" name="_csrf_token" value="%s">', self::token());
    }

    public static function meta(): string
    {
        return sprintf('<meta name="csrf-token" content="%s">', self::token());
    }

    public static function header(): string
    {
        return 'X-CSRF-Token: ' . self::token();
    }

    public static function verify(Request $request): bool
    {
        // GET / HEAD / OPTIONS don't need CSRF
        if (in_array($request->method(), ['GET', 'HEAD', 'OPTIONS'], true)) {
            return true;
        }

        Session::start();

        // Token can come from form field, JSON body, custom header, or Authorization.
        $token = $request->input('_csrf_token')
                 ?? $request->header('x-csrf-token')
                 ?? $request->header('csrf-token');

        // Some apps pass CSRF in Authorization as "Bearer <token>".
        if (empty($token)) {
            $auth = $request->header('authorization');
            if ($auth && preg_match('/Bearer\s+(.+)/i', $auth, $m)) {
                $token = trim($m[1]);
            }
        }

        if (!is_string($token) || $token === '') {
            return false;
        }

        return Session::verifyCsrf($token);
    }

    /**
     * Middleware handler to verify CSRF
     */
    public function handle(Request $request, Response $response): bool
    {
        if (!self::verify($request)) {
            if ($request->isAjax() || str_starts_with($request->path(), '/api/')) {
                $response->error('CSRF token mismatch', null, 419)->send();
                return false;
            }
            http_response_code(419);
            echo '<h1>419 - Page Expired</h1>';
            echo '<p>Phiên làm việc đã hết hạn hoặc CSRF token không hợp lệ.</p>';
            echo '<p><a href="' . htmlspecialchars($_SERVER['HTTP_REFERER'] ?? '/') . '">Quay lại</a></p>';
            return false;
        }
        return true;
    }
}