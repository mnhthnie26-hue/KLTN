<?php
/**
 * Session - Session Manager
 */

declare(strict_types=1);

class Session
{
    private static bool $started = false;

    public static function start(): void
    {
        if (self::$started) {
            return;
        }

        if (session_status() === PHP_SESSION_ACTIVE) {
            self::$started = true;
            return;
        }

        // Session cookie params
        $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || APP_ENV === 'production';

        session_name(SESSION_NAME);
        session_set_cookie_params([
            'lifetime' => SESSION_LIFETIME,
            'path'     => '/',
            'domain'   => '',
            'secure'   => $secure,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);

        ini_set('session.use_strict_mode', '1');
        ini_set('session.use_only_cookies', '1');

        session_start();

        self::$started = true;

        // Validate session - check expiration
        if (self::has('auth.id') && self::has('auth.expires_at')) {
            if (time() > (int)self::get('auth.expires_at')) {
                self::destroy();
                self::start();
            }
        }

        // Session hijack prevention
        if (self::has('fingerprint')) {
            $currentFingerprint = self::fingerprint();
            if (!hash_equals(self::get('fingerprint'), $currentFingerprint)) {
                self::destroy();
                self::start();
            }
        }
    }

    public static function set(string $key, $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function get(string $key, $default = null)
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public static function forget(string $key): void
    {
        unset($_SESSION[$key]);
    }

    public static function regenerate(): void
    {
        if (self::$started) {
            session_regenerate_id(true);
        }
    }

    public static function destroy(): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            $_SESSION = [];

            if (ini_get("session.use_cookies")) {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(),
                    '',
                    time() - 42000,
                    $params["path"],
                    $params["domain"],
                    $params["secure"],
                    $params["httponly"]
                );
            }

            session_destroy();
            self::$started = false;
        }
    }

    public static function flash(string $key, $value = null)
    {
        if (func_num_args() === 2) {
            if (is_array($value) || is_object($value)) {
                $_SESSION['_flash'][$key] = $value;
            } else {
                $_SESSION['_flash'][$key] = $value;
            }
            return null;
        }

        if (isset($_SESSION['_flash'][$key])) {
            $value = $_SESSION['_flash'][$key];
            unset($_SESSION['_flash'][$key]);
            return $value;
        }

        return null;
    }

    public static function csrfToken(): string
    {
        if (!self::has('_csrf_token')) {
            self::set('_csrf_token', Security::randomToken(32));
        }
        return self::get('_csrf_token');
    }

    public static function verifyCsrf(?string $token): bool
    {
        $stored = self::get('_csrf_token');
        if ($stored === null || $token === null) {
            return false;
        }
        return hash_equals($stored, $token);
    }

    public static function regenerateCsrf(): void
    {
        self::set('_csrf_token', Security::randomToken(32));
    }

    private static function fingerprint(): string
    {
        $ua = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        $ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
        return hash('sha256', $ua . '|' . $ip);
    }
}