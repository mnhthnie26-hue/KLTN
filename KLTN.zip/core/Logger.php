<?php
/**
 * Logger - Application & Audit Logger.
 *
 * Routes every write through ErrorLog so we always have a request ID,
 * context, and a fallback to error_log().
 */

declare(strict_types=1);

class Logger
{
    public const LEVEL_DEBUG = 'debug';
    public const LEVEL_INFO  = 'info';
    public const LEVEL_WARN  = 'warn';
    public const LEVEL_ERROR = 'error';

    private string $logDir;

    public function __construct()
    {
        $this->logDir = STORAGE_PATH . '/logs';
        if (!is_dir($this->logDir)) {
            @mkdir($this->logDir, 0755, true);
        }
    }

    /**
     * Write a single log line to the daily file. Always funnels through ErrorLog
     * so request ID + extras are included.
     */
    public function log(string $level, string $message, array $context = []): void
    {
        // Make sure ErrorLog has a request ID even if nobody called init().
        if (class_exists('ErrorLog')) {
            ErrorLog::init();
        }

        $entry = [
            'time'    => date('Y-m-d H:i:s'),
            'level'   => strtoupper($level),
            'message' => $message,
            'context' => $context,
        ];

        // 1) Write to the daily file.
        try {
            $date = date('Y-m-d');
            $logFile = $this->logDir . "/app-{$date}.log";
            $line = json_encode($entry, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n";
            @file_put_contents($logFile, $line, FILE_APPEND | LOCK_EX);
        } catch (Throwable $e) {
            // Don't let logging crash the request.
            error_log('[Logger] failed to write log file: ' . $e->getMessage());
        }

        // 2) Errors also bubble up to error_log so hosting-level alert systems see them.
        if (in_array($level, [self::LEVEL_ERROR, self::LEVEL_WARN], true)) {
            error_log(sprintf('[%s][%s] %s %s',
                $entry['level'],
                $context['rid'] ?? '-',
                $message,
                json_encode($context, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
            ));
        }
    }

    public function info(string $message, array $context = []): void { $this->log(self::LEVEL_INFO, $message, $context); }
    public function warn(string $message, array $context = []): void { $this->log(self::LEVEL_WARN, $message, $context); }
    public function error(string $message, array $context = []): void { $this->log(self::LEVEL_ERROR, $message, $context); }
    public function debug(string $message, array $context = []): void
    {
        if (APP_DEBUG) $this->log(self::LEVEL_DEBUG, $message, $context);
    }

    /**
     * Log action to audit_logs table.
     *
     * Failures are swallowed so that audit logging never breaks business logic.
     * The swallow is logged via ErrorLog so we still see WHY the audit failed.
     */
    public function audit(
        string $action,
        string $module,
        ?int $userId = null,
        ?int $targetId = null,
        $oldData = null,
        $newData = null,
        ?string $description = null,
        ?string $ipAddress = null,
        ?string $userAgent = null
    ): void {
        try {
            $db = Database::getInstance();
            $db->insert('audit_logs', [
                'user_id'     => $userId,
                'action'      => $action,
                'module'      => $module,
                'target_id'   => $targetId,
                'old_data'    => $oldData !== null ? json_encode($oldData, JSON_UNESCAPED_UNICODE) : null,
                'new_data'    => $newData !== null ? json_encode($newData, JSON_UNESCAPED_UNICODE) : null,
                'ip_address'  => $ipAddress ?? ($_SERVER['REMOTE_ADDR'] ?? null),
                'user_agent'  => $userAgent ?? substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
                'description' => $description,
            ]);
        } catch (Throwable $e) {
            ErrorLog::error('[audit] insert failed', [
                'action'      => $action,
                'module'      => $module,
                'target_id'   => $targetId,
            ], $e);
        }
    }

    /**
     * Log a login attempt.
     */
    public function logLogin(?int $userId, string $username, bool $success, ?string $reason = null, ?string $ip = null): void
    {
        try {
            Database::getInstance()->insert('login_logs', [
                'user_id'        => $userId,
                'username'       => $username,
                'ip_address'     => $ip ?? ($_SERVER['REMOTE_ADDR'] ?? ''),
                'user_agent'     => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
                'success'        => $success ? 1 : 0,
                'failure_reason' => $reason,
            ]);
        } catch (Throwable $e) {
            ErrorLog::error('[login_log] insert failed', [
                'username' => $username,
                'success'  => $success,
                'reason'   => $reason,
            ], $e);
        }
    }

    public static function getInstance(): Logger
    {
        static $instance = null;
        if ($instance === null) {
            $instance = new self();
        }
        return $instance;
    }
}