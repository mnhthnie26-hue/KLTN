<?php
/**
 * Validator - Input validation
 */

declare(strict_types=1);

class Validator
{
    private array $data;
    private array $rules;
    private array $errors = [];
    private array $validated = [];
    private bool $ran = false;

    public function __construct(array $data, array $rules)
    {
        $this->data = $data;
        $this->rules = $rules;
    }

    public static function make(array $data, array $rules): self
    {
        return new self($data, $rules);
    }

    /**
     * Run validation. Idempotent: subsequent calls are no-ops until a fresh Validator is built.
     */
    public function validate(): bool
    {
        if ($this->ran) {
            return empty($this->errors);
        }
        $this->ran = true;
        $this->errors = [];
        $this->validated = [];

        foreach ($this->rules as $field => $ruleString) {
            $rules = explode('|', (string)$ruleString);
            $value = $this->data[$field] ?? null;

            // 'nullable' rule lets the value be null and skips other rules.
            if (in_array('nullable', $rules, true) && ($value === null || $value === '')) {
                continue;
            }

            foreach ($rules as $rule) {
                $this->applyRule($field, $value, $rule);
            }

            if (!isset($this->errors[$field])) {
                $this->validated[$field] = $value;
            }
        }
        return empty($this->errors);
    }

    public function fails(): bool
    {
        return !$this->validate();
    }

    public function passes(): bool
    {
        return $this->validate();
    }

    public function errors(): array
    {
        // Run validation if not done yet so callers always see errors.
        $this->validate();
        return $this->errors;
    }

    public function validated(): array
    {
        $this->validate();
        return $this->validated;
    }

    public function first(string $field): ?string
    {
        $errors = $this->errors();
        return $errors[$field][0] ?? null;
    }

    /**
     * Flatten errors into a "field => firstError" map (used by toasts / simple forms).
     */
    public function flatErrors(): array
    {
        $out = [];
        foreach ($this->errors() as $field => $msgs) {
            $out[$field] = $msgs[0] ?? '';
        }
        return $out;
    }

    private function applyRule(string $field, $value, string $rule): void
    {
        $params = '';
        if (str_contains($rule, ':')) {
            [$rule, $params] = explode(':', $rule, 2);
        }
        $paramsArray = $params !== '' ? explode(',', $params) : [];

        switch ($rule) {
            case 'required':
                if ($value === null || $value === '' || (is_array($value) && empty($value))) {
                    $this->errors[$field][] = 'Trường này là bắt buộc';
                }
                break;

            case 'nullable':
                // No-op; handled in validate().
                break;

            case 'string':
                if ($value !== null && !is_string($value)) {
                    $this->errors[$field][] = 'Phải là chuỗi';
                }
                break;

            case 'integer':
            case 'int':
                if ($value !== null && filter_var($value, FILTER_VALIDATE_INT) === false) {
                    $this->errors[$field][] = 'Phải là số nguyên';
                }
                break;

            case 'numeric':
                if ($value !== null && !is_numeric($value)) {
                    $this->errors[$field][] = 'Phải là số';
                }
                break;

            case 'boolean':
            case 'bool':
                if ($value !== null && !is_bool($value) && !in_array($value, [0, 1, '0', '1', 'true', 'false'], true)) {
                    $this->errors[$field][] = 'Phải là boolean';
                }
                break;

            case 'email':
                if ($value !== null && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
                    $this->errors[$field][] = 'Email không hợp lệ';
                }
                break;

            case 'url':
                if ($value !== null && $value !== '' && !filter_var($value, FILTER_VALIDATE_URL)) {
                    $this->errors[$field][] = 'URL không hợp lệ';
                }
                break;

            case 'date':
                if ($value !== null && $value !== '' && strtotime((string)$value) === false) {
                    $this->errors[$field][] = 'Ngày không hợp lệ';
                }
                break;

            case 'min':
                $min = (int)($paramsArray[0] ?? 0);
                if (is_string($value) && mb_strlen($value) < $min) {
                    $this->errors[$field][] = "Tối thiểu {$min} ký tự";
                } elseif (is_numeric($value) && $value < $min) {
                    $this->errors[$field][] = "Giá trị tối thiểu là {$min}";
                } elseif (is_array($value) && count($value) < $min) {
                    $this->errors[$field][] = "Tối thiểu {$min} phần tử";
                }
                break;

            case 'max':
                $max = (int)($paramsArray[0] ?? 0);
                if (is_string($value) && mb_strlen($value) > $max) {
                    $this->errors[$field][] = "Tối đa {$max} ký tự";
                } elseif (is_numeric($value) && $value > $max) {
                    $this->errors[$field][] = "Giá trị tối đa là {$max}";
                } elseif (is_array($value) && count($value) > $max) {
                    $this->errors[$field][] = "Tối đa {$max} phần tử";
                }
                break;

            case 'between':
                $min = (float)($paramsArray[0] ?? 0);
                $max = (float)($paramsArray[1] ?? 0);
                if (is_numeric($value) && ($value < $min || $value > $max)) {
                    $this->errors[$field][] = "Giá trị phải từ {$min} đến {$max}";
                }
                break;

            case 'in':
                if ($value !== null && !in_array($value, $paramsArray, true)) {
                    $this->errors[$field][] = 'Giá trị không hợp lệ';
                }
                break;

            case 'not_in':
                if ($value !== null && in_array($value, $paramsArray, true)) {
                    $this->errors[$field][] = 'Giá trị không được phép';
                }
                break;

            case 'regex':
                if ($value !== null && $value !== '' && !preg_match($params, (string)$value)) {
                    $this->errors[$field][] = 'Định dạng không hợp lệ';
                }
                break;

            case 'same':
                $other = $paramsArray[0] ?? '';
                if ($value !== ($this->data[$other] ?? null)) {
                    $this->errors[$field][] = 'Giá trị không khớp';
                }
                break;

            case 'confirmed':
                // expects $field . '_confirmation' in data
                if ($value !== ($this->data[$field . '_confirmation'] ?? null)) {
                    $this->errors[$field][] = 'Xác nhận không khớp';
                }
                break;

            case 'unique':
                $table = $paramsArray[0] ?? '';
                $column = $paramsArray[1] ?? $field;
                $except = isset($paramsArray[2]) ? (int)$paramsArray[2] : null;
                if ($value !== null && $value !== '' && $this->checkUnique($table, $column, $value, $except)) {
                    $this->errors[$field][] = 'Giá trị đã tồn tại';
                }
                break;

            case 'exists':
                $table = $paramsArray[0] ?? '';
                $column = $paramsArray[1] ?? 'id';
                if ($value !== null && $value !== '' && !$this->checkExists($table, $column, $value)) {
                    $this->errors[$field][] = 'Giá trị không tồn tại';
                }
                break;

            case 'username':
                if ($value !== null && $value !== '' && !preg_match('/^[a-zA-Z0-9._-]+$/', (string)$value)) {
                    $this->errors[$field][] = 'Tên đăng nhập chỉ chứa chữ, số, dấu chấm, gạch dưới, gạch ngang';
                }
                break;

            case 'phone':
                if ($value !== null && $value !== '' && !preg_match('/^[0-9+\-\s()]{8,20}$/', (string)$value)) {
                    $this->errors[$field][] = 'Số điện thoại không hợp lệ';
                }
                break;
        }
    }

    private function checkUnique(string $table, string $column, $value, ?int $exceptId = null): bool
    {
        try {
            $sql = "SELECT COUNT(*) FROM `{$table}` WHERE `{$column}` = ?";
            $params = [$value];
            if ($exceptId !== null) {
                $sql .= " AND id != ?";
                $params[] = $exceptId;
            }
            $count = Database::getInstance()->fetchValue($sql, $params);
            return $count > 0;
        } catch (Throwable $e) {
            ErrorLog::error('[Validator::validateUnique] DB lookup failed', [
                'table' => $table, 'column' => $column,
            ], $e);
            return false;
        }
    }

    private function checkExists(string $table, string $column, $value): bool
    {
        try {
            $sql = "SELECT COUNT(*) FROM `{$table}` WHERE `{$column}` = ? LIMIT 1";
            $count = Database::getInstance()->fetchValue($sql, [$value]);
            return $count > 0;
        } catch (Throwable $e) {
            ErrorLog::error('[Validator::checkExists] DB lookup failed', [
                'table' => $table, 'column' => $column,
            ], $e);
            return false;
        }
    }
}