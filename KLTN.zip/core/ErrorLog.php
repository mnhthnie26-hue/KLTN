<?php
/**
 * ErrorLog - Centralized logging facade.
 *
 * All logging in the codebase should funnel through this class. It guarantees:
 * - Every log entry has a unique request ID (so you can grep one request's logs).
 * - Every entry includes file, line, class, function, and a structured context.
 * - Falls back to error_log() if the Logger singleton is unavailable.
 * - Severity levels (debug/info/warn/error/critical) map to Logger constants.
 *
 * Usage:
 *   ErrorLog::error('Failed to send email', ['to' => 'user@example.com'], $e);
 *   ErrorLog::warning('Cache miss', ['key' => 'foo']);
 */

declare(strict_types=1);

class ErrorLog
{
    /** Per-request unique ID, available in every log entry written by this class. */
    private static ?string $requestId = null;

    /** User id of the current request, if known (set by Auth bootstrap). */
    private static ?int $userId = null;

    private static ?float $startedAt = null;

    /**
     * Initialize the request-scoped context. Call once at request start.
     */
    public static function init(?int $userId = null): void
    {
        if (self::$requestId === null) {
            self::$requestId = self::generateRequestId();
        }
        if ($userId !== null) {
            self::$userId = $userId;
        }
        if (self::$startedAt === null) {
            self::$startedAt = microtime(true);
        }
    }

    public static function setUser(?int $userId): void
    {
        self::$userId = $userId;
    }

    public static function requestId(): string
    {
        if (self::$requestId === null) {
            self::$requestId = self::generateRequestId();
        }
        return self::$requestId;
    }

    public static function uptime(): float
    {
        if (self::$startedAt === null) return 0.0;
        return microtime(true) - self::$startedAt;
    }

    /**
     * Build a context array that is automatically attached to every entry.
     */
    private static function baseContext(array $extra = []): array
    {
        $ctx = [
            'rid'  => self::requestId(),
            'time' => self::uptime(),
        ];
        if (self::$userId !== null) {
            $ctx['uid'] = self::$userId;
        }
        if (!empty($_SERVER['REQUEST_METHOD'] ?? null)) {
            $ctx['method'] = $_SERVER['REQUEST_METHOD'];
            $ctx['path']   = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
        }
        return array_merge($ctx, $extra);
    }

    public static function debug(string $message, array $context = []): void
    {
        self::write('debug', $message, $context);
    }

    public static function info(string $message, array $context = []): void
    {
        self::write('info', $message, $context);
    }

    public static function warning(string $message, array $context = [], ?Throwable $e = null): void
    {
        if ($e !== null) {
            $context['exception'] = self::describeException($e);
        }
        self::write('warn', $message, $context);
    }

    public static function warn(string $message, array $context = [], ?Throwable $e = null): void
    {
        self::warning($message, $context, $e);
    }

    public static function error(string $message, array $context = [], ?Throwable $e = null): void
    {
        if ($e !== null) {
            $context['exception'] = self::describeException($e);
        }
        self::write('error', $message, $context);
    }

    public static function critical(string $message, array $context = [], ?Throwable $e = null): void
    {
        if ($e !== null) {
            $context['exception'] = self::describeException($e);
        }
        self::write('error', '[CRITICAL] ' . $message, $context);
    }

    /**
     * Convenience: log + rethrow nothing. Just a "this happened" hook.
     */
    public static function exception(Throwable $e, string $message = '', array $context = []): void
    {
        self::error($message !== '' ? $message : $e->getMessage(), $context, $e);
    }

    /**
     * Pretty-print an exception so we always have file/line/trace in logs.
     */
    public static function describeException(Throwable $e): array
    {
        return [
            'type'    => get_class($e),
            'message' => $e->getMessage(),
            'file'    => $e->getFile(),
            'line'    => $e->getLine(),
            'code'    => (string)$e->getCode(),
            // First 5 frames is enough context without bloating every log.
            'trace'   => array_slice(explode("\n", $e->getTraceAsString()), 0, 8),
            'previous'=> $e->getPrevious() ? [
                'type'    => get_class($e->getPrevious()),
                'message' => $e->getPrevious()->getMessage(),
            ] : null,
        ];
    }

    /**
     * Write through Logger singleton. If unavailable (e.g. very early bootstrap), fall back to error_log.
     */
    private static function write(string $level, string $message, array $context): void
    {
        $ctx = self::baseContext($context);

        if (class_exists('Logger')) {
            try {
                $logger = Logger::getInstance();
                $logger->log($level, $message, $ctx);
                return;
            } catch (Throwable $inner) {
                // Fall through to error_log below.
            }
        }
        // Last resort. Still includes the request ID so logs are grep-able.
        error_log(sprintf('[%s][%s][%s] %s %s',
            strtoupper($level),
            self::requestId(),
            date('Y-m-d H:i:s'),
            $message,
            json_encode($ctx, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        ));
    }

    private static function generateRequestId(): string
    {
        try {
            return bin2hex(random_bytes(8));
        } catch (Throwable $e) {
            return substr(md5(uniqid((string)mt_rand(), true)), 0, 16);
        }
    }
}