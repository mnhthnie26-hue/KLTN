<?php
/**
 * Database - PDO Singleton
 */

declare(strict_types=1);

class Database
{
    private static ?Database $instance = null;
    private PDO $pdo;
    private array $config;

    // Reserved column names that must NEVER be bound from user input.
    private const RESERVED_KEYS = ['created_at', 'updated_at', 'deleted_at'];

    private function __construct()
    {
        $this->config = require __DIR__ . '/../config/database.php';

        $dsn = sprintf(
            'mysql:dbname=%s;charset=%s',
            $this->config['database'],
            $this->config['charset']
        );

        try {
            $this->pdo = new PDO(
                $dsn,
                $this->config['username'],
                $this->config['password'],
                $this->config['options']
            );

            $this->pdo->exec("SET time_zone = '+07:00'");
            $this->pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
        } catch (PDOException $e) {
            if (APP_DEBUG) {
                throw $e;
            }
            ErrorLog::critical('[Database::__construct] connect failed', ['dsn' => $dsn], $e);
            throw new RuntimeException('Không thể kết nối cơ sở dữ liệu');
        }
    }

    public static function getInstance(): Database
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function pdo(): PDO
    {
        return $this->pdo;
    }

    /**
     * Execute a query and return PDOStatement
     */
    public function query(string $sql, array $params = []): PDOStatement
    {
        try {
            $stmt = $this->pdo->prepare($sql);
            if (!empty($params)) {
                foreach ($params as $key => $value) {
                    $param = is_int($key) ? $key + 1 : ':' . ltrim((string)$key, ':');
                    $this->bindParam($stmt, $param, $value);
                }
            }
            $stmt->execute();
            return $stmt;
        } catch (PDOException $e) {
            ErrorLog::error('[DB::query] failed', [
                'sql'    => $sql,
                'params' => $params,
            ], $e);
            throw new RuntimeException('Query failed: ' . $e->getMessage(), (int)$e->getCode(), $e);
        }
    }

    /**
     * Fetch a single row.
     *
     * @return array<string,mixed>|null
     */
    public function fetchOne(string $sql, array $params = []): ?array
    {
        $stmt = $this->query($sql, $params);
        $row = $stmt->fetch();
        return $row === false ? null : $row;
    }

    /**
     * Fetch all rows.
     *
     * @return array<int,array<string,mixed>>
     */
    public function fetchAll(string $sql, array $params = []): array
    {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }

    /**
     * Fetch a single scalar value.
     *
     * @return mixed null if no row, otherwise the column value
     */
    public function fetchValue(string $sql, array $params = [])
    {
        $stmt = $this->query($sql, $params);
        $value = $stmt->fetchColumn();
        return $value === false ? null : $value;
    }

    /**
     * Execute INSERT and return last insert id.
     *
     * @param string $table Target table. Column names are validated against the schema when possible.
     * @param array  $data  Associative array of column => value. Reserved keys are stripped silently.
     * @return int          The inserted row's primary key.
     * @throws RuntimeException on SQL failure (with detailed logging).
     */
    public function insert(string $table, array $data): int
    {
        $data = $this->stripReservedKeys($data);
        $columns = array_keys($data);
        if (empty($columns)) {
            throw new InvalidArgumentException('insert(): data array is empty');
        }

        $placeholders = array_map(fn($c) => ':' . $c, $columns);

        $sql = sprintf(
            'INSERT INTO `%s` (`%s`) VALUES (%s)',
            $table,
            implode('`, `', $columns),
            implode(', ', $placeholders)
        );

        try {
            $stmt = $this->pdo->prepare($sql);
            foreach ($data as $key => $value) {
                $this->bindParam($stmt, ':' . $key, $value);
            }
            $stmt->execute();
            return (int)$this->pdo->lastInsertId();
        } catch (PDOException $e) {
            ErrorLog::error('[DB::insert] failed', [
                'table' => $table, 'data' => $data,
            ], $e);
            throw new RuntimeException('Insert failed: ' . $e->getMessage(), (int)$e->getCode(), $e);
        }
    }

    /**
     * Execute UPDATE and return affected rows.
     *
     * @param string $table       Target table.
     * @param array  $data        Associative array column => value.
     * @param string $where        WHERE clause with named placeholders (e.g. "id = :id").
     * @param array  $whereParams  Values for placeholders in $where.
     * @return int                Number of affected rows.
     * @throws RuntimeException on SQL failure.
     */
    public function update(string $table, array $data, string $where, array $whereParams = []): int
    {
        $data = $this->stripReservedKeys($data);
        if (empty($data)) {
            throw new InvalidArgumentException('update(): data array is empty');
        }

        $sets = [];
        foreach ($data as $key => $value) {
            $sets[] = sprintf('`%s` = :%s', $key, $key);
        }

        $sql = sprintf('UPDATE `%s` SET %s WHERE %s', $table, implode(', ', $sets), $where);

        try {
            $stmt = $this->pdo->prepare($sql);
            foreach ($data as $key => $value) {
                $this->bindParam($stmt, ':' . $key, $value);
            }
            foreach ($whereParams as $key => $value) {
                $param = ':' . ltrim((string)$key, ':');
                $this->bindParam($stmt, $param, $value);
            }
            $stmt->execute();
            return $stmt->rowCount();
        } catch (PDOException $e) {
            ErrorLog::error('[DB::update] failed', [
                'table'   => $table,
                'data'    => $data,
                'where'   => $where,
                'params'  => $whereParams,
            ], $e);
            throw new RuntimeException('Update failed: ' . $e->getMessage(), (int)$e->getCode(), $e);
        }
    }

    /**
     * Execute DELETE and return affected rows.
     *
     * @throws RuntimeException on SQL failure.
     */
    public function delete(string $table, string $where, array $params = []): int
    {
        $sql = sprintf('DELETE FROM `%s` WHERE %s', $table, $where);
        try {
            $stmt = $this->pdo->prepare($sql);
            if (!empty($params)) {
                foreach ($params as $key => $value) {
                    $param = ':' . ltrim((string)$key, ':');
                    $this->bindParam($stmt, $param, $value);
                }
            }
            $stmt->execute();
            return $stmt->rowCount();
        } catch (PDOException $e) {
            ErrorLog::error('[DB::delete] failed', [
                'table' => $table, 'where' => $where,
            ], $e);
            throw new RuntimeException('Delete failed: ' . $e->getMessage(), (int)$e->getCode(), $e);
        }
    }

    /**
     * Internal helper: bind a single parameter with the right PDO type.
     */
    private function bindParam(PDOStatement $stmt, string $param, $value): void
    {
        if ($value === null) {
            $stmt->bindValue($param, null, PDO::PARAM_NULL);
        } elseif (is_bool($value)) {
            $stmt->bindValue($param, $value, PDO::PARAM_BOOL);
        } elseif (is_int($value)) {
            $stmt->bindValue($param, $value, PDO::PARAM_INT);
        } elseif (is_float($value)) {
            $stmt->bindValue($param, $value); // PDO::PARAM_STR is correct for floats
        } else {
            $stmt->bindValue($param, (string)$value, PDO::PARAM_STR);
        }
    }

    /**
     * Strip reserved keys (auto-managed by DB) from data arrays.
     */
    private function stripReservedKeys(array $data): array
    {
        foreach (self::RESERVED_KEYS as $key) {
            unset($data[$key]);
        }
        return $data;
    }

    /**
     * Begin transaction
     */
    public function beginTransaction(): bool
    {
        if ($this->pdo->inTransaction()) {
            return true;
        }
        return $this->pdo->beginTransaction();
    }

    /**
     * Commit transaction
     */
    public function commit(): bool
    {
        if (!$this->pdo->inTransaction()) {
            return false;
        }
        return $this->pdo->commit();
    }

    /**
     * Rollback transaction (only when one is active)
     */
    public function rollback(): bool
    {
        if ($this->pdo->inTransaction()) {
            return $this->pdo->rollBack();
        }
        return false;
    }

    /**
     * Execute callback inside transaction.
     *
     * On failure: rollback, rethrow the original exception with the previous error chained.
     */
    public function transaction(callable $callback)
    {
        $started = $this->beginTransaction();
        if (!$started) {
            throw new RuntimeException('Unable to start database transaction');
        }
        try {
            $result = $callback($this);
            $this->commit();
            return $result;
        } catch (\Throwable $e) {
            $this->rollback();
            ErrorLog::error('[DB::transaction] rolled back', [], $e);
            throw $e;
        }
    }

    public function lastInsertId(): string
    {
        return $this->pdo->lastInsertId();
    }

    /**
     * Prevent cloning
     */
    private function __clone() {}
}
