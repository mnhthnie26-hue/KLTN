<?php
/**
 * BaseController - Shared helpers for controllers
 *
 * Standardizes success/error responses, pagination, form data flash, audit logs.
 */

declare(strict_types=1);

abstract class BaseController
{
    /**
     * Build a paginated result with consistent shape.
     *
     * @param array $items    raw rows
     * @param int   $total    total row count (before pagination)
     * @param int   $page     current page (1-based)
     * @param int   $perPage  items per page
     */
    protected function paginated(array $items, int $total, int $page, int $perPage): array
    {
        return [
            'items'      => $items,
            'pagination' => paginate($total, max(1, $page), max(1, $perPage)),
        ];
    }

    /**
     * Flash a success message and redirect.
     */
    protected function redirectWithSuccess(Response $response, string $url, string $message): void
    {
        Session::flash('success', $message);
        $response->redirect(url($url))->send();
    }

    /**
     * Flash an error message and redirect.
     */
    protected function redirectWithError(Response $response, string $url, string $message): void
    {
        Session::flash('error', $message);
        $response->redirect(url($url))->send();
    }

    /**
     * Send a JSON success response.
     */
    protected function jsonSuccess(Response $response, $data = null, string $message = 'Success', int $status = 200, array $meta = []): void
    {
        $response->success($data, $message, $status, $meta)->send();
    }

    /**
     * Send a JSON error response.
     */
    protected function jsonError(Response $response, string $message, $errors = null, int $status = 400, $data = null): void
    {
        $response->error($message, $errors, $status, $data)->send();
    }

    /**
     * Run an action inside a transaction with structured logging.
     * Returns ['success' => true, 'data' => $callbackReturn]
     *      or ['success' => false, 'message' => string, 'code' => ?]
     *
     * @param callable $callback receives Database instance, returns whatever the caller wants
     */
    protected function runInTransaction(callable $callback, string $errorMessage = 'Có lỗi xảy ra'): array
    {
        try {
            $result = Database::getInstance()->transaction($callback);
            return ['success' => true, 'data' => $result];
        } catch (Throwable $e) {
            ErrorLog::error('[BaseController::runInTransaction] failed', ['errMessage' => $errorMessage], $e);
            return ['success' => false, 'message' => $errorMessage, 'code' => $e->getCode()];
        }
    }

    /**
     * Audit-log an action safely (failures are non-fatal).
     */
    protected function audit(int $action, string $module, ?int $resourceId = null, $old = null, $new = null, ?string $description = null): void
    {
        try {
            Logger::getInstance()->audit(
                $action,
                $module,
                Auth::id(),
                $resourceId,
                $old,
                $new,
                $description
            );
        } catch (Throwable $e) {
            ErrorLog::error('[BaseController::audit] failed', ['action' => $action, 'module' => $module], $e);
        }
    }

    /**
     * Validate input and short-circuit on failure.
     *
     * @return array{ok: bool, errors: array, data: array}
     */
    protected function validateInput(array $data, array $rules): array
    {
        $validator = Validator::make($data, $rules);
        if ($validator->fails()) {
            return ['ok' => false, 'errors' => $validator->errors(), 'data' => []];
        }
        return ['ok' => true, 'errors' => [], 'data' => $validator->validated()];
    }

    /**
     * Read integer id from route params with safe default.
     */
    protected function paramId(array $params, string $key = 'id', int $default = 0): int
    {
        return max(0, (int)($params[$key] ?? $default));
    }

    /**
     * Get a request field as a trimmed string.
     */
    protected function strField(Request $request, string $key, string $default = ''): string
    {
        $v = $request->input($key, $default);
        return is_string($v) ? trim($v) : $default;
    }

    /**
     * Get a request field as int (or null if missing).
     */
    protected function intField(Request $request, string $key, ?int $default = null): ?int
    {
        $v = $request->input($key, null);
        if ($v === null || $v === '') return $default;
        return is_numeric($v) ? (int)$v : $default;
    }

    /**
     * Require an authenticated user; returns null and emits 401 if guest (for API).
     */
    protected function requireUserApi(Request $request, Response $response): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) {
            $response->error('Unauthenticated', null, 401)->send();
            return null;
        }
        return $user;
    }
}