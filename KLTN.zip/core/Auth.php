<?php
/**
 * Auth - Web Authentication Manager
 */

declare(strict_types=1);

class Auth
{
    public const SESSION_KEY = 'auth.user';

    private static ?array $currentUser = null;

    /**
     * Attempt to login
     */
    public static function attempt(string $usernameOrEmail, string $password, bool $remember = false): array
    {
        $db = Database::getInstance();

        // Find user
        $user = $db->fetchOne(
            'SELECT * FROM users WHERE (username = ? OR email = ?) AND deleted_at IS NULL LIMIT 1',
            [$usernameOrEmail, $usernameOrEmail]
        );

        if (!$user) {
            Logger::getInstance()->logLogin(null, $usernameOrEmail, false, 'user_not_found');
            return ['success' => false, 'message' => 'Tên đăng nhập hoặc mật khẩu không chính xác'];
        }

        // Check locked
        if ($user['locked_until'] && strtotime($user['locked_until']) > time()) {
            $remaining = ceil((strtotime($user['locked_until']) - time()) / 60);
            Logger::getInstance()->logLogin((int)$user['id'], $usernameOrEmail, false, 'account_locked');
            return ['success' => false, 'message' => "Tài khoản bị khóa. Vui lòng thử lại sau {$remaining} phút"];
        }

        // Check status
        if ((int)$user['status'] === 0) {
            Logger::getInstance()->logLogin((int)$user['id'], $usernameOrEmail, false, 'account_disabled');
            return ['success' => false, 'message' => 'Tài khoản đã bị vô hiệu hóa'];
        }

        // Verify password
        if (!password_verify($password, $user['password'])) {
            // Increment failed count
            $failedCount = (int)$user['failed_login_count'] + 1;
            $maxAttempts = (int)getSetting('security.max_login_attempts', 5);
            $lockoutDuration = (int)getSetting('security.lockout_duration', 900);

            $updateData = ['failed_login_count' => $failedCount];
            if ($failedCount >= $maxAttempts) {
                $updateData['locked_until'] = date('Y-m-d H:i:s', time() + $lockoutDuration);
                $updateData['failed_login_count'] = 0;
            }
            $db->update('users', $updateData, 'id = :id', ['id' => $user['id']]);

            Logger::getInstance()->logLogin((int)$user['id'], $usernameOrEmail, false, 'wrong_password');
            return ['success' => false, 'message' => 'Tên đăng nhập hoặc mật khẩu không chính xác'];
        }

        // Check password rehash (algorithm update)
        if (password_needs_rehash($user['password'], PASSWORD_BCRYPT)) {
            $newHash = password_hash($password, PASSWORD_BCRYPT);
            $db->update('users', ['password' => $newHash], 'id = :id', ['id' => $user['id']]);
        }

        // Reset failed count
        $db->update('users', [
            'failed_login_count' => 0,
            'locked_until'       => null,
            'last_login_at'      => date('Y-m-d H:i:s'),
            'last_login_ip'      => $_SERVER['REMOTE_ADDR'] ?? null,
        ], 'id = :id', ['id' => $user['id']]);

        // Load user with roles and permissions
        $user = self::loadUserWithRoles((int)$user['id']);

        // Set session
        Session::start();
        Session::regenerate();
        Session::regenerateCsrf();

        // Reset cached user so the new identity is picked up immediately.
        self::$currentUser = null;

        Session::set(self::SESSION_KEY, $user);
        Session::set('auth.id', $user['id']);
        Session::set('auth.expires_at', time() + SESSION_LIFETIME);

        // Remember me
        if ($remember) {
            $token = Security::randomToken(64);
            $db->update('users', ['remember_token' => hash('sha256', $token)], 'id = :id', ['id' => $user['id']]);
            setcookie('remember_user', $user['id'] . ':' . $token, [
                'expires'  => time() + (30 * 24 * 3600),
                'path'     => '/',
                'secure'   => APP_ENV === 'production',
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
        }

        // Audit log
        Logger::getInstance()->audit(
            AUDIT_LOGIN,
            'auth',
            (int)$user['id'],
            null,
            null,
            null,
            'Đăng nhập thành công',
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)
        );
        Logger::getInstance()->logLogin((int)$user['id'], $usernameOrEmail, true);

        return ['success' => true, 'user' => $user];
    }

    /**
     * Load user with roles and permissions
     */
    public static function loadUserWithRoles(int $userId): array
    {
        $db = Database::getInstance();

        $user = $db->fetchOne(
            'SELECT u.*, f.name AS faculty_name, d.name AS department_name
             FROM users u
             LEFT JOIN faculties f ON u.faculty_id = f.id
             LEFT JOIN departments d ON u.department_id = d.id
             WHERE u.id = ? AND u.deleted_at IS NULL',
            [$userId]
        );

        if (!$user) {
            return [];
        }

        // Load roles
        $roles = $db->fetchAll(
            'SELECT r.* FROM roles r
             INNER JOIN user_roles ur ON r.id = ur.role_id
             WHERE ur.user_id = ? AND r.status = 1',
            [$userId]
        );

        $roleNames = array_column($roles, 'name');
        $user['roles'] = $roles;
        $user['role_names'] = $roleNames;

        // Load permissions (from roles)
        $permissions = $db->fetchAll(
            'SELECT DISTINCT p.name, p.module FROM permissions p
             INNER JOIN role_permissions rp ON p.id = rp.permission_id
             INNER JOIN user_roles ur ON rp.role_id = ur.role_id
             WHERE ur.user_id = ?',
            [$userId]
        );

        $permNames = array_column($permissions, 'name');
        $user['permissions'] = $permissions;
        $user['permission_names'] = $permNames;

        return $user;
    }

    /**
     * Logout current user
     */
    public static function logout(): void
    {
        Session::start();
        $userId = Session::get('auth.id');

        if ($userId) {
            $userIdInt = (int)$userId;
            Logger::getInstance()->audit(
                AUDIT_LOGOUT,
                'auth',
                $userIdInt,
                null,
                null,
                null,
                'Đăng xuất',
                $_SERVER['REMOTE_ADDR'] ?? null,
                substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255)
            );

            // Revoke all access tokens
            try {
                Database::getInstance()->update(
                    'access_tokens',
                    ['revoked_at' => date('Y-m-d H:i:s')],
                    'user_id = :uid AND revoked_at IS NULL',
                    ['uid' => $userIdInt]
                );
            } catch (Throwable $e) {
                ErrorLog::error('[Auth::logout] token revoke failed', ['uid' => $userIdInt], $e);
            }
        }

        // Clear remember cookie
        if (isset($_COOKIE['remember_user'])) {
            setcookie('remember_user', '', time() - 3600, '/');
        }

        // Reset cached user so the next request does not see the previous user.
        self::$currentUser = null;

        Session::destroy();
        Session::start();
    }

    /**
     * Get current user
     */
    public static function user(): ?array
    {
        if (self::$currentUser !== null) {
            return self::$currentUser;
        }

        Session::start();

        // Try remember cookie
        if (!Session::has(self::SESSION_KEY) && isset($_COOKIE['remember_user'])) {
            self::loginFromRememberCookie($_COOKIE['remember_user']);
        }

        $user = Session::get(self::SESSION_KEY);

        // Make every log entry have a user_id when known.
        if (is_array($user) && isset($user['id'])) {
            ErrorLog::setUser((int)$user['id']);
        }

        // If the session carries a user but missing roles/permissions/user_type
        // (e.g. session from a previous code version, or partial hydration),
        // re-load from DB so admin detection works reliably.
        if ($user && (
            empty($user['permission_names']) ||
            !array_key_exists('role_names', $user) ||
            !array_key_exists('user_type', $user)
        )) {
            $reloaded = self::loadUserWithRoles((int)($user['id'] ?? 0));
            if ($reloaded) {
                $user = $reloaded;
                Session::set(self::SESSION_KEY, $user);
            } else {
                // Reload failed - log so we can diagnose.
                ErrorLog::warning('[Auth::user] reload returned empty', ['uid' => (int)($user['id'] ?? 0)]);
            }
        }

        // Check expiration
        if ($user && Session::has('auth.expires_at') && time() > (int)Session::get('auth.expires_at')) {
            self::logout();
            return null;
        }

        // Update expires_at
        if ($user) {
            Session::set('auth.expires_at', time() + SESSION_LIFETIME);
        }

        self::$currentUser = $user;
        return $user;
    }

    public static function id(): ?int
    {
        $user = self::user();
        return $user ? (int)$user['id'] : null;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function guest(): bool
    {
        return !self::check();
    }

    public static function hasRole(string $role): bool
    {
        $user = self::user();
        if (!$user) return false;

        // Built-in admin: user_type='admin' grants every role/permission.
        if (($user['user_type'] ?? null) === 'admin') return true;

        return in_array($role, $user['role_names'] ?? [], true);
    }

    public static function hasAnyRole(array $roles): bool
    {
        $user = self::user();
        if (!$user) return false;
        // Admin shortcut: if the user is admin, treat every role as granted.
        if (self::isAdmin()) return true;
        foreach ($roles as $role) {
            if (self::hasRole($role)) return true;
        }
        return false;
    }

    public static function hasPermission(string $permission): bool
    {
        $user = self::user();
        if (!$user) return false;
        // Admin (user_type='admin') gets every permission implicitly to avoid
        // stale permission cache problems.
        if (($user['user_type'] ?? null) === 'admin') return true;
        return in_array($permission, $user['permission_names'] ?? [], true);
    }

    public static function hasAnyPermission(array $permissions): bool
    {
        $user = self::user();
        if (!$user) return false;
        // Admin shortcut.
        if (($user['user_type'] ?? null) === 'admin') return true;
        foreach ($permissions as $perm) {
            if (self::hasPermission($perm)) return true;
        }
        return false;
    }

    public static function hasAllPermissions(array $permissions): bool
    {
        $user = self::user();
        if (!$user) return false;
        // Admin shortcut.
        if (($user['user_type'] ?? null) === 'admin') return true;
        foreach ($permissions as $perm) {
            if (!self::hasPermission($perm)) return false;
        }
        return true;
    }

    public static function isAdmin(): bool
    {
        return self::hasRole('admin');
    }

    public static function isManager(): bool
    {
        return self::hasAnyRole(['admin', 'manager']);
    }

    private static function loginFromRememberCookie(string $cookie): void
    {
        $parts = explode(':', $cookie, 2);
        if (count($parts) !== 2) return;

        [$userId, $token] = $parts;
        if (!ctype_digit($userId) || strlen($token) < 32) return;

        $user = Database::getInstance()->fetchOne(
            'SELECT id, remember_token FROM users WHERE id = ? AND status = 1 AND deleted_at IS NULL',
            [(int)$userId]
        );

        if (!$user || !$user['remember_token']) return;
        if (!hash_equals($user['remember_token'], hash('sha256', $token))) {
            // Invalid token - clear it
            Database::getInstance()->update('users', ['remember_token' => null], 'id = :id', ['id' => $userId]);
            setcookie('remember_user', '', time() - 3600, '/');
            return;
        }

        // Login
        $fullUser = self::loadUserWithRoles((int)$userId);
        Session::regenerate();
        Session::set(self::SESSION_KEY, $fullUser);
        Session::set('auth.id', $fullUser['id']);
        Session::set('auth.expires_at', time() + SESSION_LIFETIME);
        self::$currentUser = $fullUser;
    }

    /**
     * Change password
     */
    public static function changePassword(int $userId, string $currentPassword, string $newPassword): array
    {
        $db = Database::getInstance();
        $user = $db->fetchOne('SELECT id, password FROM users WHERE id = ?', [$userId]);

        if (!$user) {
            return ['success' => false, 'message' => 'Người dùng không tồn tại'];
        }

        if (!password_verify($currentPassword, $user['password'])) {
            return ['success' => false, 'message' => 'Mật khẩu hiện tại không chính xác'];
        }

        $minLength = (int)getSetting('security.password_min_length', 6);
        if (strlen($newPassword) < $minLength) {
            return ['success' => false, 'message' => "Mật khẩu mới phải có ít nhất {$minLength} ký tự"];
        }

        if ($currentPassword === $newPassword) {
            return ['success' => false, 'message' => 'Mật khẩu mới phải khác mật khẩu hiện tại'];
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
        try {
            $db->update('users', [
                'password' => $newHash,
                'must_change_password' => 0,
                'remember_token' => null,
            ], 'id = :id', ['id' => $userId]);
        } catch (Throwable $e) {
            ErrorLog::error('[Auth::changePassword] update users failed', ['uid' => $userId], $e);
            return ['success' => false, 'message' => 'Không thể cập nhật mật khẩu: ' . $e->getMessage()];
        }

        // Revoke all access tokens
        try {
            $db->update('access_tokens', ['revoked_at' => date('Y-m-d H:i:s')], 'user_id = :uid AND revoked_at IS NULL', ['uid' => $userId]);
        } catch (Throwable $e) {
            // access_tokens table may not exist on fresh installs - log so admins notice.
            ErrorLog::warning('[Auth::changePassword] access_tokens revoke failed', ['uid' => $userId], $e);
        }

        Logger::getInstance()->audit(
            AUDIT_CHANGE_PASSWORD,
            'auth',
            $userId,
            $userId,
            null,
            null,
            'Đổi mật khẩu',
            $_SERVER['REMOTE_ADDR'] ?? null
        );

        return ['success' => true, 'message' => 'Đổi mật khẩu thành công'];
    }

    /**
     * Reset password by admin
     */
    public static function resetPassword(int $userId, string $newPassword): array
    {
        $minLength = (int)getSetting('security.password_min_length', 6);
        if (strlen($newPassword) < $minLength) {
            return ['success' => false, 'message' => "Mật khẩu phải có ít nhất {$minLength} ký tự"];
        }

        $newHash = password_hash($newPassword, PASSWORD_BCRYPT);

        Database::getInstance()->update('users', [
            'password' => $newHash,
            'must_change_password' => 1,
            'remember_token' => null,
            'failed_login_count' => 0,
            'locked_until' => null,
        ], 'id = :id', ['id' => $userId]);

        // Revoke all access tokens
        try {
            Database::getInstance()->update('access_tokens', ['revoked_at' => date('Y-m-d H:i:s')], 'user_id = :uid AND revoked_at IS NULL', ['uid' => $userId]);
        } catch (Throwable $e) {
            ErrorLog::warning('[Auth::resetPassword] access_tokens revoke failed', ['uid' => $userId], $e);
        }

        Logger::getInstance()->audit(
            AUDIT_RESET_PASSWORD,
            'users',
            Auth::id(),
            $userId,
            null,
            null,
            'Reset mật khẩu'
        );

        return ['success' => true, 'message' => 'Reset mật khẩu thành công'];
    }
}