<?php
/**
 * Request - HTTP Request wrapper
 */

declare(strict_types=1);

class Request
{
    private string $method;
    private string $uri;
    private string $path;
    private array $query;
    private array $post;
    private array $server;
    private array $cookies;
    private array $files;
    private array $headers;
    private array $jsonBody = [];
    private ?array $cachedBody = null;
    private bool $bodyParsed = false;
    private ?array $apiUser = null;

    public function __construct()
    {
        $this->method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        $this->uri    = $_SERVER['REQUEST_URI'] ?? '/';
        $this->path   = '/' . trim(parse_url($this->uri, PHP_URL_PATH) ?? '/', '/');
        $this->query    = $_GET ?? [];
        $this->post     = $_POST ?? [];
        $this->server   = $_SERVER ?? [];
        $this->cookies  = $_COOKIE ?? [];
        $this->files    = $_FILES ?? [];
        $this->headers  = $this->parseHeaders();
    }

    private function parseHeaders(): array
    {
        $headers = [];
        foreach ($this->server as $key => $value) {
            if (str_starts_with((string)$key, 'HTTP_')) {
                $name = str_replace('_', '-', strtolower(substr((string)$key, 5)));
                $headers[$name] = $value;
            }
        }
        if (isset($this->server['CONTENT_TYPE'])) {
            $headers['content-type'] = $this->server['CONTENT_TYPE'];
        }
        if (isset($this->server['CONTENT_LENGTH'])) {
            $headers['content-length'] = $this->server['CONTENT_LENGTH'];
        }
        return $headers;
    }

    public function method(): string { return $this->method; }
    public function uri(): string { return $this->uri; }
    public function path(): string { return $this->path; }

    public function isGet(): bool    { return $this->method === 'GET'; }
    public function isPost(): bool   { return $this->method === 'POST'; }
    public function isPut(): bool    { return $this->method === 'PUT'; }
    public function isPatch(): bool  { return $this->method === 'PATCH'; }
    public function isDelete(): bool { return $this->method === 'DELETE'; }
    public function isAjax(): bool   { return ($this->headers['x-requested-with'] ?? '') === 'XMLHttpRequest'; }

    public function query(string $key = null, $default = null)
    {
        if ($key === null) return $this->query;
        return $this->query[$key] ?? $default;
    }

    public function post(string $key = null, $default = null)
    {
        if ($key === null) return $this->post;
        return $this->post[$key] ?? $default;
    }

    public function cookie(string $key = null, $default = null)
    {
        if ($key === null) return $this->cookies;
        return $this->cookies[$key] ?? $default;
    }

    public function file(string $key): ?array
    {
        return $this->files[$key] ?? null;
    }

    /**
     * Get all uploaded files normalized into a flat array (supports nested names like files[]).
     */
    public function files(?string $key = null): array
    {
        if ($key === null) return $this->files;
        return $this->files[$key] ?? [];
    }

    public function header(string $name): ?string
    {
        return $this->headers[strtolower($name)] ?? null;
    }

    public function bearerToken(): ?string
    {
        $auth = $this->header('authorization');
        if ($auth && preg_match('/Bearer\s+(.+)/i', $auth, $matches)) {
            return trim($matches[1]);
        }
        return null;
    }

    /**
     * Return the merged body (POST + JSON), cached.
     * - JSON body wins over POST when both exist (REST API behavior).
     * - form-urlencoded POST is preserved.
     */
    public function body(): array
    {
        if ($this->bodyParsed) {
            return $this->cachedBody ?? [];
        }
        $this->bodyParsed = true;

        $contentType = $this->header('content-type') ?? '';

        if (str_contains($contentType, 'application/json')) {
            $raw = file_get_contents('php://input');
            if ($raw !== false && $raw !== '') {
                $decoded = json_decode($raw, true);
                if (is_array($decoded)) {
                    $this->jsonBody = $this->flattenArrays($decoded);
                }
            }
            // For JSON requests, ignore $_POST entirely (cleaner semantics).
            $this->cachedBody = $this->jsonBody;
            return $this->cachedBody;
        }

        if (str_contains($contentType, 'multipart/form-data')) {
            $this->cachedBody = $this->flattenArrays($this->post);
            return $this->cachedBody;
        }

        // Default: form-urlencoded or unknown.
        $this->cachedBody = $this->flattenArrays($this->post);
        return $this->cachedBody;
    }

    /**
     * Recursively flatten arrays with string keys.
     * Useful for converting {"a": {"b": 1}} into ["a[b]" => 1] for storage compatibility.
     */
    private function flattenArrays(array $data, string $prefix = ''): array
    {
        $out = [];
        foreach ($data as $key => $value) {
            $fullKey = $prefix === '' ? (string)$key : $prefix . '[' . $key . ']';
            if (is_array($value) && $this->isAssoc($value)) {
                $out = array_merge($out, $this->flattenArrays($value, $fullKey));
            } else {
                $out[$fullKey] = $value;
            }
        }
        return $out;
    }

    private function isAssoc(array $arr): bool
    {
        if ($arr === []) return false;
        return array_keys($arr) !== range(0, count($arr) - 1);
    }

    /**
     * Get one input value from the merged body.
     */
    public function input(string $key, $default = null)
    {
        $body = $this->body();
        return $body[$key] ?? $default;
    }

    /**
     * Get input as trimmed string.
     */
    public function str(string $key, string $default = ''): string
    {
        $v = $this->input($key, $default);
        return is_string($v) ? trim($v) : (string)$v;
    }

    /**
     * Get input as integer (or default).
     */
    public function int(string $key, int $default = 0): int
    {
        $v = $this->input($key, $default);
        return is_numeric($v) ? (int)$v : $default;
    }

    /**
     * Get input as float (or default).
     */
    public function float(string $key, float $default = 0.0): float
    {
        $v = $this->input($key, $default);
        return is_numeric($v) ? (float)$v : $default;
    }

    /**
     * Get input as boolean.
     */
    public function bool(string $key, bool $default = false): bool
    {
        $v = $this->input($key, $default);
        if (is_bool($v)) return $v;
        if ($v === 1 || $v === '1' || $v === 'true' || $v === 'on') return true;
        if ($v === 0 || $v === '0' || $v === 'false' || $v === 'off') return false;
        return (bool)$v;
    }

    /**
     * Get input as array (with default []).
     */
    public function array(string $key, array $default = []): array
    {
        $v = $this->input($key, $default);
        return is_array($v) ? $v : $default;
    }

    /**
     * Return only the listed keys from body().
     */
    public function only(array $keys): array
    {
        $body = $this->body();
        $out = [];
        foreach ($keys as $k) {
            if (array_key_exists($k, $body)) {
                $out[$k] = $body[$k];
            }
        }
        return $out;
    }

    /**
     * Return body() minus the listed keys.
     */
    public function except(array $keys): array
    {
        $body = $this->body();
        foreach ($keys as $k) {
            unset($body[$k]);
        }
        return $body;
    }

    public function ip(): string
    {
        $candidates = [
            'HTTP_CF_CONNECTING_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];
        foreach ($candidates as $key) {
            if (!empty($this->server[$key])) {
                $ip = explode(',', (string)$this->server[$key])[0];
                $ip = trim($ip);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        return '0.0.0.0';
    }

    public function userAgent(): string
    {
        return substr((string)($this->server['HTTP_USER_AGENT'] ?? 'Unknown'), 0, 255);
    }

    public function segment(int $index): ?string
    {
        $segments = array_values(array_filter(explode('/', $this->path)));
        return $segments[$index - 1] ?? null;
    }

    /**
     * Set the authenticated API user (used by ApiAuthMiddleware).
     */
    public function setApiUser(?array $user): void
    {
        $this->apiUser = $user;
        $GLOBALS['__api_user'] = $user;
    }

    /**
     * Get the authenticated API user (set by ApiAuthMiddleware).
     */
    public function apiUser(): ?array
    {
        return $this->apiUser ?? ($GLOBALS['__api_user'] ?? null);
    }
}