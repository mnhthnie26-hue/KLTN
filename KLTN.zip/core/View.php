<?php
/**
 * View - Template renderer
 */

declare(strict_types=1);

class View
{
    private static array $sharedData = [];

    public static function share(string $key, $value): void
    {
        self::$sharedData[$key] = $value;
    }

    public static function render(string $view, array $data = [], string $layout = 'app'): string
    {
        $data = array_merge(self::$sharedData, $data);

        // Render view content
        $content = self::renderFile($view, $data);

        // Nested layout fragments must not be wrapped in a layout (infinite recursion).
        $viewPath = str_replace('\\', '/', $view);
        if (str_starts_with($viewPath, 'layouts/')) {
            return $content;
        }

        // If layout is null, return content as-is
        if ($layout === null || $layout === '') {
            return $content;
        }

        // Render with layout
        $layoutFile = VIEWS_PATH . '/layouts/' . $layout . '.php';
        if (!file_exists($layoutFile)) {
            return $content;
        }

        $data['content'] = $content;
        return self::renderFileContent($layoutFile, $data);
    }

    public static function renderPartial(string $view, array $data = []): string
    {
        return self::renderFile($view, array_merge(self::$sharedData, $data));
    }

    private static function renderFile(string $view, array $data): string
    {
        $viewFile = VIEWS_PATH . '/' . str_replace('.', '/', $view) . '.php';

        if (!file_exists($viewFile)) {
            throw new RuntimeException("View not found: {$view}");
        }

        return self::renderFileContent($viewFile, $data);
    }

    private static function renderFileContent(string $file, array $data): string
    {
        // Extract data into local scope
        extract($data, EXTR_SKIP);

        ob_start();
        include $file;
        return ob_get_clean();
    }

    /**
     * Escape HTML
     */
    public static function e($value): string
    {
        if ($value === null) return '';
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}