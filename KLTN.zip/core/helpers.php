<?php
/**
 * Helper functions
 */

declare(strict_types=1);

if (!function_exists('getSetting')) {
    /**
     * Get system setting value
     */
    function getSetting(string $key, $default = null)
    {
        static $cache = [];
        static $loaded = false;
        static $allLoadedAt = 0.0;

        if (array_key_exists($key, $cache)) {
            return $cache[$key];
        }

        $now = microtime(true);

        try {
            $db = Database::getInstance();

            if (!$loaded || ($now - $allLoadedAt) > 3.0) {
                $allLoadedAt = $now;
                $loaded = true;
                try {
                    $rows = $db->fetchAll('SELECT setting_key, setting_value FROM system_settings');
                    foreach ($rows as $row) {
                        $raw = (string)$row['setting_value'];
                        $decoded = json_decode($raw, true);
                        if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                            $cache[$row['setting_key']] = $decoded;
                        } else {
                            $cache[$row['setting_key']] = $raw;
                        }
                    }
                    if (array_key_exists($key, $cache)) {
                        return $cache[$key];
                    }
                    $cache[$key] = $default;
                    return $default;
                } catch (Throwable $e) {
                    ErrorLog::warning('[getSetting] bulk-load failed, falling back to per-key', [], $e);
                    // Fall through to per-key fetch.
                }
            }

            $value = $db->fetchValue('SELECT setting_value FROM system_settings WHERE setting_key = ?', [$key]);
            if ($value === null) {
                $cache[$key] = $default;
                return $default;
            }
            $decoded = json_decode((string)$value, true);
            if (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) {
                $cache[$key] = $decoded;
                return $decoded;
            }
            $cache[$key] = $value;
            return $value;
        } catch (Throwable $e) {
            ErrorLog::error('[getSetting] failed', ['key' => $key], $e);
            return $default;
        }
    }
}

if (!function_exists('url')) {
    /**
     * Generate URL
     */
    function url(string $path = ''): string
    {
        $base = APP_URL;
        if ($path === '') return $base;
        return rtrim($base, '/') . '/' . ltrim($path, '/');
    }
}

if (!function_exists('asset')) {
    /**
     * Generate asset URL
     */
    function asset(string $path): string
    {
        return url('assets/' . ltrim($path, '/'));
    }
}

if (!function_exists('redirect')) {
    function redirect(string $url, int $status = 302): void
    {
        header('Location: ' . $url, true, $status);
        exit;
    }
}

if (!function_exists('e')) {
    /**
     * Escape HTML
     */
    function e($value): string
    {
        if ($value === null) return '';
        if (is_array($value) || is_object($value)) {
            return htmlspecialchars(json_encode($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }
}

if (!function_exists('dd')) {
    /**
     * Dump and die (debug)
     */
    function dd(...$vars): void
    {
        if (!APP_DEBUG) return;
        echo '<pre style="background:#222;color:#0f0;padding:15px;margin:10px;">';
        foreach ($vars as $v) {
            var_dump($v);
        }
        echo '</pre>';
        exit;
    }
}

if (!function_exists('formatDate')) {
    /**
     * Format date
     */
    function formatDate($date, string $format = 'd/m/Y'): string
    {
        if (empty($date) || $date === '0000-00-00' || $date === '0000-00-00 00:00:00') return '';
        $timestamp = is_numeric($date) ? (int)$date : strtotime($date);
        return date($format, $timestamp);
    }
}

if (!function_exists('formatDateTime')) {
    function formatDateTime($date, string $format = 'd/m/Y H:i'): string
    {
        return formatDate($date, $format);
    }
}

if (!function_exists('old')) {
    /**
     * Get old input value (for form re-population)
     */
    function old(string $key, $default = '')
    {
        $old = Session::flash('form_data');
        return $old[$key] ?? $default;
    }
}

if (!function_exists('csrf_field')) {
    function csrf_field(): string
    {
        Session::start();
        return '<input type="hidden" name="_csrf_token" value="' . Session::csrfToken() . '">';
    }
}

if (!function_exists('method_field')) {
    function method_field(string $method): string
    {
        return '<input type="hidden" name="_method" value="' . $method . '">';
    }
}

if (!function_exists('paginate')) {
    /**
     * Build pagination data
     */
    function paginate(int $total, int $page = 1, int $perPage = 20): array
    {
        $totalPages = max(1, (int)ceil($total / $perPage));
        $page = max(1, min($page, $totalPages));

        return [
            'total'        => $total,
            'per_page'     => $perPage,
            'current_page' => $page,
            'total_pages'  => $totalPages,
            'has_next'     => $page < $totalPages,
            'has_prev'     => $page > 1,
            'next_page'    => $page < $totalPages ? $page + 1 : null,
            'prev_page'    => $page > 1 ? $page - 1 : null,
            'offset'       => ($page - 1) * $perPage,
        ];
    }
}

if (!function_exists('render_pagination')) {
    function render_pagination(array $pagination, string $baseUrl): string
    {
        if ($pagination['total_pages'] <= 1) return '';

        $current = $pagination['current_page'];
        $total = $pagination['total_pages'];

        $html = '<nav class="pagination"><ul>';
        $html .= '<li class="' . ($pagination['has_prev'] ? '' : 'disabled') . '">';
        if ($pagination['has_prev']) {
            $html .= '<a href="' . $baseUrl . '&page=' . $pagination['prev_page'] . '">&laquo;</a>';
        } else {
            $html .= '<span>&laquo;</span>';
        }
        $html .= '</li>';

        for ($i = 1; $i <= $total; $i++) {
            if ($i === $current) {
                $html .= '<li class="active"><span>' . $i . '</span></li>';
            } else {
                $html .= '<li><a href="' . $baseUrl . '&page=' . $i . '">' . $i . '</a></li>';
            }
        }

        $html .= '<li class="' . ($pagination['has_next'] ? '' : 'disabled') . '">';
        if ($pagination['has_next']) {
            $html .= '<a href="' . $baseUrl . '&page=' . $pagination['next_page'] . '">&raquo;</a>';
        } else {
            $html .= '<span>&raquo;</span>';
        }
        $html .= '</li>';
        $html .= '</ul></nav>';

        return $html;
    }
}

if (!function_exists('slugify')) {
    function slugify(string $text): string
    {
        $text = preg_replace('~[^\pL\d]+~u', '-', $text);
        $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);
        $text = preg_replace('~[^-\w]+~', '', $text);
        $text = trim($text, '-');
        $text = preg_replace('~-+~', '-', $text);
        $text = strtolower($text);
        return $text === '' ? 'n-a' : $text;
    }
}