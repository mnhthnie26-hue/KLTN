<?php
/**
 * Router - URL routing system
 */

declare(strict_types=1);

class Router
{
    private array $routes = [
        'GET'    => [],
        'POST'   => [],
        'PUT'    => [],
        'PATCH'  => [],
        'DELETE' => [],
    ];
    private array $middlewareGroups = [];
    private array $namedRoutes = [];
    private ?string $currentRouteName = null;

    public function get(string $path, $handler, array $middleware = []): void
    {
        $this->addRoute('GET', $path, $handler, $middleware);
    }

    public function post(string $path, $handler, array $middleware = []): void
    {
        $this->addRoute('POST', $path, $handler, $middleware);
    }

    public function put(string $path, $handler, array $middleware = []): void
    {
        $this->addRoute('PUT', $path, $handler, $middleware);
    }

    public function patch(string $path, $handler, array $middleware = []): void
    {
        $this->addRoute('PATCH', $path, $handler, $middleware);
    }

    public function delete(string $path, $handler, array $middleware = []): void
    {
        $this->addRoute('DELETE', $path, $handler, $middleware);
    }

    public function any(string $path, $handler, array $middleware = []): void
    {
        foreach (['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] as $method) {
            $this->addRoute($method, $path, $handler, $middleware);
        }
    }

    public function name(string $name): void
    {
        if (!empty($this->routes)) {
            $lastKey = array_key_last($this->routes);
            // Find last added
            foreach (['GET', 'POST', 'PUT', 'PATCH', 'DELETE'] as $method) {
                if (!empty($this->routes[$method])) {
                    $lastRouteKey = array_key_last($this->routes[$method]);
                    if (isset($this->routes[$method][$lastRouteKey])) {
                        $this->namedRoutes[$name] = ['method' => $method, 'path' => $this->routes[$method][$lastRouteKey]['path']];
                    }
                }
            }
        }
    }

    private function addRoute(string $method, string $path, $handler, array $middleware): void
    {
        $pattern = $this->compilePath($path);
        $this->routes[$method][] = [
            'path'        => $path,
            'pattern'     => $pattern,
            'handler'     => $handler,
            'middleware'  => $middleware,
        ];
    }

    private function compilePath(string $path): string
    {
        $pattern = preg_replace('/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/', '(?P<$1>[^/]+)', $path);
        return '#^' . $pattern . '$#';
    }

    public function dispatch(Request $request, Response $response): void
    {
        $method = $request->method();
        $path = $request->path();

        // Strip base path if present
        if (defined('BASE_PATH') && BASE_PATH !== '' && str_starts_with($path, BASE_PATH)) {
            $path = substr($path, strlen(BASE_PATH));
            if ($path === '') $path = '/';
        }

        $routes = $this->routes[$method] ?? [];

        foreach ($routes as $route) {
            if (preg_match($route['pattern'], $path, $matches)) {
                $params = array_filter($matches, fn($k) => !is_int($k), ARRAY_FILTER_USE_KEY);

                // Run middleware (class name or already-built instance)
                foreach ($route['middleware'] as $middlewareDef) {
                    $middleware = is_object($middlewareDef) ? $middlewareDef : new $middlewareDef();
                    $middlewareResult = $middleware->handle($request, $response);
                    if ($middlewareResult === false) {
                        return;
                    }
                    if ($middlewareResult instanceof Response) {
                        $middlewareResult->send();
                        return;
                    }
                }

                // Run handler
                $this->invokeHandler($route['handler'], $params, $request, $response);
                return;
            }
        }

        // 404
        $this->handleNotFound($request, $response);
    }

    private function invokeHandler($handler, array $params, Request $request, Response $response): void
    {
        if (is_callable($handler)) {
            $handler($params, $request, $response);
            return;
        }

        if (is_string($handler) && str_contains($handler, '@')) {
            [$controller, $method] = explode('@', $handler);
            $controllerInstance = new $controller();
            $controllerInstance->$method($params, $request, $response);
            return;
        }

        throw new InvalidArgumentException('Invalid route handler');
    }

    private function handleNotFound(Request $request, Response $response): void
    {
        if (str_starts_with($request->path(), '/api/')) {
            $response->error('Endpoint not found', null, 404)->send();
            return;
        }

        if (file_exists(VIEWS_PATH . '/errors/404.php')) {
            http_response_code(404);
            include VIEWS_PATH . '/errors/404.php';
        } else {
            echo '<h1>404 Not Found</h1>';
        }
        exit;
    }
}