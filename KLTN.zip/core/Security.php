<?php
/**
 * Secure - XSS and input sanitization
 */

declare(strict_types=1);

class Security
{
    /**
     * Escape HTML output
     */
    public static function escape($value): string
    {
        if ($value === null) return '';
        if (is_array($value) || is_object($value)) {
            return htmlspecialchars(json_encode($value), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        return htmlspecialchars((string)$value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /**
     * Sanitize string (strip tags, trim)
     */
    public static function sanitize(?string $value): string
    {
        if ($value === null) return '';
        $value = strip_tags($value);
        $value = trim($value);
        return $value;
    }

    /**
     * Clean recursive array
     */
    public static function cleanArray(array $data): array
    {
        $cleaned = [];
        foreach ($data as $key => $value) {
            if (is_string($value)) {
                $cleaned[$key] = self::sanitize($value);
            } elseif (is_array($value)) {
                $cleaned[$key] = self::cleanArray($value);
            } else {
                $cleaned[$key] = $value;
            }
        }
        return $cleaned;
    }

    /**
     * Generate random token
     */
    public static function randomToken(int $length = 32): string
    {
        try {
            return bin2hex(random_bytes((int)($length / 2)));
        } catch (Throwable $e) {
            // If the CSPRNG itself failed we should NOT pretend we generated a token silently.
            ErrorLog::critical('[Security::randomToken] random_bytes failed, using non-secure fallback', ['len' => $length], $e);
            // Best-effort fallback; the failure is already logged at CRITICAL.
            $bytes = '';
            if (function_exists('openssl_random_pseudo_bytes')) {
                $bytes = (string)@openssl_random_pseudo_bytes((int)($length / 2), $strong);
                if (empty($strong)) {
                    ErrorLog::critical('[Security::randomToken] openssl fallback also weak', []);
                }
            }
            if ($bytes === '') {
                // Last-resort non-secure pseudo-random. Always logged as a critical event.
                ErrorLog::critical('[Security::randomToken] no secure RNG available - using mt_rand fallback', []);
                $bytes = '';
                for ($i = 0; $i < (int)($length / 2); $i++) {
                    $bytes .= chr((int)(mt_rand(0, 255)));
                }
            }
            return bin2hex($bytes);
        }
    }

    /**
     * Generate UUID v4
     */
    public static function uuid(): string
    {
        $data = random_bytes(16);
        $data[6] = chr((ord($data[6]) & 0x0f) | 0x40);
        $data[8] = chr((ord($data[8]) & 0x3f) | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }

    /**
     * Hash token for storage (so plain token never stored)
     */
    public static function hashToken(string $token): string
    {
        return hash_hmac('sha256', $token, APP_SECRET);
    }

    /**
     * Verify hashed token
     */
    public static function verifyToken(string $token, string $hash): bool
    {
        return hash_equals($hash, self::hashToken($token));
    }

    /**
     * Constant-time string comparison
     */
    public static function safeCompare(string $known, string $user): bool
    {
        return hash_equals($known, $user);
    }

    /**
     * Prevent XSS in JS context
     */
    public static function escapeJs($value): string
    {
        return json_encode($value, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP);
    }

    /**
     * Sanitize filename
     */
    public static function sanitizeFilename(string $filename): string
    {
        $filename = preg_replace('/[^a-zA-Z0-9._-]/', '_', $filename);
        return substr($filename, 0, 255);
    }
}