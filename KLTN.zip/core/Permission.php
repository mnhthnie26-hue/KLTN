<?php
/**
 * Permission - RBAC permission checker
 */

declare(strict_types=1);

class Permission
{
    /**
     * Get all permissions of current user (cached in session)
     */
    public static function currentPermissions(): array
    {
        $user = Auth::user();
        if (!$user) return [];
        return $user['permission_names'] ?? [];
    }

    public static function can(string $permission): bool
    {
        return Auth::hasPermission($permission);
    }

    public static function cannot(string $permission): bool
    {
        return !self::can($permission);
    }

    /**
     * Check if user is in role
     */
    public static function inRole(string $role): bool
    {
        return Auth::hasRole($role);
    }

    /**
     * Get all available permissions grouped by module
     */
    public static function getAllGrouped(): array
    {
        try {
            $permissions = Database::getInstance()->fetchAll(
                'SELECT * FROM permissions ORDER BY module, name'
            );

            $grouped = [];
            foreach ($permissions as $perm) {
                $grouped[$perm['module']][$perm['name']] = $perm;
            }
            return $grouped;
        } catch (Throwable $e) {
            ErrorLog::error('[Permission::getAllGrouped] failed', [], $e);
            return [];
        }
    }

    /**
     * Get permissions of a role
     */
    public static function getRolePermissions(int $roleId): array
    {
        return Database::getInstance()->fetchAll(
            'SELECT p.* FROM permissions p
             INNER JOIN role_permissions rp ON p.id = rp.permission_id
             WHERE rp.role_id = ?
             ORDER BY p.module, p.name',
            [$roleId]
        );
    }

    /**
     * Sync role permissions
     */
    public static function syncRolePermissions(int $roleId, array $permissionIds): void
    {
        $db = Database::getInstance();
        $db->beginTransaction();
        try {
            $db->query('DELETE FROM role_permissions WHERE role_id = ?', [$roleId]);
            foreach ($permissionIds as $permId) {
                $db->insert('role_permissions', [
                    'role_id' => $roleId,
                    'permission_id' => (int)$permId,
                ]);
            }
            $db->commit();
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
    }
}