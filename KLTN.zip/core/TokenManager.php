<?php
/**
 * TokenManager - API token generation & validation
 */

declare(strict_types=1);

class TokenManager
{
    /**
     * Generate a new access token
     */
    public static function generateAccessToken(int $userId, ?string $tokenName = null, ?int $expiresIn = null): array
    {
        $expiresIn = $expiresIn ?? (int)getSetting('security.token_lifetime', 3600);
        $token = Security::randomToken(40);
        $tokenHash = Security::hashToken($token);

        $db = Database::getInstance();

        $id = $db->insert('access_tokens', [
            'user_id'    => $userId,
            'token_hash' => $tokenHash,
            'token_name' => $tokenName,
            'expires_at' => date('Y-m-d H:i:s', time() + $expiresIn),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent' => substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 255),
        ]);

        return [
            'id'           => $id,
            'access_token' => $token,
            'token_type'   => 'Bearer',
            'expires_in'   => $expiresIn,
            'expires_at'   => date('Y-m-d H:i:s', time() + $expiresIn),
        ];
    }

    /**
     * Generate refresh token
     */
    public static function generateRefreshToken(int $accessTokenId, ?int $expiresIn = null): array
    {
        $expiresIn = $expiresIn ?? (int)getSetting('security.refresh_token_lifetime', 2592000);
        $token = Security::randomToken(64);
        $tokenHash = Security::hashToken($token);

        $db = Database::getInstance();
        $db->insert('refresh_tokens', [
            'access_token_id' => $accessTokenId,
            'token_hash'      => $tokenHash,
            'expires_at'      => date('Y-m-d H:i:s', time() + $expiresIn),
        ]);

        return [
            'refresh_token' => $token,
            'expires_in'    => $expiresIn,
        ];
    }

    /**
     * Validate access token
     */
    public static function validate(string $token): ?array
    {
        $tokenHash = Security::hashToken($token);
        $db = Database::getInstance();

        $row = $db->fetchOne(
            'SELECT t.*, u.username, u.email, u.full_name, u.user_type, u.status, u.deleted_at
             FROM access_tokens t
             INNER JOIN users u ON t.user_id = u.id
             WHERE t.token_hash = ?',
            [$tokenHash]
        );

        if (!$row) return null;
        if ($row['revoked_at']) return null;
        if (strtotime($row['expires_at']) < time()) return null;
        if ((int)$row['status'] !== 1 || $row['deleted_at']) return null;

        // Update last used
        $db->update('access_tokens', ['last_used_at' => date('Y-m-d H:i:s')], 'id = :id', ['id' => $row['id']]);

        return $row;
    }

    /**
     * Revoke a token
     */
    public static function revoke(string $token): bool
    {
        $tokenHash = Security::hashToken($token);
        $db = Database::getInstance();
        $rows = $db->update('access_tokens', ['revoked_at' => date('Y-m-d H:i:s')], 'token_hash = :h AND revoked_at IS NULL', ['h' => $tokenHash]);
        return $rows > 0;
    }

    /**
     * Revoke all tokens for user
     */
    public static function revokeAllForUser(int $userId): int
    {
        $db = Database::getInstance();
        return $db->update('access_tokens', ['revoked_at' => date('Y-m-d H:i:s')], 'user_id = :uid AND revoked_at IS NULL', ['uid' => $userId]);
    }

    /**
     * Refresh access token using refresh token
     */
    public static function refresh(string $refreshToken): ?array
    {
        $tokenHash = Security::hashToken($refreshToken);
        $db = Database::getInstance();

        $row = $db->fetchOne(
            'SELECT rt.*, at.user_id, at.revoked_at AS at_revoked
             FROM refresh_tokens rt
             INNER JOIN access_tokens at ON rt.access_token_id = at.id
             WHERE rt.token_hash = ?',
            [$tokenHash]
        );

        if (!$row) return null;
        if ($row['revoked_at']) return null;
        if ($row['at_revoked']) return null;
        if (strtotime($row['expires_at']) < time()) return null;

        // Revoke old, generate new
        $db->update('access_tokens', ['revoked_at' => date('Y-m-d H:i:s')], 'id = :id', ['id' => $row['access_token_id']]);
        $db->delete('refresh_tokens', 'id = :id', ['id' => $row['id']]);

        return self::generateAccessToken((int)$row['user_id']);
    }
}