<?php
/**
 * Bootstrap - global handlers, request init, error reporting.
 *
 * Loaded from index.php (web) and api/index.php (API). Must be required AFTER
 * config/constants but BEFORE route dispatch so handlers are armed early.
 */

declare(strict_types=1);

if (!function_exists('bootstrap_runtime')) {
    /**
     * Arm global error/exception handlers, init request context, and seed the error logger.
     */
    function bootstrap_runtime(): void
    {
        static $booted = false;
        if ($booted) return;
        $booted = true;

        // Make sure the storage directories exist; if they don't we want to know early.
        $storageDirs = [
            STORAGE_PATH . '/logs',
            STORAGE_PATH . '/exports',
            STORAGE_PATH . '/cache',
            STORAGE_PATH . '/uploads',
        ];
        foreach ($storageDirs as $dir) {
            if (!is_dir($dir)) {
                if (!@mkdir($dir, 0755, true)) {
                    error_log('[bootstrap] cannot create storage dir: ' . $dir);
                }
            }
            if (!is_writable($dir)) {
                error_log('[bootstrap] storage dir not writable: ' . $dir);
            }
        }

        // Load ErrorLog class early so the bootstrap can use it.
        if (file_exists(__DIR__ . '/ErrorLog.php')) {
            require_once __DIR__ . '/ErrorLog.php';
        }

        ErrorLog::init();

        // Convert PHP notices/warnings into ErrorException for uncaught handler.
        set_error_handler(function ($severity, $message, $file, $line): bool {
            if (!(error_reporting() & $severity)) return false;
            throw new ErrorException($message, 0, $severity, $file, $line);
        });

        // Catch anything not caught by try/catch and never let it be silent.
        set_exception_handler(function (Throwable $e): void {
            ErrorLog::critical('[uncaught]', [
                'uri'    => $_SERVER['REQUEST_URI'] ?? null,
                'method' => $_SERVER['REQUEST_METHOD'] ?? null,
            ], $e);

            // Try to respond gracefully if no headers have been sent.
            if (!headers_sent()) {
                http_response_code(500);
                $isApi = str_starts_with((string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH), '/api/');
                if ($isApi) {
                    header('Content-Type: application/json; charset=utf-8');
                    echo json_encode([
                        'success' => false,
                        'message' => APP_DEBUG
                            ? ('Internal server error: ' . $e->getMessage())
                            : 'Internal server error',
                        'request_id' => ErrorLog::requestId(),
                    ], JSON_UNESCAPED_UNICODE);
                } else {
                    $view = ROOT_PATH . '/views/errors/500.php';
                    if (file_exists($view)) {
                        $error_data = ['error' => APP_DEBUG ? $e->getMessage() : 'Server error', 'request_id' => ErrorLog::requestId()];
                        include $view;
                    } else {
                        echo '<h1>500 - Server Error</h1>';
                    }
                }
            }
            exit(1);
        });

        // Last-chance handler for fatal errors (shutdown).
        register_shutdown_function(function (): void {
            $error = error_get_last();
            if ($error === null) return;
            $fatal = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR];
            if (!in_array($error['type'], $fatal, true)) return;

            $msg = sprintf('%s in %s:%d', $error['message'], $error['file'], $error['line']);
            ErrorLog::critical('[fatal] ' . $msg, [
                'type' => $error['type'],
            ]);

            if (!headers_sent()) {
                http_response_code(500);
                if (APP_DEBUG) {
                    header('Content-Type: text/plain; charset=utf-8');
                    echo "Fatal error: " . $msg;
                }
            }
            exit(1);
        });
    }
}

bootstrap_runtime();