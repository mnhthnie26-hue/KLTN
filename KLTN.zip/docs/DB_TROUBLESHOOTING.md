# Hướng dẫn khắc phục lỗi DB trên shared hosting (cPanel)

## Lỗi thường gặp

```
SQLSTATE[42000] [1044] Access denied for user 'kypcbhvj_manager_student'@'localhost'
to database 'kypcbhvj_manager_student'
```

## Nguyên nhân

User MySQL chưa được cấp quyền truy cập database (hoặc thông tin trong `config/database.php` chưa đúng).

## Cách khắc phục trên cPanel

1. Đăng nhập cPanel
2. Vào mục **"MySQL Databases"** (Databases > MySQL Databases)
3. Kiểm tra **"Current Databases"** - đảm bảo database `kypcbhvj_manager_student` tồn tại
4. Kiểm tra **"Current Users"** - đảm bảo user `kypcbhvj_manager_student` tồn tại
5. Kiểm tra **"Add User To Database"** - phải có dòng:
   ```
   kypcbhvj_manager_student | kypcbhvj_manager_student | All Privileges
   ```
   Nếu chưa có, hãy thêm:
   - User: `kypcbhvj_manager_student`
   - Database: `kypcbhvj_manager_student`
   - Privileges: **ALL PRIVILEGES**
6. Click **"Make Changes"** / **"Add"**

## Cách khắc phục bằng SQL (nếu có quyền root)

Mở phpMyAdmin > SQL tab, chạy:

```sql
GRANT ALL PRIVILEGES ON `kypcbhvj_manager_student`.* TO 'kypcbhvj_manager_student'@'localhost';
FLUSH PRIVILEGES;
```

File `database/grant_privileges.sql` chứa lệnh sẵn.

## Kiểm tra thông tin đăng nhập

Nếu MySQL đã được cấp quyền nhưng vẫn lỗi, kiểm tra `config/database.php`:
- `host`: thường là `localhost`
- `port`: mặc định `3306`
- `database`: tên database đúng
- `username`: tên user đúng
- `password`: mật khẩu đúng

Nếu hosting cung cấp hostname khác `localhost` (ví dụ: `mysql.hostinger.com`), hãy đặt biến môi trường:
```
DB_HOST=mysql.hostinger.com
DB_PORT=3306
DB_NAME=kypcbhvj_manager_student
DB_USER=kypcbhvj_manager_student
DB_PASS=mật_khẩu_của_bạn
```

Một số hosting dùng Unix socket. Đặt:
```
DB_SOCKET=/var/run/mysqld/mysqld.sock
```

## Cấu hình với .htaccess (tùy chọn)

Tạo file `.htaccess` ở thư mục gốc (cùng cấp với `index.php`):

```apache
SetEnv DB_HOST "localhost"
SetEnv DB_PORT "3306"
SetEnv DB_NAME "kypcbhvj_manager_student"
SetEnv DB_USER "kypcbhvj_manager_student"
SetEnv DB_PASS "your_password_here"
```

## Test kết nối

Tạo file `test_db.php` ở thư mục gốc (NHỚ XÓA SAU KHI TEST):

```php
<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/core/Database.php';

try {
    $db = Database::getInstance();
    $row = $db->fetchOne('SELECT VERSION() AS v, DATABASE() AS d, USER() AS u');
    echo '<pre>';
    print_r($row);
    echo '</pre>';
    echo 'Connection OK!';
} catch (Throwable $e) {
    echo 'Error: ' . $e->getMessage();
}
```

Truy cập `https://yourdomain.com/test_db.php` để kiểm tra.
