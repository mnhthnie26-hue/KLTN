<?php
/**
 * Main Configuration
 */

declare(strict_types=1);

// Application
define('APP_NAME', 'Manager Student Quality Evaluation');
define('APP_VERSION', '1.0.0');
define('APP_ENV', getenv('APP_ENV') ?: 'production'); // production | development
// define('APP_DEBUG', getenv('APP_DEBUG') === '1' || APP_ENV === 'development');
define('APP_DEBUG', true);
// Auto-detect APP_URL from request if not set
$envAppUrl = getenv('APP_URL');
if (!$envAppUrl || $envAppUrl === '') {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    // Detect the install path; an app extracted directly into public_html has no base path.
    $scriptName = $_SERVER['SCRIPT_NAME'] ?? '';
    $basePath = str_replace('\\', '/', dirname($scriptName));
    // Strip /api/v1 or /api suffix if any
    $basePath = preg_replace('#/api(/v1)?$#', '', $basePath);
    $basePath = rtrim($basePath, '/');
    define('APP_URL', $protocol . '://' . $host . $basePath);
} else {
    define('APP_URL', $envAppUrl);
}

define('API_URL', APP_URL . '/api/v1');
define('APP_TIMEZONE', getenv('APP_TIMEZONE') ?: 'Asia/Ho_Chi_Minh');

date_default_timezone_set(APP_TIMEZONE);

// Paths
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}
define('CONFIG_PATH', ROOT_PATH . '/config');
define('CORE_PATH', ROOT_PATH . '/core');
define('STORAGE_PATH', ROOT_PATH . '/storage');
define('VIEWS_PATH', ROOT_PATH . '/views');
define('UPLOAD_PATH', STORAGE_PATH . '/uploads');

// Locale
define('APP_LOCALE', 'vi');
define('APP_CHARSET', 'utf-8');

// Session
define('SESSION_NAME', 'MSS_SESSION');
define('SESSION_LIFETIME', (int)(getenv('SESSION_LIFETIME') ?: 1800)); // 30 min

// Pagination
define('ITEMS_PER_PAGE', 20);
define('MAX_ITEMS_PER_PAGE', 100);

// Error handling
if (APP_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    // Respect the hosting's configured error_log (cPanel sets this outside public_html).
}

// Session security
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');

// Default headers
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');
header_remove('X-Powered-By');
