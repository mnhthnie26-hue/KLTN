<?php
/**
 * System Constants
 */

declare(strict_types=1);

// User types
const USER_TYPE_ADMIN    = 'admin';
const USER_TYPE_MANAGER  = 'manager';
const USER_TYPE_LECTURER = 'lecturer';
const USER_TYPE_STUDENT  = 'student';

// Survey status
const SURVEY_STATUS_DRAFT     = 'draft';
const SURVEY_STATUS_PUBLISHED = 'published';
const SURVEY_STATUS_CLOSED    = 'closed';
const SURVEY_STATUS_ARCHIVED  = 'archived';

// Question types
const QUESTION_TYPE_SINGLE   = 'single_choice';
const QUESTION_TYPE_MULTIPLE = 'multiple_choice';
const QUESTION_TYPE_RATING   = 'rating';
const QUESTION_TYPE_SCALE    = 'scale';
const QUESTION_TYPE_NUMBER   = 'number';
const QUESTION_TYPE_TEXT     = 'text';
const QUESTION_TYPE_TEXTAREA = 'textarea';

// Evaluation target types
const EVAL_TARGET_STUDENT    = 'student';
const EVAL_TARGET_LECTURER   = 'lecturer';
const EVAL_TARGET_MANAGER    = 'manager';
const EVAL_TARGET_DEPARTMENT = 'department';
const EVAL_TARGET_FACULTY    = 'faculty';
const EVAL_TARGET_OVERALL    = 'overall';

// Evaluation calculation methods
const EVAL_METHOD_AVERAGE  = 'average';
const EVAL_METHOD_WEIGHTED = 'weighted';
const EVAL_METHOD_AHP      = 'ahp';

// Classification labels
const CLASSIFICATION_EXCELLENT = 'Xuất sắc';
const CLASSIFICATION_GOOD      = 'Tốt';
const CLASSIFICATION_FAIR      = 'Khá';
const CLASSIFICATION_AVERAGE   = 'Trung bình';
const CLASSIFICATION_POOR      = 'Cần cải thiện';

// HTTP Status codes
const HTTP_OK           = 200;
const HTTP_CREATED      = 201;
const HTTP_NO_CONTENT   = 204;
const HTTP_BAD_REQUEST  = 400;
const HTTP_UNAUTHORIZED = 401;
const HTTP_FORBIDDEN    = 403;
const HTTP_NOT_FOUND    = 404;
const HTTP_CONFLICT     = 409;
const HTTP_UNPROCESSABLE = 422;
const HTTP_TOO_MANY     = 429;
const HTTP_SERVER_ERROR = 500;

// Report formats
const REPORT_FORMAT_CSV   = 'csv';
const REPORT_FORMAT_EXCEL = 'excel';
const REPORT_FORMAT_PDF  = 'pdf';
const REPORT_FORMAT_PRINT = 'print';

// Audit actions
const AUDIT_LOGIN            = 'login';
const AUDIT_LOGOUT           = 'logout';
const AUDIT_LOGIN_FAILED     = 'login_failed';
const AUDIT_CHANGE_PASSWORD  = 'change_password';
const AUDIT_CREATE           = 'create';
const AUDIT_UPDATE           = 'update';
const AUDIT_DELETE           = 'delete';
const AUDIT_PUBLISH          = 'publish';
const AUDIT_SUBMIT           = 'submit';
const AUDIT_EXPORT           = 'export';
const AUDIT_LOCK             = 'lock';
const AUDIT_UNLOCK           = 'unlock';
const AUDIT_RESET_PASSWORD   = 'reset_password';
const AUDIT_ASSIGN_ROLE      = 'assign_role';
const AUDIT_REVOKE_TOKEN     = 'revoke_token';