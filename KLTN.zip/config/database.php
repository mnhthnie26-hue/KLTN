<?php
/**
 * Database Configuration
 * Edit these values for your hosting environment.
 */

declare(strict_types=1);

return [
    'database' => getenv('DB_NAME') ?: 'kypcbhvj_manager_student',
    'username' => getenv('DB_USER') ?: 'kypcbhvj_manager_student',
    'password' => getenv('DB_PASS') ?: 'kypcbhvj_manager_student',
    'charset'  => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'options'  => [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
        PDO::ATTR_PERSISTENT         => false,
    ],
];
