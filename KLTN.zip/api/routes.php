<?php
/**
 * API Routes (v1)
 */

declare(strict_types=1);

// Public endpoints
$router->post('/auth/login', 'Api\AuthController@login', [new RateLimitMiddleware('api_login', 10, 60)]);
$router->post('/auth/refresh', 'Api\AuthController@refresh', [new RateLimitMiddleware('api_refresh', 30, 60)]);
$router->get('/health', 'Api\SystemController@health');

// Authenticated endpoints
$router->post('/auth/logout', 'Api\AuthController@logout', [ApiAuthMiddleware::class]);
$router->get('/auth/me', 'Api\AuthController@me', [ApiAuthMiddleware::class]);

// Users
$router->get('/users', 'Api\UsersController@index', [ApiAuthMiddleware::class]);
$router->get('/users/{id}', 'Api\UsersController@show', [ApiAuthMiddleware::class]);
$router->post('/users', 'Api\UsersController@create', [ApiAuthMiddleware::class]);
$router->put('/users/{id}', 'Api\UsersController@update', [ApiAuthMiddleware::class]);
$router->delete('/users/{id}', 'Api\UsersController@delete', [ApiAuthMiddleware::class]);

// KPIs
$router->get('/kpis', 'Api\KpisController@index', [ApiAuthMiddleware::class]);
$router->get('/kpis/{id}', 'Api\KpisController@show', [ApiAuthMiddleware::class]);
$router->post('/kpis', 'Api\KpisController@create', [ApiAuthMiddleware::class]);
$router->put('/kpis/{id}', 'Api\KpisController@update', [ApiAuthMiddleware::class]);
$router->delete('/kpis/{id}', 'Api\KpisController@delete', [ApiAuthMiddleware::class]);

// Criteria
$router->get('/criteria', 'Api\CriteriaController@index', [ApiAuthMiddleware::class]);
$router->get('/criteria/{id}', 'Api\CriteriaController@show', [ApiAuthMiddleware::class]);
$router->post('/criteria', 'Api\CriteriaController@create', [ApiAuthMiddleware::class]);
$router->put('/criteria/{id}', 'Api\CriteriaController@update', [ApiAuthMiddleware::class]);
$router->delete('/criteria/{id}', 'Api\CriteriaController@delete', [ApiAuthMiddleware::class]);

// Surveys
$router->get('/surveys', 'Api\SurveysController@index', [ApiAuthMiddleware::class]);
$router->get('/surveys/{id}', 'Api\SurveysController@show', [ApiAuthMiddleware::class]);
$router->post('/surveys', 'Api\SurveysController@create', [ApiAuthMiddleware::class]);
$router->put('/surveys/{id}', 'Api\SurveysController@update', [ApiAuthMiddleware::class]);
$router->delete('/surveys/{id}', 'Api\SurveysController@delete', [ApiAuthMiddleware::class]);
$router->post('/surveys/{id}/submit', 'Api\SurveysController@submit', [ApiAuthMiddleware::class, new RateLimitMiddleware('survey_submit_api', 5, 60)]);

// Evaluations
$router->get('/evaluations', 'Api\EvaluationsController@index', [ApiAuthMiddleware::class]);
$router->get('/evaluations/{id}', 'Api\EvaluationsController@show', [ApiAuthMiddleware::class]);
$router->post('/evaluations/calculate', 'Api\EvaluationsController@calculate', [ApiAuthMiddleware::class]);

// Statistics
$router->get('/statistics/survey/{id}', 'Api\StatisticsController@survey', [ApiAuthMiddleware::class]);

// Rankings
$router->get('/rankings', 'Api\RankingsController@index', [ApiAuthMiddleware::class]);

// Reports
$router->post('/reports/export', 'Api\ReportsController@export', [ApiAuthMiddleware::class]);