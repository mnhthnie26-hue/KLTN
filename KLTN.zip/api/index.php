<?php
/**
 * REST API Entry Point
 */

declare(strict_types=1);

define('IS_API', true);

// Define ROOT_PATH immediately
if (!defined('ROOT_PATH')) {
    define('ROOT_PATH', dirname(__DIR__));
}

// Disable direct access errors
error_reporting(E_ALL);
ini_set('display_errors', '0');

// Load config FIRST
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/constants.php';
require_once __DIR__ . '/../core/bootstrap.php';

if (file_exists(__DIR__ . '/../vendor/autoload.php')) {
    require_once __DIR__ . '/../vendor/autoload.php';
}

// Autoload
spl_autoload_register(function (string $class): void {
    // PSR-4 style: namespace -> folder mapping
    // Api\AuthController  -> api/v1/AuthController.php (relative to project root)
    $namespaceMap = [
        'Api\\'        => __DIR__ . '/v1/',
        'Core\\'       => __DIR__ . '/../core/',
        'Middleware\\' => __DIR__ . '/../middleware/',
        'Service\\'    => __DIR__ . '/../services/',
        'Repository\\' => __DIR__ . '/../repositories/',
    ];

    foreach ($namespaceMap as $prefix => $baseDir) {
        if (str_starts_with($class, $prefix)) {
            $relative = substr($class, strlen($prefix));
            $file = $baseDir . str_replace('\\', '/', $relative) . '.php';
            if (file_exists($file)) {
                require_once $file;
                return;
            }
        }
    }

    // Fallback: non-namespaced classes
    $directories = [
        __DIR__ . '/../core/',
        __DIR__ . '/../controllers/',
        __DIR__ . '/../services/',
        __DIR__ . '/../repositories/',
        __DIR__ . '/../middleware/',
    ];
    foreach ($directories as $dir) {
        $file = $dir . $class . '.php';
        if (file_exists($file)) {
            require_once $file;
            return;
        }
    }
});

require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../core/Request.php';
require_once __DIR__ . '/../core/Response.php';
require_once __DIR__ . '/../core/Router.php';
require_once __DIR__ . '/../core/View.php';
require_once __DIR__ . '/../core/Security.php';
require_once __DIR__ . '/../core/Session.php';
require_once __DIR__ . '/../core/Validator.php';
require_once __DIR__ . '/../core/Logger.php';
require_once __DIR__ . '/../core/Auth.php';
require_once __DIR__ . '/../core/Permission.php';
require_once __DIR__ . '/../core/TokenManager.php';
require_once __DIR__ . '/../core/CSRF.php';
require_once __DIR__ . '/../core/helpers.php';

if (!defined('APP_SECRET')) {
    define('APP_SECRET', getenv('APP_SECRET') ?: 'CHANGE-THIS-SECRET-IN-PRODUCTION-' . md5(__DIR__));
}

// Ensure storage directories exist
$storageDirs = [
    __DIR__ . '/../storage/logs',
    __DIR__ . '/../storage/exports',
];
foreach ($storageDirs as $dir) {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
}

// CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-CSRF-Token, X-Requested-With');
header('Access-Control-Max-Age: 86400');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Define BASE_PATH from SCRIPT_NAME so the router supports root and subfolder installs.
$scriptName = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
// For api/index.php, dirname points at the API entry directory.
$basePath = rtrim(str_replace('/index.php', '', dirname($scriptName)), '/');
if (!defined('BASE_PATH')) {
    define('BASE_PATH', $basePath);
}

$request = new Request();
$response = new Response();
$router = new Router();

// Load API routes
require_once __DIR__ . '/routes.php';

try {
    $router->dispatch($request, $response);
} catch (Throwable $e) {
    ErrorLog::critical('[api-dispatch] uncaught', [], $e);
    $response->error('Internal server error', ['message' => $e->getMessage()], 500)->send();
}
