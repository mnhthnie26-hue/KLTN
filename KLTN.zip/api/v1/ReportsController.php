<?php
namespace Api;

class ReportsController
{
    /**
     * Permission check with admin bypass.
     * Admins (user_type='admin') get a free pass on every permission gate.
     */
    private function requirePermission(string $perm): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) return ['error' => 'Unauthenticated', 'code' => 401];
        if (($user['user_type'] ?? null) === 'admin') return null;
        if (!in_array($perm, $user['permission_names'] ?? [], true)) {
            return ['error' => 'Forbidden', 'code' => 403];
        }
        return null;
    }

    public function export($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('report.export');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $data = $request->body();
        $type = $data['report_type'] ?? '';
        $format = $data['format'] ?? 'csv';

        $service = new \ReportService();
        $reportData = $service->getReportData($type, $data);
        $headers = $service->getReportHeaders($type);

        if (empty($reportData)) {
            $response->error('No data to export', null, 400)->send();
            return;
        }

        $filename = $type . '_' . date('Ymd_His');
        $filePath = '';

        switch ($format) {
            case 'csv':
                $filePath = $service->exportToCSV($reportData, $headers, $filename . '.csv');
                break;
            case 'excel':
                $filePath = $service->exportToExcel($reportData, $headers, $filename . '.xls');
                break;
            case 'pdf':
                $filePath = $service->exportToPDF($reportData, $headers, ucfirst($type), $filename . '.html');
                break;
            default:
                $response->error('Invalid format', null, 400)->send();
                return;
        }

        $user = $GLOBALS['__api_user'];
        $exportId = $service->recordExport((int)$user['id'], $type, $format, $filePath);

        $response->success([
            'export_id'   => $exportId,
            'file_url'    => url('reports/download/' . $exportId),
            'file_size'   => filesize($filePath),
            'expires_at'  => date('Y-m-d H:i:s', time() + 7 * 24 * 3600),
        ], 'Export completed')->send();
    }
}