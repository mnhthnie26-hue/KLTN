<?php
namespace Api;

class AuthController
{
    public function login($params, Request $request, Response $response): void
    {
        $username = $request->input('username');
        $password = $request->input('password');

        if (!$username || !$password) {
            $response->error('Username và password là bắt buộc', null, 400)->send();
            return;
        }

        $result = Auth::attempt($username, $password, false);

        if (!$result['success']) {
            $response->error($result['message'], null, 401)->send();
            return;
        }

        $userId = (int)$result['user']['id'];
        $token = TokenManager::generateAccessToken($userId, 'api');
        $refresh = TokenManager::generateRefreshToken($token['id']);

        $response->success([
            'user'  => [
                'id'         => $userId,
                'username'   => $result['user']['username'],
                'email'      => $result['user']['email'],
                'full_name'  => $result['user']['full_name'],
                'user_type'  => $result['user']['user_type'],
                'roles'      => $result['user']['role_names'] ?? [],
                'permissions'=> $result['user']['permission_names'] ?? [],
            ],
            'access_token'  => $token['access_token'],
            'refresh_token' => $refresh['refresh_token'],
            'token_type'    => 'Bearer',
            'expires_in'    => $token['expires_in'],
            'expires_at'    => $token['expires_at'],
        ], 'Đăng nhập thành công')->send();
    }

    public function refresh($params, Request $request, Response $response): void
    {
        $refreshToken = $request->input('refresh_token');
        if (!$refreshToken) {
            $response->error('Missing refresh_token', null, 400)->send();
            return;
        }

        $result = TokenManager::refresh($refreshToken);
        if (!$result) {
            $response->error('Invalid or expired refresh token', null, 401)->send();
            return;
        }

        $newRefresh = TokenManager::generateRefreshToken($result['id']);

        $response->success([
            'access_token'  => $result['access_token'],
            'refresh_token' => $newRefresh['refresh_token'],
            'token_type'    => 'Bearer',
            'expires_in'    => $result['expires_in'],
            'expires_at'    => $result['expires_at'],
        ], 'Token refreshed')->send();
    }

    public function logout($params, Request $request, Response $response): void
    {
        $token = $request->bearerToken();
        if ($token) {
            TokenManager::revoke($token);
        }
        $response->success(null, 'Đã đăng xuất')->send();
    }

    public function me($params, Request $request, Response $response): void
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) {
            $response->error('Unauthenticated', null, 401)->send();
            return;
        }
        $response->success([
            'id'         => (int)$user['id'],
            'username'   => $user['username'],
            'email'      => $user['email'],
            'full_name'  => $user['full_name'],
            'user_type'  => $user['user_type'],
            'roles'      => $user['role_names'] ?? [],
            'permissions'=> $user['permission_names'] ?? [],
        ])->send();
    }
}