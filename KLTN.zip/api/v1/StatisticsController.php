<?php
namespace Api;

class StatisticsController
{
    /**
     * Permission check with admin bypass.
     * Admins (user_type='admin') get a free pass on every permission gate.
     */
    private function requirePermission(string $perm): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) return ['error' => 'Unauthenticated', 'code' => 401];
        if (($user['user_type'] ?? null) === 'admin') return null;
        if (!in_array($perm, $user['permission_names'] ?? [], true)) {
            return ['error' => 'Forbidden', 'code' => 403];
        }
        return null;
    }

    public function survey($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('analysis.statistics');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $stats = (new \StatisticsService())->getSurveyStatistics($id);

        if (empty($stats)) { $response->error('Survey not found', null, 404)->send(); return; }

        $response->success($stats)->send();
    }
}