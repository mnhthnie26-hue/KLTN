<?php
namespace Api;

class RankingsController
{
    /**
     * Permission check with admin bypass.
     * Admins (user_type='admin') get a free pass on every permission gate.
     */
    private function requirePermission(string $perm): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) return ['error' => 'Unauthenticated', 'code' => 401];
        if (($user['user_type'] ?? null) === 'admin') return null;
        if (!in_array($perm, $user['permission_names'] ?? [], true)) {
            return ['error' => 'Forbidden', 'code' => 403];
        }
        return null;
    }

    public function index($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('ranking.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $type = $request->query('type', 'overall');
        $period = $request->query('period', '');
        $kpiId = (int)$request->query('kpi_id', 0);

        $service = new \RankingService();
        switch ($type) {
            case 'kpi':
                $rankings = $service->getRankingByKpi($period);
                break;
            case 'criterion':
                $rankings = $kpiId ? $service->getRankingByCriterion($kpiId) : [];
                break;
            default:
                $rankings = $service->getOverallRanking(20, $period);
        }

        $response->success(['items' => $rankings, 'type' => $type])->send();
    }
}