<?php
namespace Api;

class EvaluationsController
{
    /**
     * Permission check with admin bypass.
     * Admins (user_type='admin') get a free pass on every permission gate.
     */
    private function requirePermission(string $perm): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) return ['error' => 'Unauthenticated', 'code' => 401];
        if (($user['user_type'] ?? null) === 'admin') return null;
        if (!in_array($perm, $user['permission_names'] ?? [], true)) {
            return ['error' => 'Forbidden', 'code' => 403];
        }
        return null;
    }

    public function index($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('evaluation.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $page = max(1, (int)$request->query('page', 1));
        $perPage = min(100, max(1, (int)$request->query('per_page', 20)));
        $result = (new \EvaluationService())->list($page, $perPage, []);

        $response->success([
            'items' => $result['items'],
            'meta'  => $result['pagination'],
        ])->send();
    }

    public function show($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('evaluation.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $evaluation = (new \EvaluationService())->get($id);

        if (!$evaluation) { $response->error('Evaluation not found', null, 404)->send(); return; }

        $response->success($evaluation)->send();
    }

    public function calculate($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('evaluation.calculate');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $data = $request->body();
        $surveyId = (int)($data['survey_id'] ?? 0);
        $period = $data['period'] ?? null;

        if (!$surveyId) {
            $response->error('survey_id required', null, 400)->send();
            return;
        }

        $result = (new \EvaluationService())->calculateForSurvey($surveyId, $period);

        if (!$result) {
            $response->error('Cannot calculate', null, 400)->send();
            return;
        }

        $response->success($result, 'Đã tính điểm thành công', 201)->send();
    }
}