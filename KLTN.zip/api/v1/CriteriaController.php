<?php
namespace Api;

class CriteriaController
{
    /**
     * Permission check with admin bypass.
     * Admins (user_type='admin') get a free pass on every permission gate.
     */
    private function requirePermission(string $perm): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) return ['error' => 'Unauthenticated', 'code' => 401];
        if (($user['user_type'] ?? null) === 'admin') return null;
        if (!in_array($perm, $user['permission_names'] ?? [], true)) {
            return ['error' => 'Forbidden', 'code' => 403];
        }
        return null;
    }

    public function index($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('criteria.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $kpiId = (int)$request->query('kpi_id', 0);
        if (!$kpiId) {
            $response->error('kpi_id required', null, 400)->send();
            return;
        }

        $criteria = (new \CriterionRepository())->getByKpi($kpiId);
        $response->success(['items' => $criteria])->send();
    }

    public function show($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('criteria.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $c = (new \CriterionRepository())->find($id);

        if (!$c) { $response->error('Criterion not found', null, 404)->send(); return; }

        $response->success($c)->send();
    }

    public function create($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('criteria.create');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $data = $request->body();
        $result = (new \CriterionService())->create($data);

        if (!$result['success']) {
            $response->error($result['message'], $result['errors'] ?? null, 400)->send();
            return;
        }

        $c = (new \CriterionRepository())->find($result['id']);
        $response->success($c, $result['message'], 201)->send();
    }

    public function update($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('criteria.update');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $data = $request->body();
        $result = (new \CriterionService())->update($id, $data);

        if (!$result['success']) {
            $response->error($result['message'], $result['errors'] ?? null, 400)->send();
            return;
        }

        $c = (new \CriterionRepository())->find($id);
        $response->success($c, $result['message'])->send();
    }

    public function delete($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('criteria.delete');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $result = (new \CriterionService())->delete($id);

        if (!$result['success']) {
            $response->error($result['message'], null, 400)->send();
            return;
        }

        $response->success(null, $result['message'])->send();
    }
}