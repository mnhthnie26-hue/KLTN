<?php
namespace Api;

class UsersController
{
    /**
     * Permission check with admin bypass.
     * Admins (user_type='admin') get a free pass on every permission gate.
     */
    private function requirePermission(string $perm): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) return ['error' => 'Unauthenticated', 'code' => 401];
        if (($user['user_type'] ?? null) === 'admin') return null;
        if (!in_array($perm, $user['permission_names'] ?? [], true)) {
            return ['error' => 'Forbidden', 'code' => 403];
        }
        return null;
    }

    public function index($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('users.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $page = max(1, (int)$request->query('page', 1));
        $perPage = min(100, max(1, (int)$request->query('per_page', 20)));
        $filters = [
            'search'    => trim($request->query('search', '')),
            'user_type' => $request->query('user_type', ''),
            'status'    => $request->query('status', ''),
        ];

        $result = (new \UserRepository())->getUsers($page, $perPage, $filters);

        $response->success([
            'items' => $result['items'],
            'meta'  => $result['pagination'],
        ])->send();
    }

    public function show($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('users.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $user = (new \UserService())->getUser($id);

        if (!$user) {
            $response->error('User not found', null, 404)->send();
            return;
        }

        unset($user['password']);
        $response->success($user)->send();
    }

    public function create($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('users.create');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $data = $request->body();
        $roleIds = $data['roles'] ?? [];
        unset($data['roles']);

        $result = (new \UserService())->createUser($data, $roleIds);

        if (!$result['success']) {
            $response->error($result['message'], $result['errors'] ?? null, 400)->send();
            return;
        }

        $user = (new \UserService())->getUser($result['id']);
        $response->success($user, $result['message'], 201)->send();
    }

    public function update($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('users.update');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $data = $request->body();
        $roleIds = $data['roles'] ?? null;
        if ($roleIds !== null) unset($data['roles']);

        $result = (new \UserService())->updateUser($id, $data, $roleIds);

        if (!$result['success']) {
            $response->error($result['message'], $result['errors'] ?? null, 400)->send();
            return;
        }

        $user = (new \UserService())->getUser($id);
        $response->success($user, $result['message'])->send();
    }

    public function delete($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('users.delete');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $result = (new \UserService())->deleteUser($id);

        if (!$result['success']) {
            $response->error($result['message'], null, 400)->send();
            return;
        }

        $response->success(null, $result['message'])->send();
    }
}