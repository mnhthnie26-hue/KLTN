<?php
namespace Api;

class SystemController
{
    public function health($params, Request $request, Response $response): void
    {
        $response->success([
            'status'    => 'ok',
            'time'      => date('c'),
            'version'   => APP_VERSION,
            'database'  => 'connected',
        ])->send();
    }
}