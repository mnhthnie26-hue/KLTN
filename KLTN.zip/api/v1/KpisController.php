<?php
namespace Api;

class KpisController
{
    private function requirePermission(string $perm): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) return ['error' => 'Unauthenticated', 'code' => 401];
        if (!in_array($perm, $user['permission_names'] ?? [], true)) {
            return ['error' => 'Forbidden', 'code' => 403];
        }
        return null;
    }

    public function index($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('kpi.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $kpis = (new \KpiRepository())->getAllWithGroup();
        $response->success(['items' => $kpis])->send();
    }

    public function show($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('kpi.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $kpi = (new \KpiService())->getKpi($id);

        if (!$kpi) { $response->error('KPI not found', null, 404)->send(); return; }

        $response->success($kpi)->send();
    }

    public function create($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('kpi.create');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $data = $request->body();
        $result = (new \KpiService())->createKpi($data);

        if (!$result['success']) {
            $response->error($result['message'], $result['errors'] ?? null, 400)->send();
            return;
        }

        $kpi = (new \KpiService())->getKpi($result['id']);
        $response->success($kpi, $result['message'], 201)->send();
    }

    public function update($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('kpi.update');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $data = $request->body();
        $result = (new \KpiService())->updateKpi($id, $data);

        if (!$result['success']) {
            $response->error($result['message'], $result['errors'] ?? null, 400)->send();
            return;
        }

        $kpi = (new \KpiService())->getKpi($id);
        $response->success($kpi, $result['message'])->send();
    }

    public function delete($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('kpi.delete');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $result = (new \KpiService())->deleteKpi($id);

        if (!$result['success']) {
            $response->error($result['message'], null, 400)->send();
            return;
        }

        $response->success(null, $result['message'])->send();
    }
}