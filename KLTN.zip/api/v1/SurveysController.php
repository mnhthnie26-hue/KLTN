<?php
namespace Api;

class SurveysController
{
    private function requirePermission(string $perm): ?array
    {
        $user = $GLOBALS['__api_user'] ?? null;
        if (!$user) return ['error' => 'Unauthenticated', 'code' => 401];
        if (!in_array($perm, $user['permission_names'] ?? [], true)) {
            return ['error' => 'Forbidden', 'code' => 403];
        }
        return null;
    }

    public function index($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('survey.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $page = max(1, (int)$request->query('page', 1));
        $perPage = min(100, max(1, (int)$request->query('per_page', 20)));
        $filters = [
            'search' => trim($request->query('search', '')),
            'status' => $request->query('status', ''),
        ];

        $result = (new \SurveyService())->list($page, $perPage, $filters);
        $response->success([
            'items' => $result['items'],
            'meta'  => $result['pagination'],
        ])->send();
    }

    public function show($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('survey.view');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $survey = (new \SurveyService())->get($id);

        if (!$survey) { $response->error('Survey not found', null, 404)->send(); return; }

        $response->success($survey)->send();
    }

    public function create($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('survey.create');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $data = $request->body();
        $result = (new \SurveyService())->create($data);

        if (!$result['success']) {
            $response->error($result['message'], $result['errors'] ?? null, 400)->send();
            return;
        }

        $survey = (new \SurveyService())->get($result['id']);
        $response->success($survey, $result['message'], 201)->send();
    }

    public function update($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('survey.update');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $data = $request->body();
        $result = (new \SurveyService())->update($id, $data);

        if (!$result['success']) {
            $response->error($result['message'], null, 400)->send();
            return;
        }

        $survey = (new \SurveyService())->get($id);
        $response->success($survey, $result['message'])->send();
    }

    public function delete($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('survey.delete');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $result = (new \SurveyService())->delete($id);

        if (!$result['success']) {
            $response->error($result['message'], null, 400)->send();
            return;
        }

        $response->success(null, $result['message'])->send();
    }

    public function submit($params, Request $request, Response $response): void
    {
        $err = $this->requirePermission('survey.submit');
        if ($err) { $response->error($err['error'], null, $err['code'])->send(); return; }

        $id = (int)($params['id'] ?? 0);
        $user = $GLOBALS['__api_user'];

        $survey = (new \SurveyService())->get($id);
        if (!$survey || $survey['status'] !== 'published') {
            $response->error('Survey not available', null, 400)->send();
            return;
        }

        $answers = (array)($request->body()['answers'] ?? []);
        $db = \Database::getInstance();

        try {
            $responseId = $db->transaction(function() use ($db, $survey, $user, $answers) {
                $rid = $db->insert('survey_responses', [
                    'survey_id'      => $survey['id'],
                    'respondent_id'  => $survey['allow_anonymous'] ? null : (int)$user['id'],
                    'respondent_type'=> $survey['allow_anonymous'] ? 'anonymous' : ($user['user_type'] ?? null),
                    'submitted_at'   => date('Y-m-d H:i:s'),
                    'status'         => 'submitted',
                    'ip_address'     => $_SERVER['REMOTE_ADDR'] ?? null,
                ]);

                foreach ($survey['questions'] as $q) {
                    $answer = $answers[$q['id']] ?? null;
                    if (empty($answer) && $answer !== '0' && $answer !== '0.0') continue;

                    $score = null;
                    $optionId = null;
                    $answerText = null;
                    $answerNumber = null;

                    if (in_array($q['question_type'], ['single_choice', 'rating', 'scale'])) {
                        $optionId = (int)$answer;
                        foreach ($q['options'] as $opt) {
                            if ((int)$opt['id'] === $optionId) {
                                $score = $opt['option_value'];
                                $answerNumber = $opt['option_value'];
                                break;
                            }
                        }
                    } elseif ($q['question_type'] === 'number') {
                        $answerNumber = (float)$answer;
                        $score = $answerNumber;
                    } else {
                        $answerText = \Security::sanitize($answer);
                    }

                    $db->insert('survey_answers', [
                        'response_id'    => $rid,
                        'question_id'    => $q['id'],
                        'option_id'      => $optionId,
                        'answer_text'    => $answerText,
                        'answer_number'  => $answerNumber,
                        'score'          => $score,
                    ]);
                }

                return $rid;
            });

            $response->success(['response_id' => $responseId], 'Cảm ơn bạn đã tham gia khảo sát', 201)->send();
        } catch (Throwable $e) {
            ErrorLog::error('[Api\SurveysController::submit] failed', ['sid' => $id ?? null], $e);
            $response->error('Submit failed: ' . $e->getMessage(), null, 500)->send();
        }
    }
}