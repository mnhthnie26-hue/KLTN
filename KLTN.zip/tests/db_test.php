<?php
// Quick test to verify Database layer after the fix.
// Run from project root: php tests/db_test.php

declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../core/Session.php';
require_once __DIR__ . '/../core/Security.php';

if (defined('APP_DEBUG') === false) {
    define('APP_DEBUG', true);
}

$db = Database::getInstance();
$db->pdo()->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$results = [];
$failed = 0;

function test(string $name, callable $fn) {
    global $failed;
    try {
        $fn();
        echo "[OK]   $name\n";
    } catch (Throwable $e) {
        $failed++;
        echo "[FAIL] $name => " . $e->getMessage() . "\n";
    }
}

// 1) insert with explicit null
test('insert user with nulls', function() use ($db) {
    $db->beginTransaction();
    try {
        $id = $db->insert('users', [
            'username' => 'test_user_' . uniqid(),
            'email'    => 'test_' . uniqid() . '@example.com',
            'password' => password_hash('123456', PASSWORD_BCRYPT),
            'full_name'=> 'Test',
            'user_type'=> 'student',
            'status'   => 1,
            'faculty_id'   => null,
            'department_id'=> null,
            'student_code' => '',
            'must_change_password' => 0,
        ]);
        if ($id <= 0) throw new RuntimeException('No insert id');
        $db->query('DELETE FROM users WHERE id = ?', [$id]);
    } finally {
        $db->rollback();
    }
});

// 2) update with null
test('update user set nulls', function() use ($db) {
    $db->beginTransaction();
    try {
        $id = $db->insert('users', [
            'username' => 'test_user_' . uniqid(),
            'email'    => 'test_' . uniqid() . '@example.com',
            'password' => password_hash('123456', PASSWORD_BCRYPT),
            'full_name'=> 'Test',
            'user_type'=> 'student',
            'status'   => 1,
            'must_change_password' => 0,
        ]);
        $db->update('users', [
            'faculty_id'   => null,
            'department_id'=> null,
            'locked_until' => null,
            'remember_token' => null,
        ], 'id = :id', ['id' => $id]);
        $db->query('DELETE FROM users WHERE id = ?', [$id]);
    } finally {
        $db->rollback();
    }
});

// 3) update password (real flow)
test('update password (mimic Auth::changePassword)', function() use ($db) {
    $db->beginTransaction();
    try {
        $id = $db->insert('users', [
            'username' => 'test_user_' . uniqid(),
            'email'    => 'test_' . uniqid() . '@example.com',
            'password' => password_hash('123456', PASSWORD_BCRYPT),
            'full_name'=> 'Test',
            'user_type'=> 'student',
            'status'   => 1,
            'must_change_password' => 0,
        ]);
        $newHash = password_hash('newpass', PASSWORD_BCRYPT);
        $db->update('users', [
            'password' => $newHash,
            'must_change_password' => 0,
            'remember_token' => null,
        ], 'id = :id', ['id' => $id]);
        $db->query('DELETE FROM users WHERE id = ?', [$id]);
    } finally {
        $db->rollback();
    }
});

// 4) select with positional ? placeholders
test('select users positional', function() use ($db) {
    $rows = $db->fetchAll('SELECT id, username FROM users WHERE id > ? LIMIT 5', [0]);
    if (!is_array($rows)) throw new RuntimeException('Not array');
});

// 5) select with named :name placeholders
test('select users named', function() use ($db) {
    $rows = $db->fetchAll('SELECT id, username FROM users WHERE id > :min LIMIT 5', ['min' => 0]);
    if (!is_array($rows)) throw new RuntimeException('Not array');
});

// 6) transaction
test('transaction', function() use ($db) {
    $result = $db->transaction(function() use ($db) {
        return 42;
    });
    if ($result !== 42) throw new RuntimeException('Wrong return');
});

// 7) update with bool
test('update bool field', function() use ($db) {
    $db->beginTransaction();
    try {
        $id = $db->insert('users', [
            'username' => 'test_user_' . uniqid(),
            'email'    => 'test_' . uniqid() . '@example.com',
            'password' => password_hash('123456', PASSWORD_BCRYPT),
            'full_name'=> 'Test',
            'user_type'=> 'student',
            'status'   => 1,
            'must_change_password' => 0,
        ]);
        $db->update('users', [
            'status' => 0,
            'must_change_password' => 1,
        ], 'id = :id', ['id' => $id]);
        $db->query('DELETE FROM users WHERE id = ?', [$id]);
    } finally {
        $db->rollback();
    }
});

if ($failed > 0) {
    echo "\n$failed test(s) FAILED\n";
    exit(1);
}
echo "\nAll tests passed!\n";
