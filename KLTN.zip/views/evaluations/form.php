<?php
/** @var array $surveys */
/** @var array $kpis */
?>
<div class="page-header">
    <h1 class="page-title">Tạo Đánh giá</h1>
    <a href="<?= url('evaluations') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= url('evaluations') ?>">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

            <div class="form-group">
                <label>Chọn khảo sát đã đóng <span class="required">*</span></label>
                <select name="survey_id" required class="form-control">
                    <option value="">-- Chọn --</option>
                    <?php foreach ($surveys as $s): ?>
                    <option value="<?= $s['id'] ?>"><?= e($s['title']) ?></option>
                    <?php endforeach; ?>
                </select>
                <small class="form-hint">Khảo sát phải liên kết với KPI có tiêu chí và tổng trọng số = 100%</small>
            </div>

            <div class="form-group">
                <label>Kỳ đánh giá</label>
                <input type="text" name="period" placeholder="VD: 2025-H1, 2025-Q1" class="form-control">
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Tính điểm</button>
                <a href="<?= url('evaluations') ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>