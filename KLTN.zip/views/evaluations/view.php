<?php
/** @var array $evaluation */
?>
<div class="page-header">
    <h1 class="page-title"><?= e($evaluation['name']) ?></h1>
    <a href="<?= url('evaluations') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card stat-card-<?= $evaluation['normalized_score'] >= 80 ? 'success' : ($evaluation['normalized_score'] >= 50 ? 'warning' : 'danger') ?>">
            <div class="card-body text-center">
                <div class="stat-label">ĐIỂM TỔNG</div>
                <div class="stat-value" style="font-size:48px;"><?= number_format((float)$evaluation['normalized_score'], 2) ?></div>
                <div class="stat-trend" style="font-size:18px; font-weight:600;"><?= e($evaluation['classification'] ?? '') ?></div>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3>Thông tin</h3></div>
            <div class="card-body">
                <p><strong>KPI:</strong> <?= e($evaluation['kpi_name'] ?? '-') ?></p>
                <p><strong>Khảo sát:</strong> <?= e($evaluation['survey_title'] ?? '-') ?></p>
                <p><strong>Kỳ:</strong> <?= e($evaluation['period'] ?? '-') ?></p>
                <p><strong>Phương pháp:</strong> <?= e($evaluation['calculation_method']) ?></p>
                <p><strong>Ngày tính:</strong> <?= e(formatDateTime($evaluation['calculated_at'])) ?></p>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header"><h3>Chi tiết điểm tiêu chí</h3></div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>Tiêu chí</th>
                    <th>Điểm gốc</th>
                    <th>Điểm chuẩn hóa (0-100)</th>
                    <th>Trọng số</th>
                    <th>Điểm có trọng số</th>
                    <th>Số phản hồi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($evaluation['scores'] as $s): ?>
                <tr>
                    <td><?= e($s['criterion_name']) ?></td>
                    <td><?= $s['raw_score'] !== null ? number_format((float)$s['raw_score'], 2) : '-' ?></td>
                    <td><?= $s['normalized_score'] !== null ? number_format((float)$s['normalized_score'], 2) : '-' ?></td>
                    <td><?= number_format((float)$s['weight'], 2) ?>%</td>
                    <td><strong><?= $s['weighted_score'] !== null ? number_format((float)$s['weighted_score'], 2) : '-' ?></strong></td>
                    <td><?= (int)$s['response_count'] ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>