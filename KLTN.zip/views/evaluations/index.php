<?php
/** @var array $evaluations */
/** @var array $pagination */
/** @var array $kpis */
/** @var array $filters */
?>
<div class="page-header">
    <h1 class="page-title">Đánh giá Chất lượng</h1>
    <?php if (Auth::hasPermission('evaluation.create')): ?>
    <a href="<?= url('evaluations/create') ?>" class="btn btn-primary">+ Tạo đánh giá</a>
    <?php endif; ?>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('evaluations') ?>" class="filter-form">
            <select name="kpi_id" class="form-control">
                <option value="">Tất cả KPI</option>
                <?php foreach ($kpis as $k): ?>
                <option value="<?= $k['id'] ?>" <?= (int)$filters['kpi_id'] === (int)$k['id'] ? 'selected' : '' ?>><?= e($k['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="text" name="period" value="<?= e($filters['period']) ?>" placeholder="Kỳ (vd: 2025-H1)" class="form-control">
        </form>

        <?php if (empty($evaluations)): ?>
        <div class="empty-state"><p>Chưa có đánh giá nào.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên</th>
                        <th>KPI</th>
                        <th>Kỳ</th>
                        <th>Điểm</th>
                        <th>Xếp loại</th>
                        <th>Phương pháp</th>
                        <th>Ngày tính</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($evaluations as $e): ?>
                    <tr>
                        <td>#<?= $e['id'] ?></td>
                        <td><a href="<?= url('evaluations/' . $e['id']) ?>"><?= e($e['name']) ?></a></td>
                        <td><?= e($e['kpi_name'] ?? '-') ?></td>
                        <td><?= e($e['period'] ?? '-') ?></td>
                        <td><strong><?= $e['normalized_score'] !== null ? number_format((float)$e['normalized_score'], 2) : '-' ?></strong></td>
                        <td><?= e($e['classification'] ?? '-') ?></td>
                        <td><?= e($e['calculation_method']) ?></td>
                        <td><?= e(formatDateTime($e['calculated_at'])) ?></td>
                        <td><a href="<?= url('evaluations/' . $e['id']) ?>" class="btn btn-sm btn-secondary">Xem</a></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= render_pagination($pagination, '?' . http_build_query(array_filter($filters))) ?>
        <?php endif; ?>
    </div>
</div>