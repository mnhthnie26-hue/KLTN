<?php require_once __DIR__ . '/icons.php'; ?>
<nav class="quick-dock" aria-label="Thao tác nhanh">
    <?php if (Auth::hasPermission('survey.create')): ?>
    <a class="qd-green" href="<?= url('surveys/create') ?>" aria-label="Tạo khảo sát"><?= icon('survey') ?></a>
    <?php endif; ?>
    <?php if (Auth::hasPermission('evaluation.view')): ?>
    <a class="qd-orange" href="<?= url('evaluations') ?>" aria-label="Đánh giá"><?= icon('eval') ?></a>
    <?php endif; ?>
    <?php if (Auth::hasPermission('analysis.statistics')): ?>
    <a class="qd-violet" href="<?= url('analysis/statistics') ?>" aria-label="Thống kê"><?= icon('stats') ?></a>
    <?php endif; ?>
    <?php if (Auth::hasPermission('report.view')): ?>
    <a class="qd-blue" href="<?= url('reports') ?>" aria-label="Báo cáo"><?= icon('report') ?></a>
    <?php endif; ?>
    <?php if (Auth::hasPermission('settings.view')): ?>
    <a class="qd-red" href="<?= url('settings') ?>" aria-label="Cài đặt"><?= icon('settings') ?></a>
    <?php endif; ?>
</nav>
<button class="scroll-top" id="scrollTop" type="button" aria-label="Lên đầu trang"><?= icon('up') ?></button>
