<?php
/**
 * App Layout — dashboard (chuẩn SEO, responsive)
 *
 * Biến tuỳ chọn mà controller có thể truyền vào view:
 *   $pageTitle, $pageDescription, $canonicalUrl, $ogImage, $robots
 */
require_once __DIR__ . '/icons.php';

$appTitle  = getSetting('app.name', APP_NAME);
$seoDesc   = $pageDescription
    ?? (getSetting('seo.site_description', '') ?: ($appTitle . ' - Hệ thống quản lý KPI, khảo sát và đánh giá chất lượng đào tạo.'));
$seoDesc   = mb_substr(trim(preg_replace('/\s+/u', ' ', strip_tags((string)$seoDesc))), 0, 160);
$fullTitle = trim(($pageTitle ?? '') !== '' ? ($pageTitle . ' | ' . $appTitle) : $appTitle);
$reqPath   = (string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
$basePath  = (string)parse_url(APP_URL, PHP_URL_PATH);
$relPath   = ($basePath !== '' && $basePath !== '/' && str_starts_with($reqPath, $basePath)) ? substr($reqPath, strlen($basePath)) : $reqPath;
$canonical = $canonicalUrl ?? rtrim(APP_URL, '/') . '/' . ltrim($relPath, '/');
$robots    = $robots ?? getSetting('seo.robots', 'noindex,nofollow'); // khu vực quản trị: mặc định không index
$ogImage   = $ogImage ?? asset('images/og-cover.png');
$siteUrl   = rtrim(APP_URL, '/') . '/';
$crumbs    = [['@type' => 'ListItem', 'position' => 1, 'name' => $appTitle, 'item' => $siteUrl]];
if (trim((string)($pageTitle ?? '')) !== '') {
    $crumbs[] = ['@type' => 'ListItem', 'position' => 2, 'name' => (string)$pageTitle, 'item' => $canonical];
}
$jsonLd    = [
    '@context' => 'https://schema.org',
    '@graph'   => [
        [
            '@type'      => 'WebSite',
            '@id'        => $siteUrl . '#website',
            'url'        => $siteUrl,
            'name'       => $appTitle,
            'inLanguage' => 'vi-VN',
        ],
        [
            '@type'               => 'WebApplication',
            '@id'                 => $siteUrl . '#app',
            'name'                => $appTitle,
            'description'         => $seoDesc,
            'url'                 => $siteUrl,
            'applicationCategory' => 'EducationalApplication',
            'operatingSystem'     => 'Web',
            'inLanguage'          => 'vi-VN',
            'isPartOf'            => ['@id' => $siteUrl . '#website'],
        ],
        [
            '@type'           => 'BreadcrumbList',
            'itemListElement' => $crumbs,
        ],
    ],
];
$isDashboardPage = str_contains($content, 'chart') || ($pageTitle ?? '') === 'Tổng quan';
?>
<!DOCTYPE html>
<html lang="vi" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <title><?= e($fullTitle) ?></title>
    <meta name="description" content="<?= e($seoDesc) ?>">
    <meta name="robots" content="<?= e($robots) ?>">
    <meta name="author" content="<?= e($appTitle) ?>">
    <meta name="application-name" content="<?= e($appTitle) ?>">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-title" content="<?= e($appTitle) ?>">
    <meta name="format-detection" content="telephone=no">
    <meta name="theme-color" content="#6366f1">
    <meta name="color-scheme" content="light">
    <link rel="canonical" href="<?= e($canonical) ?>">
    <link rel="alternate" hreflang="vi" href="<?= e($canonical) ?>">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?= e($appTitle) ?>">
    <meta property="og:title" content="<?= e($fullTitle) ?>">
    <meta property="og:description" content="<?= e($seoDesc) ?>">
    <meta property="og:url" content="<?= e($canonical) ?>">
    <meta property="og:image" content="<?= e($ogImage) ?>">
    <meta property="og:image:alt" content="<?= e($appTitle) ?>">
    <meta property="og:locale" content="vi_VN">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?= e($fullTitle) ?>">
    <meta name="twitter:description" content="<?= e($seoDesc) ?>">
    <meta name="twitter:image" content="<?= e($ogImage) ?>">
    <meta name="twitter:image:alt" content="<?= e($appTitle) ?>">
    <link rel="icon" type="image/x-icon" href="<?= asset('images/favicon.ico') ?>">
    <link rel="apple-touch-icon" href="<?= asset('images/favicon.ico') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <?php if ($isDashboardPage): ?><link rel="dns-prefetch" href="https://cdn.jsdelivr.net"><?php endif; ?>

    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800&amp;display=swap" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800&amp;display=swap"></noscript>
    <link rel="stylesheet" href="<?= asset('css/main.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/toast.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/confirm.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/dashboard.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/responsive.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/theme-pro.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/layout-fix.css') ?>">
    <script>try{if(localStorage.getItem('sidebarCollapsed')==='1'&&window.innerWidth>1024){document.documentElement.classList.add('sidebar-collapsed')}}catch(e){}</script>
    <script type="application/ld+json"><?= json_encode($jsonLd, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?></script>
</head>
<body class="app-body">
    <a class="skip-link" href="#main-content">Bỏ qua đến nội dung chính</a>

    <?= View::renderPartial('layouts/header', ['user' => $user ?? Auth::user()]) ?>

    <div class="app-wrapper">
        <?= View::renderPartial('layouts/sidebar', ['user' => $user ?? Auth::user()]) ?>

        <main class="app-main" id="main-content" tabindex="-1">
            <div class="app-content">
                <?= View::renderPartial('layouts/alerts', [
                    'success' => $success ?? Session::flash('success'),
                    'error'   => $error ?? Session::flash('error'),
                    'warning' => $warning ?? Session::flash('warning'),
                    'info'    => $info ?? Session::flash('info'),
                ]) ?>

                <?= $content ?>
            </div>
            <?= View::renderPartial('layouts/footer') ?>
        </main>
    </div>

    <?= View::renderPartial('layouts/dock') ?>

    <script src="<?= asset('js/toast.js') ?>" defer></script>
    <script src="<?= asset('js/confirm.js') ?>" defer></script>
    <script src="<?= asset('js/main.js') ?>" defer></script>
    <script src="<?= asset('js/ajax.js') ?>" defer></script>
    <script src="<?= asset('js/autofilter.js') ?>" defer></script>
    <?php if ($isDashboardPage): ?>
    <script src="<?= asset('js/charts.js') ?>" defer></script>
    <?php endif; ?>
</body>
</html>
