<?php
/** @var array|null $user */
require_once __DIR__ . '/icons.php';
$user = $user ?? Auth::user();
$brandName = getSetting('app.name', APP_NAME);
?>
<header class="app-header" id="appHeader" role="banner">
    <div class="header-left">
        <button class="icon-btn sidebar-toggle" id="sidebarToggle" type="button" aria-label="Mở/đóng menu" aria-controls="appSidebar" aria-expanded="false">
            <?= icon('menu') ?>
        </button>
        <a href="<?= url('dashboard') ?>" class="brand" aria-label="<?= e($brandName) ?> - Trang chủ">
            <span class="brand-mark" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($brandName, 0, 1))) ?></span>
            <span class="brand-text"><?= e($brandName) ?></span>
        </a>
    </div>

    <div class="header-search" role="search">
        <label class="header-search-field" for="globalSearch">
            <?= icon('search') ?>
            <span class="sr-only">Tìm chức năng</span>
            <input type="search" id="globalSearch" placeholder="Tìm chức năng..." autocomplete="off" aria-controls="searchResults" aria-expanded="false">
            <kbd aria-hidden="true">/</kbd>
        </label>
        <ul class="search-results" id="searchResults" role="listbox" aria-label="Kết quả tìm kiếm"></ul>
    </div>

    <div class="header-right">
        <button class="icon-btn header-search-toggle" id="searchToggle" type="button" aria-label="Tìm kiếm" aria-controls="globalSearch">
            <?= icon('search') ?>
        </button>
        <?php if (Auth::hasPermission('survey.create')): ?>
        <a href="<?= url('surveys/create') ?>" class="quick-add" aria-label="Tạo khảo sát mới"><?= icon('plus') ?></a>
        <?php endif; ?>
        <?php if (Auth::hasPermission('settings.view')): ?>
        <a href="<?= url('settings') ?>" class="header-link">Cài đặt</a>
        <?php endif; ?>
        <?php if (Auth::hasPermission('audit.view')): ?>
        <a href="<?= url('audit') ?>" class="icon-btn" aria-label="Nhật ký hoạt động"><?= icon('clock') ?></a>
        <?php endif; ?>
        <button class="icon-btn" id="fullscreenToggle" type="button" aria-label="Bật/tắt toàn màn hình"><?= icon('expand') ?></button>

        <div class="user-menu" id="userMenu">
            <button class="user-button" id="userMenuButton" type="button" aria-haspopup="true" aria-expanded="false">
                <span class="user-avatar" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($user['full_name'] ?? 'U', 0, 1))) ?></span>
                <span class="user-name"><?= e($user['full_name'] ?? 'User') ?></span>
                <span class="caret" aria-hidden="true">&#9662;</span>
            </button>
            <ul class="user-dropdown" role="menu">
                <li class="user-dropdown-header">
                    <strong><?= e($user['full_name'] ?? '') ?></strong>
                    <small><?= e($user['email'] ?? '') ?></small>
                </li>
                <li><a href="<?= url('change-password') ?>" role="menuitem">Đổi mật khẩu</a></li>
                <?php if (Auth::hasPermission('audit.view')): ?>
                <li><a href="<?= url('audit') ?>" role="menuitem">Nhật ký hoạt động</a></li>
                <?php endif; ?>
                <li class="divider" role="separator"></li>
                <li><a href="<?= url('logout') ?>" role="menuitem" data-confirm="Bạn có chắc chắn muốn đăng xuất?" data-confirm-title="Đăng xuất" data-confirm-text="Đăng xuất" data-confirm-type="warning">Đăng xuất</a></li>
            </ul>
        </div>
    </div>
</header>
