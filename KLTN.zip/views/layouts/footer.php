<footer class="app-footer" role="contentinfo">
    <div class="footer-content">
        <p>&copy; <?= date('Y') ?> <?= e(getSetting('app.name', APP_NAME)) ?> &middot; Phiên bản <?= e(APP_VERSION) ?></p>
    </div>
</footer>
