<?php
/**
 * Auth Layout
 */
$authName = $appName ?? APP_NAME;
$authPath = (string)parse_url($_SERVER['REQUEST_URI'] ?? '/login', PHP_URL_PATH);
$authBase = (string)parse_url(APP_URL, PHP_URL_PATH);
$authRel  = ($authBase !== '' && $authBase !== '/' && str_starts_with($authPath, $authBase)) ? substr($authPath, strlen($authBase)) : $authPath;
$authDesc = $authName . ' - Đăng nhập vào hệ thống quản lý KPI, khảo sát và đánh giá chất lượng đào tạo.';
?><!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
    <meta name="author" content="<?= e($authName) ?>">
    <title><?= e($pageTitle ?? '') ?> | <?= e($authName) ?></title>
    <meta name="robots" content="<?= e(getSetting('seo.robots', 'noindex,nofollow')) ?>">
    <link rel="canonical" href="<?= e(rtrim(APP_URL, '/') . '/' . ltrim($authRel, '/')) ?>">
    <meta name="color-scheme" content="light">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:image" content="<?= e(asset('images/og-cover.png')) ?>">
    <meta name="twitter:title" content="<?= e($pageTitle ?? '') ?> | <?= e($authName) ?>">
    <meta name="twitter:description" content="<?= e($authDesc) ?>">
    <meta name="description" content="<?= e($authDesc) ?>">
    <meta name="theme-color" content="#6366f1">
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="<?= e($authName) ?>">
    <meta property="og:title" content="<?= e($pageTitle ?? '') ?> | <?= e($authName) ?>">
    <meta property="og:description" content="<?= e($authDesc) ?>">
    <meta property="og:url" content="<?= e(rtrim(APP_URL, '/') . '/' . ltrim($authRel, '/')) ?>">
    <meta property="og:image" content="<?= e(asset('images/og-cover.png')) ?>">
    <meta property="og:locale" content="vi_VN">
    <link rel="icon" type="image/x-icon" href="<?= asset('images/favicon.ico') ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800&amp;display=swap" onload="this.onload=null;this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Be+Vietnam+Pro:wght@400;500;600;700;800&amp;display=swap"></noscript>
    <link rel="dns-prefetch" href="https://fonts.googleapis.com">
    <meta name="application-name" content="<?= e($authName) ?>">
    <meta name="format-detection" content="telephone=no">
    <link rel="alternate" hreflang="vi" href="<?= e(rtrim(APP_URL, '/') . '/' . ltrim($authRel, '/')) ?>">
    <script type="application/ld+json"><?= json_encode([
        '@context' => 'https://schema.org',
        '@type'    => 'WebPage',
        'name'     => ($pageTitle ?? 'Đăng nhập') . ' | ' . $authName,
        'description' => $authDesc,
        'url'      => rtrim(APP_URL, '/') . '/' . ltrim($authRel, '/'),
        'inLanguage'  => 'vi-VN',
        'isPartOf' => ['@type' => 'WebSite', 'name' => $authName, 'url' => rtrim(APP_URL, '/') . '/'],
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG) ?></script>
    <link rel="stylesheet" href="<?= asset('css/auth.css') ?>">
    <link rel="stylesheet" href="<?= asset('css/toast.css') ?>">
</head>
<body class="auth-body">
    <main class="auth-wrapper" id="main-content">
        <div class="auth-container">
            <?= $content ?>
        </div>
    </main>
    <script src="<?= asset('js/toast.js') ?>" defer></script>
    <script src="<?= asset('js/auth.js') ?>" defer></script>
</body>
</html>
