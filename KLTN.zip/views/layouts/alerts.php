<?php
/**
 * Thông báo (toast). Không in HTML tại chỗ: chỉ xuất dữ liệu JSON, toast.js sẽ hiển thị
 * ở góc trên bên phải, tự ẩn sau 2 giây. Nếu có nhiều thông báo thì cái sau thay cái trước.
 *
 * @var string|null $success
 * @var string|null $error
 * @var string|null $warning
 * @var string|null $info
 */
$toastSource = [
    'success' => $success ?? null,
    'info'    => $info ?? null,
    'warning' => $warning ?? null,
    'error'   => $error ?? null, // để cuối: lỗi là thông báo ưu tiên nên ở lại trên màn hình
];
$toasts = [];
foreach ($toastSource as $toastType => $toastMessage) {
    if (!empty($toastMessage)) {
        $toasts[] = ['type' => $toastType, 'message' => (string)$toastMessage];
    }
}
?>
<?php if ($toasts): ?>
<script type="application/json" data-toast><?= json_encode($toasts, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
<?php endif; ?>
