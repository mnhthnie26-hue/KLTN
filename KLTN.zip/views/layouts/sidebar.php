<?php
require_once __DIR__ . '/icons.php';
$user    = $user ?? Auth::user();
$path    = (string)parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);

/**
 * Cấu trúc menu: mục đơn hoặc nhóm (có menu con). Quyền giữ nguyên như bản cũ.
 * match: chuỗi con của URL để xác định đang active; not: loại trừ.
 */
$menu = [
    ['label' => 'Tổng quan', 'icon' => 'dashboard', 'href' => 'dashboard', 'match' => ['/dashboard']],
    ['label' => 'Đánh giá', 'icon' => 'kpi', 'gate' => ['kpi.view'], 'children' => [
        ['label' => 'KPI', 'href' => 'kpis', 'perm' => 'kpi.view', 'match' => ['/kpi']],
        ['label' => 'Tiêu chí', 'href' => 'criteria', 'perm' => 'kpi.view', 'match' => ['/criteria']],
    ]],
    ['label' => 'Khảo sát', 'icon' => 'survey', 'gate' => ['survey.view'], 'children' => [
        ['label' => 'Danh sách khảo sát', 'href' => 'surveys', 'perm' => 'survey.view', 'match' => ['/survey'], 'not' => ['/surveys/create']],
        ['label' => 'Tạo khảo sát', 'href' => 'surveys/create', 'perm' => 'survey.create', 'match' => ['/surveys/create']],
    ]],
    ['label' => 'Phân tích', 'icon' => 'stats', 'gate' => ['analysis.view', 'ranking.view'], 'children' => [
        ['label' => 'Thống kê', 'href' => 'analysis/statistics', 'perm' => 'analysis.statistics', 'match' => ['/analysis/statistics']],
        ['label' => 'AHP', 'href' => 'analysis/ahp', 'perm' => 'analysis.ahp', 'match' => ['/analysis/ahp']],
        ['label' => 'Xếp hạng', 'href' => 'analysis/ranking', 'perm' => 'ranking.view', 'match' => ['/analysis/ranking']],
    ]],
    ['label' => 'Đánh giá chất lượng', 'icon' => 'eval', 'href' => 'evaluations', 'perm' => 'evaluation.view', 'match' => ['/evaluations']],
    ['label' => 'Báo cáo', 'icon' => 'report', 'href' => 'reports', 'perm' => 'report.view', 'match' => ['/reports']],
    ['label' => 'Người dùng', 'icon' => 'users', 'gate' => ['users.view', 'roles.view'], 'children' => [
        ['label' => 'Tài khoản', 'href' => 'users', 'perm' => 'users.view', 'match' => ['/users']],
        ['label' => 'Vai trò & Phân quyền', 'href' => 'roles', 'perm' => 'roles.view', 'match' => ['/roles', '/permissions']],
    ]],
    ['label' => 'Hệ thống', 'icon' => 'settings', 'gate' => ['settings.view', 'audit.view'], 'children' => [
        ['label' => 'Cài đặt', 'href' => 'settings', 'perm' => 'settings.view', 'match' => ['/settings']],
        ['label' => 'Nhật ký', 'href' => 'audit', 'perm' => 'audit.view', 'match' => ['/audit']],
    ]],
];

$isActive = static function (array $it) use ($path): bool {
    foreach ($it['not'] ?? [] as $n) { if (str_contains($path, $n)) return false; }
    foreach ($it['match'] ?? [] as $m) { if (str_contains($path, $m)) return true; }
    return false;
};
$can = static fn(array $it): bool => empty($it['perm']) || Auth::hasPermission($it['perm']);
?>
<aside class="app-sidebar" id="appSidebar" aria-label="Thanh điều hướng">
    <div class="sidebar-user">
        <span class="user-avatar" aria-hidden="true"><?= e(mb_strtoupper(mb_substr($user['full_name'] ?? 'U', 0, 1))) ?></span>
        <div class="sidebar-user-info">
            <strong><?= e($user['full_name'] ?? 'User') ?></strong>
            <small><?= e($user['email'] ?? '') ?></small>
            <?php if (Auth::isAdmin()): ?>
            <span class="admin-badge" title="Quản trị viên - có toàn quyền"><span class="admin-badge-dot" aria-hidden="true"></span>Admin</span>
            <?php endif; ?>
        </div>
        <a href="<?= url('logout') ?>" class="icon-btn sidebar-logout" data-confirm="Bạn có chắc chắn muốn đăng xuất?" data-confirm-title="Đăng xuất" data-confirm-text="Đăng xuất" data-confirm-type="warning" aria-label="Đăng xuất"><?= icon('power') ?></a>
    </div>

    <div class="sidebar-search">
        <label class="sr-only" for="menuSearch">Tìm menu</label>
        <input type="search" id="menuSearch" placeholder="Tìm menu..." autocomplete="off">
        <?= icon('search') ?>
    </div>

    <nav class="sidebar-nav" aria-label="Menu chính">
        <ul class="sidebar-menu">
            <?php foreach ($menu as $item): ?>
                <?php if (isset($item['children'])): ?>
                    <?php
                    if (!empty($item['gate']) && !Auth::hasAnyPermission($item['gate'])) continue;
                    $kids = array_values(array_filter($item['children'], $can));
                    if (!$kids) continue;
                    $groupActive = false;
                    foreach ($kids as $k) { if ($isActive($k)) { $groupActive = true; break; } }
                    $gid = 'sm-' . substr(md5($item['label']), 0, 6);
                    ?>
                    <li class="menu-group <?= $groupActive ? 'open has-active' : '' ?>">
                        <button type="button" class="menu-group-toggle" aria-expanded="<?= $groupActive ? 'true' : 'false' ?>" aria-controls="<?= $gid ?>">
                            <span class="menu-icon"><?= icon($item['icon']) ?></span>
                            <span class="menu-label"><?= e($item['label']) ?></span>
                            <?= icon('chevron', 'menu-chevron') ?>
                        </button>
                        <ul class="submenu" id="<?= $gid ?>">
                            <?php foreach ($kids as $k): ?>
                            <li class="submenu-item <?= $isActive($k) ? 'active' : '' ?>">
                                <a href="<?= url($k['href']) ?>" <?= $isActive($k) ? 'aria-current="page"' : '' ?>><?= e($k['label']) ?></a>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </li>
                <?php else: ?>
                    <?php if (!$can($item)) continue; ?>
                    <li class="menu-item <?= $isActive($item) ? 'active' : '' ?>">
                        <a href="<?= url($item['href']) ?>" <?= $isActive($item) ? 'aria-current="page"' : '' ?>>
                            <span class="menu-icon"><?= icon($item['icon']) ?></span>
                            <span class="menu-label"><?= e($item['label']) ?></span>
                        </a>
                    </li>
                <?php endif; ?>
            <?php endforeach; ?>
        </ul>
    </nav>
</aside>
<div class="sidebar-backdrop" id="sidebarBackdrop" aria-hidden="true"></div>
