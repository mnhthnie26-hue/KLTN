<?php
/** @var array $exports */
?>
<div class="page-header">
    <h1 class="page-title">Báo cáo</h1>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3>Tạo báo cáo</h3></div>
            <div class="card-body">
                <form method="POST" action="<?= url('reports/export') ?>">
                    <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

                    <div class="form-group">
                        <label>Loại báo cáo <span class="required">*</span></label>
                        <select name="report_type" required class="form-control">
                            <option value="survey_results">Kết quả khảo sát</option>
                            <option value="evaluations">Đánh giá chất lượng</option>
                            <option value="rankings">Xếp hạng</option>
                            <option value="users">Người dùng</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Định dạng <span class="required">*</span></label>
                        <select name="format" required class="form-control">
                            <option value="csv">CSV</option>
                            <option value="excel">Excel</option>
                            <option value="pdf">PDF (HTML)</option>
                            <option value="print">In</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Khảo sát (nếu áp dụng)</label>
                        <select name="survey_id" class="form-control">
                            <option value="">Tất cả</option>
                            <?php foreach ($surveys as $s): ?>
                            <option value="<?= $s['id'] ?>"><?= e($s['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>KPI (nếu áp dụng)</label>
                        <select name="kpi_id" class="form-control">
                            <option value="">Tất cả</option>
                            <?php foreach ($kpis as $k): ?>
                            <option value="<?= $k['id'] ?>"><?= e($k['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Kỳ (nếu áp dụng)</label>
                        <input type="text" name="period" placeholder="VD: 2025-H1" class="form-control">
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Xuất báo cáo</button>
                </form>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3>Báo cáo đã xuất</h3></div>
            <div class="card-body">
                <?php if (empty($exports)): ?>
                <p class="text-muted">Chưa có báo cáo nào.</p>
                <?php else: ?>
                <table class="table">
                    <thead><tr><th>Tên</th><th>Loại</th><th>Định dạng</th><th>Ngày tạo</th></tr></thead>
                    <tbody>
                        <?php foreach ($exports as $e): ?>
                        <tr>
                            <td><?= e($e['name']) ?></td>
                            <td><?= e($e['report_type']) ?></td>
                            <td><?= e($e['format']) ?></td>
                            <td><?= e(formatDateTime($e['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>