<?php
/** @var array $survey */
/** @var array $responses */
/** @var array $pagination */
?>
<div class="page-header">
    <h1 class="page-title">Kết quả: <?= e($survey['title']) ?></h1>
    <a href="<?= url('surveys/' . $survey['id']) ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <h3>Tổng quan</h3>
        <p>Tổng phản hồi: <strong><?= (int)$survey['response_count'] ?></strong></p>
    </div>
</div>

<div class="card">
    <div class="card-header"><h3>Danh sách phản hồi</h3></div>
    <div class="card-body">
        <?php if (empty($responses)): ?>
        <div class="empty-state"><p>Chưa có phản hồi nào.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Người trả lời</th>
                        <th>Trạng thái</th>
                        <th>Bắt đầu</th>
                        <th>Nộp</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($responses as $r): ?>
                    <tr>
                        <td>#<?= $r['id'] ?></td>
                        <td>
                            <?= e($r['respondent_name'] ?? 'Ẩn danh') ?>
                            <?php if ($r['respondent_username']): ?><br><small class="text-muted"><?= e($r['respondent_username']) ?></small><?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $sMap = [
                                'in_progress' => '<span class="badge badge-warning">Đang làm</span>',
                                'submitted'   => '<span class="badge badge-success">Đã nộp</span>',
                                'cancelled'   => '<span class="badge">Hủy</span>',
                            ];
                            echo $sMap[$r['status']] ?? e($r['status']);
                            ?>
                        </td>
                        <td><?= e(formatDateTime($r['started_at'])) ?></td>
                        <td><?= e(formatDateTime($r['submitted_at'])) ?></td>
                        <td><?= e($r['ip_address']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= render_pagination($pagination, '?') ?>
        <?php endif; ?>
    </div>
</div>