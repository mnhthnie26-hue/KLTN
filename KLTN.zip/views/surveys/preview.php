<?php
/** @var array $survey */
/** @var bool $preview */
?>
<div class="page-header">
    <h1 class="page-title">Xem trước: <?= e($survey['title']) ?></h1>
    <a href="<?= url('surveys/' . $survey['id']) ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<?= View::renderPartial('layouts/alerts', ['info' => 'Đây là chế độ xem trước. Dữ liệu bạn nhập sẽ không được lưu.']) ?>

<div class="card">
    <div class="card-body">
        <h2><?= e($survey['title']) ?></h2>
        <p class="text-muted"><?= nl2br(e($survey['description'] ?? '')) ?></p>
        <hr>

        <?php if (empty($survey['questions'])): ?>
        <p class="text-muted">Chưa có câu hỏi.</p>
        <?php else: ?>
        <form>
            <?php foreach ($survey['questions'] as $i => $q): ?>
            <div class="question-preview" style="margin-bottom: 20px; padding: 16px; background: #f9fafb; border-radius: 8px;">
                <p><strong><?= ($i + 1) ?>. <?= e($q['question_text']) ?></strong>
                <?php if ((int)$q['is_required']): ?><span style="color:red">*</span><?php endif; ?>
                </p>
                <small class="text-muted">Loại: <?= e($q['question_type']) ?></small>

                <?php if (in_array($q['question_type'], ['single_choice', 'rating', 'scale'])): ?>
                    <?php foreach ($q['options'] as $opt): ?>
                    <label style="display:block; padding: 4px 0;">
                        <input type="radio" name="q_<?= $q['id'] ?>" disabled> <?= e($opt['option_text']) ?> <?= $opt['option_value'] !== null ? '(' . e($opt['option_value']) . ')' : '' ?>
                    </label>
                    <?php endforeach; ?>
                <?php elseif ($q['question_type'] === 'multiple_choice'): ?>
                    <?php foreach ($q['options'] as $opt): ?>
                    <label style="display:block; padding: 4px 0;">
                        <input type="checkbox" disabled> <?= e($opt['option_text']) ?>
                    </label>
                    <?php endforeach; ?>
                <?php elseif ($q['question_type'] === 'number'): ?>
                    <input type="number" disabled placeholder="Nhập số" class="form-control" style="max-width:200px">
                <?php elseif ($q['question_type'] === 'text'): ?>
                    <input type="text" disabled placeholder="Nhập văn bản" class="form-control">
                <?php elseif ($q['question_type'] === 'textarea'): ?>
                    <textarea disabled rows="3" class="form-control" placeholder="Nhập nội dung"></textarea>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

            <button type="button" class="btn btn-primary" disabled>Gửi (preview)</button>
        </form>
        <?php endif; ?>
    </div>
</div>