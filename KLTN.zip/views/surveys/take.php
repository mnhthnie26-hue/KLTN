<?php
/** @var array $survey */
?>
<div class="page-header">
    <h1 class="page-title"><?= e($survey['title']) ?></h1>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <p class="text-muted"><?= nl2br(e($survey['description'] ?? '')) ?></p>

        <form method="POST" action="<?= url('survey/' . $survey['id'] . '/submit') ?>" id="surveyForm">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

            <?php foreach ($survey['questions'] as $i => $q): ?>
            <div class="question-block" style="margin-bottom: 24px; padding: 16px; background: #f9fafb; border-radius: 8px;">
                <p><strong>Câu <?= ($i + 1) ?>: <?= e($q['question_text']) ?></strong>
                <?php if ((int)$q['is_required']): ?><span style="color:red">*</span><?php endif; ?>
                </p>

                <?php if (in_array($q['question_type'], ['single_choice', 'rating', 'scale'])): ?>
                    <?php foreach ($q['options'] as $opt): ?>
                    <label style="display:block; padding: 6px 0;">
                        <input type="radio" name="answers[<?= $q['id'] ?>]" value="<?= $opt['id'] ?>" <?= (int)$q['is_required'] === 1 ? 'required' : '' ?>> <?= e($opt['option_text']) ?>
                    </label>
                    <?php endforeach; ?>

                <?php elseif ($q['question_type'] === 'multiple_choice'): ?>
                    <?php foreach ($q['options'] as $opt): ?>
                    <label style="display:block; padding: 6px 0;">
                        <input type="checkbox" name="answers[<?= $q['id'] ?>][]" value="<?= $opt['id'] ?>"> <?= e($opt['option_text']) ?>
                    </label>
                    <?php endforeach; ?>

                <?php elseif ($q['question_type'] === 'number'): ?>
                    <input type="number" name="answers[<?= $q['id'] ?>]" <?= (int)$q['is_required'] === 1 ? 'required' : '' ?> class="form-control" style="max-width: 200px" min="<?= e($q['min_value']) ?>" max="<?= e($q['max_value']) ?>">

                <?php elseif ($q['question_type'] === 'text'): ?>
                    <input type="text" name="answers[<?= $q['id'] ?>]" <?= (int)$q['is_required'] === 1 ? 'required' : '' ?> class="form-control">

                <?php elseif ($q['question_type'] === 'textarea'): ?>
                    <textarea name="answers[<?= $q['id'] ?>]" rows="4" <?= (int)$q['is_required'] === 1 ? 'required' : '' ?> class="form-control"></textarea>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Gửi khảo sát</button>
                <a href="<?= url('dashboard') ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>