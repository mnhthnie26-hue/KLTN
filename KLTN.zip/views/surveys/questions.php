<?php
/** @var array $survey */
/** @var array $criteria */
?>
<div class="page-header">
    <h1 class="page-title">Câu hỏi: <?= e($survey['title']) ?></h1>
    <a href="<?= url('surveys/' . $survey['id']) ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= url('surveys/' . $survey['id'] . '/questions') ?>" id="questionsForm">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">
            <input type="hidden" name="survey_id" value="<?= $survey['id'] ?>">

            <div id="questionsContainer">
                <?php foreach ($survey['questions'] as $i => $q): ?>
                <div class="question-block" data-index="<?= $i ?>">
                    <div class="card mb-2" style="background: #f9fafb;">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="form-group">
                                        <label>Câu hỏi <span class="required">*</span></label>
                                        <textarea name="questions[<?= $i ?>][question_text]" required class="form-control" rows="2"><?= e($q['question_text']) ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Loại</label>
                                        <select name="questions[<?= $i ?>][question_type]" class="form-control q-type">
                                            <option value="single_choice" <?= $q['question_type'] === 'single_choice' ? 'selected' : '' ?>>Chọn 1</option>
                                            <option value="multiple_choice" <?= $q['question_type'] === 'multiple_choice' ? 'selected' : '' ?>>Chọn nhiều</option>
                                            <option value="rating" <?= $q['question_type'] === 'rating' ? 'selected' : '' ?>>Rating</option>
                                            <option value="scale" <?= $q['question_type'] === 'scale' ? 'selected' : '' ?>>Thang điểm</option>
                                            <option value="number" <?= $q['question_type'] === 'number' ? 'selected' : '' ?>>Số</option>
                                            <option value="text" <?= $q['question_type'] === 'text' ? 'selected' : '' ?>>Văn bản ngắn</option>
                                            <option value="textarea" <?= $q['question_type'] === 'textarea' ? 'selected' : '' ?>>Văn bản dài</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-1 text-right">
                                    <button type="button" class="btn btn-sm btn-danger" data-confirm="Xóa câu hỏi này cùng các lựa chọn của nó?" data-confirm-title="Xóa câu hỏi" data-confirm-remove=".question-block">×</button>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Liên kết tiêu chí</label>
                                        <select name="questions[<?= $i ?>][criterion_id]" class="form-control">
                                            <option value="">-- Không --</option>
                                            <?php foreach ($criteria as $cr): ?>
                                            <option value="<?= $cr['id'] ?>" <?= (int)$q['criterion_id'] === (int)$cr['id'] ? 'selected' : '' ?>><?= e($cr['name']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <label class="checkbox mt-2">
                                        <input type="checkbox" name="questions[<?= $i ?>][is_required]" value="1" <?= (int)$q['is_required'] === 1 ? 'checked' : '' ?>>
                                        <span>Bắt buộc</span>
                                    </label>
                                </div>
                            </div>

                            <div class="options-section" data-type="choice">
                                <label>Lựa chọn</label>
                                <div class="options-list">
                                    <?php foreach ($q['options'] as $j => $opt): ?>
                                    <div class="option-row row mb-1">
                                        <div class="col-md-7">
                                            <input type="text" name="questions[<?= $i ?>][options][<?= $j ?>][text]" value="<?= e($opt['option_text']) ?>" placeholder="Nội dung lựa chọn" class="form-control">
                                        </div>
                                        <div class="col-md-3">
                                            <input type="number" name="questions[<?= $i ?>][options][<?= $j ?>][value]" value="<?= e($opt['option_value']) ?>" step="0.01" placeholder="Giá trị" class="form-control">
                                        </div>
                                        <div class="col-md-2">
                                            <button type="button" class="btn btn-sm btn-danger" data-confirm="Xóa lựa chọn này?" data-confirm-title="Xóa lựa chọn" data-confirm-remove=".option-row">×</button>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <button type="button" class="btn btn-sm btn-secondary add-option">+ Thêm lựa chọn</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <button type="button" class="btn btn-secondary" id="addQuestion">+ Thêm câu hỏi</button>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary">Lưu câu hỏi</button>
                <a href="<?= url('surveys/' . $survey['id']) ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>

<script>
let questionIndex = <?= count($survey['questions']) ?>;
const criteriaOptions = `<?php
$html = '<option value="">-- Không --</option>';
foreach ($criteria as $cr) {
    $html .= '<option value="' . $cr['id'] . '">' . e($cr['name']) . '</option>';
}
echo str_replace(["\r", "\n"], '', addslashes($html));
?>`;

document.getElementById('addQuestion').addEventListener('click', function() {
    const container = document.getElementById('questionsContainer');
    const block = document.createElement('div');
    block.className = 'question-block';
    block.dataset.index = questionIndex;
    block.innerHTML = `
        <div class="card mb-2" style="background: #f9fafb;">
            <div class="card-body">
                <div class="row">
                    <div class="col-md-8">
                        <div class="form-group">
                            <label>Câu hỏi *</label>
                            <textarea name="questions[${questionIndex}][question_text]" required class="form-control" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label>Loại</label>
                            <select name="questions[${questionIndex}][question_type]" class="form-control q-type">
                                <option value="single_choice">Chọn 1</option>
                                <option value="multiple_choice">Chọn nhiều</option>
                                <option value="rating">Rating</option>
                                <option value="scale">Thang điểm</option>
                                <option value="number">Số</option>
                                <option value="text">Văn bản ngắn</option>
                                <option value="textarea">Văn bản dài</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-1 text-right">
                        <button type="button" class="btn btn-sm btn-danger" data-confirm="Xóa câu hỏi này cùng các lựa chọn của nó?" data-confirm-title="Xóa câu hỏi" data-confirm-remove=".question-block">×</button>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>Liên kết tiêu chí</label>
                            <select name="questions[${questionIndex}][criterion_id]" class="form-control">
                                ${criteriaOptions}
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label class="checkbox mt-2">
                            <input type="checkbox" name="questions[${questionIndex}][is_required]" value="1" checked>
                            <span>Bắt buộc</span>
                        </label>
                    </div>
                </div>
                <div class="options-section" data-type="choice">
                    <label>Lựa chọn</label>
                    <div class="options-list"></div>
                    <button type="button" class="btn btn-sm btn-secondary add-option">+ Thêm lựa chọn</button>
                </div>
            </div>
        </div>
    `;
    container.appendChild(block);
    questionIndex++;
});

// Add option
document.addEventListener('click', function(e) {
    if (e.target.classList.contains('add-option')) {
        const list = e.target.previousElementSibling;
        const block = e.target.closest('.question-block');
        const idx = block.dataset.index;
        const optCount = list.querySelectorAll('.option-row').length;
        const row = document.createElement('div');
        row.className = 'option-row row mb-1';
        row.innerHTML = `
            <div class="col-md-7">
                <input type="text" name="questions[${idx}][options][${optCount}][text]" placeholder="Nội dung" class="form-control">
            </div>
            <div class="col-md-3">
                <input type="number" name="questions[${idx}][options][${optCount}][value]" step="0.01" placeholder="Giá trị" class="form-control">
            </div>
            <div class="col-md-2">
                <button type="button" class="btn btn-sm btn-danger" data-confirm="Xóa lựa chọn này?" data-confirm-title="Xóa lựa chọn" data-confirm-remove=".option-row">×</button>
            </div>
        `;
        list.appendChild(row);
    }
});
</script>