<?php
/** @var array $survey */
?>
<div class="page-header">
    <h1 class="page-title"><?= e($survey['title']) ?></h1>
    <a href="<?= url('surveys') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><h3>Thông tin</h3></div>
            <div class="card-body">
                <p><strong>Mã:</strong> <code><?= e($survey['code']) ?></code></p>
                <p><strong>Trạng thái:</strong>
                    <?php
                    $statusMap = [
                        'draft'    => '<span class="badge">Nháp</span>',
                        'published'=> '<span class="badge badge-success">Đang mở</span>',
                        'closed'   => '<span class="badge badge-warning">Đã đóng</span>',
                        'archived' => '<span class="badge badge-secondary">Lưu trữ</span>',
                    ];
                    echo $statusMap[$survey['status']] ?? e($survey['status']);
                    ?>
                </p>
                <p><strong>KPI:</strong> <?= e($survey['kpi_name'] ?? '-') ?></p>
                <p><strong>Người tạo:</strong> <?= e($survey['creator_name'] ?? '-') ?></p>
                <p><strong>Thời gian:</strong><br>
                    <?php if ($survey['start_date']): ?><?= e(formatDateTime($survey['start_date'])) ?><br><?php endif; ?>
                    <?php if ($survey['end_date']): ?>đến <?= e(formatDateTime($survey['end_date'])) ?><?php endif; ?>
                </p>
                <p><strong>Phản hồi:</strong> <span class="badge badge-info"><?= (int)$survey['response_count'] ?></span></p>
                <hr>
                <?php if (Auth::hasPermission('survey.update') && ($survey['status'] === 'draft' || Auth::isAdmin())): ?>
                <a href="<?= url('surveys/' . $survey['id'] . '/edit') ?>" class="btn btn-secondary btn-block mb-1">Sửa thông tin</a>
                <a href="<?= url('surveys/' . $survey['id'] . '/questions') ?>" class="btn btn-primary btn-block mb-1">Quản lý câu hỏi</a>
                <a href="<?= url('surveys/' . $survey['id'] . '/preview') ?>" class="btn btn-secondary btn-block mb-1">Xem trước</a>
                <?php if ($survey['status'] === 'draft'): ?>
                <form method="POST" action="<?= url('surveys/' . $survey['id'] . '/publish') ?>">
                    <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                    <button type="submit" class="btn btn-success btn-block mb-1" data-confirm="Công bố khảo sát này? Sau khi công bố, người dùng có thể bắt đầu trả lời." data-confirm-title="Công bố khảo sát" data-confirm-text="Công bố" data-confirm-type="success">Publish</button>
                </form>
                <?php endif; ?>
                <?php endif; ?>

                <?php if (Auth::hasPermission('survey.update') && $survey['status'] === 'published'): ?>
                <form method="POST" action="<?= url('surveys/' . $survey['id'] . '/close') ?>">
                    <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                    <button type="submit" class="btn btn-warning btn-block mb-1" data-confirm="Đóng khảo sát này? Người dùng sẽ không thể trả lời thêm." data-confirm-title="Đóng khảo sát" data-confirm-text="Đóng khảo sát" data-confirm-type="warning">Đóng khảo sát</button>
                </form>
                <?php endif; ?>

                <?php if (Auth::hasPermission('survey.create')): ?>
                <form method="POST" action="<?= url('surveys/' . $survey['id'] . '/duplicate') ?>">
                    <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                    <button type="submit" class="btn btn-secondary btn-block mb-1">Sao chép</button>
                </form>
                <?php endif; ?>

                <?php if ($survey['status'] === 'published' && Auth::hasPermission('survey.submit')): ?>
                <a href="<?= url('survey/' . $survey['id'] . '/take') ?>" class="btn btn-primary btn-block mb-1">Tham gia</a>
                <?php endif; ?>

                <?php if (Auth::hasPermission('survey.view_result')): ?>
                <a href="<?= url('surveys/' . $survey['id'] . '/results') ?>" class="btn btn-secondary btn-block mb-1">Xem kết quả</a>
                <?php endif; ?>

                <?php if (Auth::hasPermission('survey.delete')): ?>
                <form method="POST" action="<?= url('surveys/' . $survey['id'] . '/delete') ?>" data-confirm="Xóa khảo sát này? Toàn bộ câu hỏi và kết quả liên quan sẽ bị xóa." data-confirm-title="Xóa khảo sát">
                    <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                    <button type="submit" class="btn btn-danger btn-block">Xóa</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header"><h3>Mô tả</h3></div>
            <div class="card-body">
                <p><?= nl2br(e($survey['description'] ?? 'Không có mô tả')) ?></p>
            </div>
        </div>

        <div class="card">
            <div class="card-header"><h3>Câu hỏi (<?= count($survey['questions']) ?>)</h3></div>
            <div class="card-body">
                <?php if (empty($survey['questions'])): ?>
                <p class="text-muted">Chưa có câu hỏi. <a href="<?= url('surveys/' . $survey['id'] . '/questions') ?>">Thêm câu hỏi</a></p>
                <?php else: ?>
                <ol>
                    <?php foreach ($survey['questions'] as $i => $q): ?>
                    <li>
                        <strong><?= e($q['question_text']) ?></strong>
                        <span class="text-muted">[<?= e($q['question_type']) ?><?= (int)$q['is_required'] ? ', bắt buộc' : '' ?>]</span>
                    </li>
                    <?php endforeach; ?>
                </ol>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>