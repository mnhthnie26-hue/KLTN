<?php
/** @var array|null $survey */
/** @var array $kpis */
$isEdit = !empty($survey);
$s = $survey ?? [];
?>
<div class="page-header">
    <h1 class="page-title"><?= $isEdit ? 'Sửa' : 'Tạo' ?> Khảo sát</h1>
    <a href="<?= url('surveys') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? url('surveys/' . $s['id']) : url('surveys') ?>">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

            <div class="row">
                <?php if (!$isEdit): ?>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Mã <span class="required">*</span></label>
                        <input type="text" name="code" value="<?= e($s['code'] ?? '') ?>" required pattern="[A-Za-z0-9_-]+" class="form-control">
                    </div>
                </div>
                <?php endif; ?>
                <div class="col-md-<?= $isEdit ? '12' : '8' ?>">
                    <div class="form-group">
                        <label>Tiêu đề <span class="required">*</span></label>
                        <input type="text" name="title" value="<?= e($s['title'] ?? '') ?>" required class="form-control">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Mô tả</label>
                <textarea name="description" rows="2" class="form-control"><?= e($s['description'] ?? '') ?></textarea>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>KPI áp dụng</label>
                        <select name="kpi_id" class="form-control">
                            <option value="">-- Không --</option>
                            <?php foreach ($kpis as $k): ?>
                            <option value="<?= $k['id'] ?>" <?= (int)($s['kpi_id'] ?? 0) === (int)$k['id'] ? 'selected' : '' ?>><?= e($k['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Đối tượng</label>
                        <select name="target_type" class="form-control">
                            <option value="all" <?= ($s['target_type'] ?? '') === 'all' ? 'selected' : '' ?>>Tất cả</option>
                            <option value="student" <?= ($s['target_type'] ?? '') === 'student' ? 'selected' : '' ?>>Sinh viên</option>
                            <option value="lecturer" <?= ($s['target_type'] ?? '') === 'lecturer' ? 'selected' : '' ?>>Giảng viên</option>
                            <option value="manager" <?= ($s['target_type'] ?? '') === 'manager' ? 'selected' : '' ?>>Quản lý</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Ngày bắt đầu</label>
                        <input type="datetime-local" name="start_date" value="<?= e(!empty($s['start_date']) ? date('Y-m-d\TH:i', strtotime($s['start_date'])) : '') ?>" class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Ngày kết thúc</label>
                        <input type="datetime-local" name="end_date" value="<?= e(!empty($s['end_date']) ? date('Y-m-d\TH:i', strtotime($s['end_date'])) : '') ?>" class="form-control">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <label class="checkbox">
                        <input type="checkbox" name="one_response_per_user" value="1" <?= (!isset($s['one_response_per_user']) || (int)$s['one_response_per_user'] === 1) ? 'checked' : '' ?>>
                        <span>Mỗi người chỉ trả lời 1 lần</span>
                    </label>
                </div>
                <div class="col-md-6">
                    <label class="checkbox">
                        <input type="checkbox" name="allow_anonymous" value="1" <?= !empty($s['allow_anonymous']) ? 'checked' : '' ?>>
                        <span>Cho phép ẩn danh</span>
                    </label>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Cập nhật' : 'Tạo' ?></button>
                <a href="<?= url('surveys') ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>