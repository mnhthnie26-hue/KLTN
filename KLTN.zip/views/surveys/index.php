<?php
/** @var array $surveys */
/** @var array $pagination */
/** @var array $filters */
/** @var array $kpis */
?>
<div class="page-header">
    <h1 class="page-title">Khảo sát</h1>
    <?php if (Auth::hasPermission('survey.create')): ?>
    <a href="<?= url('surveys/create') ?>" class="btn btn-primary">+ Tạo khảo sát</a>
    <?php endif; ?>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('surveys') ?>" class="filter-form">
            <input type="text" name="search" value="<?= e($filters['search']) ?>" placeholder="Tìm kiếm..." class="form-control">
            <select name="status" class="form-control">
                <option value="">Tất cả</option>
                <option value="draft" <?= $filters['status'] === 'draft' ? 'selected' : '' ?>>Nháp</option>
                <option value="published" <?= $filters['status'] === 'published' ? 'selected' : '' ?>>Đang mở</option>
                <option value="closed" <?= $filters['status'] === 'closed' ? 'selected' : '' ?>>Đã đóng</option>
                <option value="archived" <?= $filters['status'] === 'archived' ? 'selected' : '' ?>>Lưu trữ</option>
            </select>
            <select name="kpi_id" class="form-control">
                <option value="">Tất cả KPI</option>
                <?php foreach ($kpis as $k): ?>
                <option value="<?= $k['id'] ?>" <?= (int)$filters['kpi_id'] === (int)$k['id'] ? 'selected' : '' ?>><?= e($k['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </form>

        <?php if (empty($surveys)): ?>
        <div class="empty-state"><p>Chưa có khảo sát nào.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Mã</th>
                        <th>Tiêu đề</th>
                        <th>KPI</th>
                        <th>Trạng thái</th>
                        <th>Câu hỏi</th>
                        <th>Phản hồi</th>
                        <th>Thời gian</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($surveys as $s): ?>
                    <tr>
                        <td><code><?= e($s['code']) ?></code></td>
                        <td><strong><?= e($s['title']) ?></strong></td>
                        <td><?= e($s['kpi_name'] ?? '-') ?></td>
                        <td>
                            <?php
                            $statusMap = [
                                'draft'    => '<span class="badge">Nháp</span>',
                                'published'=> '<span class="badge badge-success">Đang mở</span>',
                                'closed'   => '<span class="badge badge-warning">Đã đóng</span>',
                                'archived' => '<span class="badge badge-secondary">Lưu trữ</span>',
                            ];
                            echo $statusMap[$s['status']] ?? e($s['status']);
                            ?>
                        </td>
                        <td><?= (int)$s['question_count'] ?></td>
                        <td><span class="badge badge-info"><?= (int)$s['response_count'] ?></span></td>
                        <td>
                            <?php if ($s['start_date']): ?><?= e(formatDate($s['start_date'])) ?><br><?php endif; ?>
                            <?php if ($s['end_date']): ?><small>đến <?= e(formatDate($s['end_date'])) ?></small><?php endif; ?>
                        </td>
                        <td class="actions">
                            <a href="<?= url('surveys/' . $s['id']) ?>" class="btn btn-sm btn-secondary">Xem</a>
                            <?php if (($s['status'] === 'draft' || Auth::isAdmin()) && Auth::hasPermission('survey.update')): ?>
                            <a href="<?= url('surveys/' . $s['id'] . '/edit') ?>" class="btn btn-sm btn-secondary">Sửa</a>
                            <?php endif; ?>
                            <?php if (Auth::hasPermission('survey.delete')): ?>
                            <form method="POST" action="<?= url('surveys/' . $s['id'] . '/delete') ?>" style="display:inline" data-confirm="Xóa khảo sát này? Thao tác không thể hoàn tác." data-confirm-title="Xóa khảo sát">
                                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                                <button type="submit" class="btn btn-sm btn-danger">Xóa</button>
                            </form>
                            <?php endif; ?>
                            <?php if ($s['status'] === 'published' && Auth::hasPermission('survey.submit')): ?>
                            <a href="<?= url('survey/' . $s['id'] . '/take') ?>" class="btn btn-sm btn-primary">Tham gia</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= render_pagination($pagination, '?' . http_build_query(array_filter($filters))) ?>
        <?php endif; ?>
    </div>
</div>