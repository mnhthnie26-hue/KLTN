<?php
/**
 * Login view — bố cục chia đôi: giới thiệu hệ thống | biểu mẫu đăng nhập
 */
require_once __DIR__ . '/../layouts/icons.php';
?>
<div class="login-shell">
    <aside class="login-brand" aria-label="Giới thiệu hệ thống">
        <div class="brand-body">
            <p class="brand-headline">Đánh giá chất lượng đào tạo bằng dữ liệu rõ ràng, nhất quán.</p>
            <p class="brand-lead">Quản lý KPI, khảo sát và phân tích kết quả trên một hệ thống thống nhất.</p>

            <ul class="brand-features">
                <li><span class="bf-icon"><?= icon('kpi') ?></span><div><strong>KPI và tiêu chí</strong><span>Thiết lập trọng số, theo dõi mức đạt theo từng nhóm.</span></div></li>
                <li><span class="bf-icon"><?= icon('survey') ?></span><div><strong>Khảo sát trực tuyến</strong><span>Thu thập phản hồi với nhiều loại câu hỏi.</span></div></li>
                <li><span class="bf-icon"><?= icon('ahp') ?></span><div><strong>Phân tích AHP và xếp hạng</strong><span>Kiểm tra tính nhất quán, so sánh kết quả.</span></div></li>
                <li><span class="bf-icon"><?= icon('roles') ?></span><div><strong>Phân quyền chi tiết</strong><span>Mỗi vai trò chỉ thấy đúng chức năng của mình.</span></div></li>
            </ul>
        </div>

        <div class="brand-preview" aria-hidden="true">
            <span class="bp-line bp-line-1"></span>
            <span class="bp-line bp-line-2"></span>
            <div class="bp-bars"><i style="--h:42%"></i><i style="--h:64%"></i><i style="--h:52%"></i><i style="--h:78%"></i><i style="--h:68%"></i><i style="--h:90%"></i></div>
        </div>
    </aside>

    <section class="login-panel">
        <div class="login-card">
            <header class="login-head">
                <span class="login-emblem" aria-hidden="true"><?= icon('lock') ?></span>
                <h1>Đăng nhập</h1>
                <p>Nhập thông tin tài khoản để tiếp tục.</p>
            </header>

            <?= View::renderPartial('layouts/alerts', ['error' => $error ?? null, 'success' => $success ?? null]) ?>

            <form method="POST" action="<?= url('login') ?>" class="login-form" data-auth-form novalidate aria-label="Biểu mẫu đăng nhập">
                <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

                <div class="field">
                    <label for="username">Tên đăng nhập</label>
                    <div class="field-control">
                        <span class="field-icon"><?= icon('user') ?></span>
                        <input type="text" id="username" name="username" value="<?= e($old['username'] ?? '') ?>"
                               required autocomplete="username" autocapitalize="none" spellcheck="false"
                               placeholder="Vui lòng điền tên đăng nhập">
                    </div>
                </div>

                <div class="field">
                    <label for="password">Mật khẩu</label>
                    <div class="field-control">
                        <span class="field-icon"><?= icon('lock') ?></span>
                        <input type="password" id="password" name="password" required
                               autocomplete="current-password" placeholder="Vui lòng điền mật khẩu">
                        <button type="button" class="field-toggle" data-toggle-password="password" aria-label="Hiện mật khẩu" aria-pressed="false">
                            <span class="ft-show"><?= icon('eye') ?></span>
                            <span class="ft-hide"><?= icon('eye-off') ?></span>
                        </button>
                    </div>
                    <p class="field-hint field-warn" data-caps-hint hidden>Caps Lock đang bật.</p>
                </div>

                <label class="login-remember">
                    <input type="checkbox" name="remember" value="1">
                    <span>Ghi nhớ đăng nhập trên thiết bị này</span>
                </label>

                <button type="submit" class="login-submit">
                    <span class="ls-label">Đăng nhập</span>
                    <span class="ls-spinner" aria-hidden="true"></span>
                </button>
            </form>

            <p class="login-secure"><?= icon('lock') ?><span>Hệ thống chỉ dành cho người dùng được cấp quyền.</span></p>

        </div>
    </section>
</div>
