<?php
/**
 * Đổi mật khẩu — hiển thị bên trong layout dashboard (app)
 * Thông báo (toast) do layout app xử lý, view không in alert riêng.
 */
require_once __DIR__ . '/../layouts/icons.php';
$minLen     = max(6, (int)getSetting('security.password_min_length', 6));
$mustChange = !empty($user['must_change_password']);
?>
<div class="page-header">
    <div>
        <h1 class="page-title">Đổi mật khẩu</h1>
    </div>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<?php if ($mustChange): ?>
<div class="pw-notice" role="note">Tài khoản đang dùng mật khẩu mặc định. Hãy đặt mật khẩu mới trước khi tiếp tục sử dụng hệ thống.</div>
<?php endif; ?>

<div class="pw-layout">
    <section class="card" aria-labelledby="pwFormTitle">
        <div class="card-header"><h2 id="pwFormTitle">Mật khẩu mới</h2></div>
        <div class="card-body">
            <form method="POST" action="<?= url('change-password') ?>" class="pw-form" data-auth-form novalidate>
                <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

                <div class="form-group">
                    <label for="current_password">Mật khẩu hiện tại</label>
                    <div class="pw-field">
                        <input type="password" id="current_password" name="current_password" required autocomplete="current-password">
                        <button type="button" class="pw-toggle" data-toggle-password="current_password" aria-label="Hiện mật khẩu" aria-pressed="false">
                            <span class="ft-show"><?= icon('eye') ?></span><span class="ft-hide"><?= icon('eye-off') ?></span>
                        </button>
                    </div>
                </div>

                <div class="form-group">
                    <label for="new_password">Mật khẩu mới</label>
                    <div class="pw-field">
                        <input type="password" id="new_password" name="new_password" required minlength="<?= $minLen ?>"
                               autocomplete="new-password" data-pw-strength aria-describedby="pwHint">
                        <button type="button" class="pw-toggle" data-toggle-password="new_password" aria-label="Hiện mật khẩu" aria-pressed="false">
                            <span class="ft-show"><?= icon('eye') ?></span><span class="ft-hide"><?= icon('eye-off') ?></span>
                        </button>
                    </div>
                    <div class="pw-meter" data-pw-meter data-level="0" aria-hidden="true"><i></i><i></i><i></i><i></i></div>
                    <p class="form-hint" id="pwHint"><span data-pw-label></span> Tối thiểu <?= $minLen ?> ký tự.</p>
                    <p class="field-hint" data-caps-hint hidden>Caps Lock đang bật.</p>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Xác nhận mật khẩu mới</label>
                    <div class="pw-field">
                        <input type="password" id="confirm_password" name="confirm_password" required minlength="<?= $minLen ?>"
                               autocomplete="new-password" data-pw-confirm="new_password">
                        <button type="button" class="pw-toggle" data-toggle-password="confirm_password" aria-label="Hiện mật khẩu" aria-pressed="false">
                            <span class="ft-show"><?= icon('eye') ?></span><span class="ft-hide"><?= icon('eye-off') ?></span>
                        </button>
                    </div>
                    <p class="field-hint" data-pw-match aria-live="polite"></p>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-primary">Cập nhật mật khẩu</button>
                    <a href="<?= url('dashboard') ?>" class="btn btn-secondary">Hủy</a>
                </div>
            </form>
        </div>
    </section>

    <aside class="card" aria-labelledby="pwTipsTitle">
        <div class="card-header"><h2 id="pwTipsTitle">Gợi ý đặt mật khẩu</h2></div>
        <div class="card-body">
            <ul class="pw-tips">
                <li>Dùng từ 12 ký tự trở lên nếu có thể.</li>
                <li>Kết hợp chữ hoa, chữ thường, số và ký tự đặc biệt.</li>
                <li>Không dùng tên đăng nhập, ngày sinh hoặc mật khẩu đã dùng ở nơi khác.</li>
            </ul>
            <p class="pw-after">Sau khi đổi mật khẩu, bạn sẽ được đăng xuất và cần đăng nhập lại bằng mật khẩu mới.</p>
        </div>
    </aside>
</div>

<script src="<?= asset('js/auth.js') ?>" defer></script>
