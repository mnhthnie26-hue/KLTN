<?php
/** @var array $users */
/** @var array $pagination */
/** @var array $filters */
/** @var array $faculties */
?>
<div class="page-header">
    <h1 class="page-title">Quản lý Người dùng</h1>
    <?php if (Auth::hasPermission('users.create')): ?>
    <a href="<?= url('users/create') ?>" class="btn btn-primary">+ Tạo người dùng</a>
    <?php endif; ?>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('users') ?>" class="filter-form">
            <input type="text" name="search" value="<?= e($filters['search']) ?>" placeholder="Tìm kiếm..." class="form-control">
            <select name="user_type" class="form-control">
                <option value="">Tất cả loại</option>
                <option value="admin" <?= $filters['user_type'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                <option value="manager" <?= $filters['user_type'] === 'manager' ? 'selected' : '' ?>>Quản lý</option>
                <option value="lecturer" <?= $filters['user_type'] === 'lecturer' ? 'selected' : '' ?>>Giảng viên</option>
                <option value="student" <?= $filters['user_type'] === 'student' ? 'selected' : '' ?>>Sinh viên</option>
            </select>
            <select name="status" class="form-control">
                <option value="">Tất cả trạng thái</option>
                <option value="1" <?= $filters['status'] === '1' ? 'selected' : '' ?>>Hoạt động</option>
                <option value="0" <?= $filters['status'] === '0' ? 'selected' : '' ?>>Bị khóa</option>
            </select>
        </form>

        <?php if (empty($users)): ?>
        <div class="empty-state">
            <p>Không có người dùng nào.</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Username</th>
                        <th>Họ tên</th>
                        <th>Email</th>
                        <th>Loại</th>
                        <th>Khoa/Phòng ban</th>
                        <th>Trạng thái</th>
                        <th>Đăng nhập cuối</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $i => $u): ?>
                    <tr>
                        <td><?= ($pagination['current_page'] - 1) * $pagination['per_page'] + $i + 1 ?></td>
                        <td><strong><?= e($u['username']) ?></strong></td>
                        <td><?= e($u['full_name']) ?></td>
                        <td><?= e($u['email']) ?></td>
                        <td>
                            <?php
                            $typeMap = [
                                'admin'    => '<span class="badge badge-danger">Admin</span>',
                                'manager'  => '<span class="badge badge-info">Quản lý</span>',
                                'lecturer' => '<span class="badge badge-success">Giảng viên</span>',
                                'student'  => '<span class="badge">Sinh viên</span>',
                            ];
                            echo $typeMap[$u['user_type']] ?? e($u['user_type']);
                            ?>
                        </td>
                        <td>
                            <?= e($u['faculty_name'] ?? '') ?>
                            <?= !empty($u['department_name']) ? '<br><small>' . e($u['department_name']) . '</small>' : '' ?>
                        </td>
                        <td>
                            <?= (int)$u['status'] === 1 ? '<span class="badge badge-success">Hoạt động</span>' : '<span class="badge badge-danger">Bị khóa</span>' ?>
                        </td>
                        <td><?= e(formatDateTime($u['last_login_at'])) ?></td>
                        <td class="actions">
                            <?php if (Auth::hasPermission('users.update')): ?>
                            <a href="<?= url('users/' . $u['id'] . '/edit') ?>" class="btn btn-sm btn-secondary">Sửa</a>
                            <?php endif; ?>
                            <?php if (Auth::hasPermission('users.lock') && (int)$u['id'] !== Auth::id()): ?>
                            <?php if ((int)$u['status'] === 1): ?>
                            <form method="POST" action="<?= url('users/' . $u['id'] . '/lock') ?>" style="display:inline">
                                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                                <button type="submit" class="btn btn-sm btn-warning" data-confirm="Khóa tài khoản này? Người dùng sẽ không thể đăng nhập cho đến khi được mở khóa." data-confirm-title="Khóa tài khoản" data-confirm-text="Khóa" data-confirm-type="warning">Khóa</button>
                            </form>
                            <?php else: ?>
                            <form method="POST" action="<?= url('users/' . $u['id'] . '/unlock') ?>" style="display:inline">
                                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                                <button type="submit" class="btn btn-sm btn-success">Mở khóa</button>
                            </form>
                            <?php endif; ?>
                            <?php endif; ?>
                            <?php if (Auth::hasPermission('users.delete') && (int)$u['id'] !== Auth::id()): ?>
                            <form method="POST" action="<?= url('users/' . $u['id'] . '/delete') ?>" style="display:inline">
                                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                                <button type="submit" class="btn btn-sm btn-danger" data-confirm="Xóa người dùng này? Thao tác không thể hoàn tác." data-confirm-title="Xóa người dùng">Xóa</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= render_pagination($pagination, '?' . http_build_query(array_filter($filters))) ?>
        <?php endif; ?>
    </div>
</div>