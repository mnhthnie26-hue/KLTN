<?php
/** @var array|null $targetUser */
/** @var array $faculties */
/** @var array $departments */
/** @var array $roles */
/** @var array $old */
$isEdit = !empty($targetUser);
$userData = $targetUser ?? $old;
?>
<div class="page-header">
    <h1 class="page-title"><?= $isEdit ? 'Sửa' : 'Tạo' ?> Người dùng</h1>
    <a href="<?= url('users') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? url('users/' . $targetUser['id']) : url('users') ?>">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

            <h3 class="form-section-title">Thông tin cơ bản</h3>
            <div class="row">
                <?php if (!$isEdit): ?>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tên đăng nhập <span class="required">*</span></label>
                        <input type="text" name="username" value="<?= e($userData['username'] ?? '') ?>" required pattern="[a-zA-Z0-9._-]+" class="form-control">
                    </div>
                </div>
                <?php endif; ?>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Email <span class="required">*</span></label>
                        <input type="email" name="email" value="<?= e($userData['email'] ?? '') ?>" required class="form-control">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Họ và tên <span class="required">*</span></label>
                        <input type="text" name="full_name" value="<?= e($userData['full_name'] ?? '') ?>" required class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Số điện thoại</label>
                        <input type="text" name="phone" value="<?= e($userData['phone'] ?? '') ?>" class="form-control">
                    </div>
                </div>
            </div>

            <?php if (!$isEdit): ?>
            <div class="form-group">
                <label>Mật khẩu <span class="required">*</span></label>
                <input type="password" name="password" required minlength="6" class="form-control" autocomplete="new-password">
                <small class="form-hint">Mật khẩu tối thiểu <?= (int)getSetting('security.password_min_length', 6) ?> ký tự. Người dùng sẽ được yêu cầu đổi mật khẩu khi đăng nhập lần đầu.</small>
            </div>
            <?php endif; ?>

            <h3 class="form-section-title">Phân loại</h3>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Loại người dùng <span class="required">*</span></label>
                        <select name="user_type" required class="form-control">
                            <option value="student" <?= ($userData['user_type'] ?? '') === 'student' ? 'selected' : '' ?>>Sinh viên</option>
                            <option value="lecturer" <?= ($userData['user_type'] ?? '') === 'lecturer' ? 'selected' : '' ?>>Giảng viên</option>
                            <option value="manager" <?= ($userData['user_type'] ?? '') === 'manager' ? 'selected' : '' ?>>Quản lý</option>
                            <option value="admin" <?= ($userData['user_type'] ?? '') === 'admin' ? 'selected' : '' ?>>Admin</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Trạng thái</label>
                        <select name="status" class="form-control">
                            <option value="1" <?= !isset($userData['status']) || (int)$userData['status'] === 1 ? 'selected' : '' ?>>Hoạt động</option>
                            <option value="0" <?= isset($userData['status']) && (int)$userData['status'] === 0 ? 'selected' : '' ?>>Bị khóa</option>
                        </select>
                    </div>
                </div>
            </div>

            <h3 class="form-section-title">Đơn vị</h3>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Khoa</label>
                        <select name="faculty_id" class="form-control">
                            <option value="">-- Không --</option>
                            <?php foreach ($faculties as $f): ?>
                            <option value="<?= $f['id'] ?>" <?= (int)($userData['faculty_id'] ?? 0) === (int)$f['id'] ? 'selected' : '' ?>><?= e($f['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Phòng ban</label>
                        <select name="department_id" class="form-control">
                            <option value="">-- Không --</option>
                            <?php foreach ($departments as $d): ?>
                            <option value="<?= $d['id'] ?>" data-faculty="<?= $d['faculty_id'] ?>" <?= (int)($userData['department_id'] ?? 0) === (int)$d['id'] ? 'selected' : '' ?>><?= e($d['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Mã sinh viên</label>
                        <input type="text" name="student_code" value="<?= e($userData['student_code'] ?? '') ?>" class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Mã giảng viên</label>
                        <input type="text" name="lecturer_code" value="<?= e($userData['lecturer_code'] ?? '') ?>" class="form-control">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Lớp</label>
                        <input type="text" name="class_name" value="<?= e($userData['class_name'] ?? '') ?>" class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Chức vụ</label>
                        <input type="text" name="position" value="<?= e($userData['position'] ?? '') ?>" class="form-control">
                    </div>
                </div>
            </div>

            <h3 class="form-section-title">Phân quyền</h3>
            <div class="permissions-grid">
                <?php
                $selectedRoleIds = $targetUser['role_ids'] ?? [];
                foreach ($roles as $role):
                ?>
                <label class="permission-check">
                    <input type="checkbox" name="roles[]" value="<?= $role['id'] ?>" <?= in_array((int)$role['id'], $selectedRoleIds, true) ? 'checked' : '' ?>>
                    <span><strong><?= e($role['display_name']) ?></strong> <small class="text-muted">(<?= e($role['name']) ?>)</small></span>
                </label>
                <?php endforeach; ?>
            </div>

            <?php if ($isEdit): ?>
            <h3 class="form-section-title">Reset mật khẩu</h3>
            <div class="form-group">
                <label>Mật khẩu mới (để trống nếu không đổi)</label>
                <input type="password" name="new_password" minlength="6" class="form-control" autocomplete="new-password">
                <small class="form-hint">Người dùng sẽ phải đổi mật khẩu khi đăng nhập lại.</small>
            </div>
            <?php endif; ?>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Cập nhật' : 'Tạo' ?></button>
                <a href="<?= url('users') ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>