<?php
/** @var array $targetUser */
?>
<div class="page-header">
    <h1 class="page-title">Chi tiết: <?= e($targetUser['full_name']) ?></h1>
    <a href="<?= url('users') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
    <?php if (Auth::hasPermission('users.update')): ?>
    <a href="<?= url('users/' . $targetUser['id'] . '/edit') ?>" class="btn btn-primary">Sửa</a>
    <?php endif; ?>
    <?php if ((int)$targetUser['id'] !== Auth::id()): ?>
        <?php if (Auth::hasPermission('users.lock')): ?>
            <?php if ((int)$targetUser['status'] === 1): ?>
            <form method="POST" action="<?= url('users/' . $targetUser['id'] . '/lock') ?>" style="display:inline">
                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                <button type="submit" class="btn btn-warning" data-confirm="Khóa tài khoản này?" data-confirm-title="Khóa tài khoản" data-confirm-type="warning">Khóa</button>
            </form>
            <?php else: ?>
            <form method="POST" action="<?= url('users/' . $targetUser['id'] . '/unlock') ?>" style="display:inline">
                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                <button type="submit" class="btn btn-success">Mở khóa</button>
            </form>
            <?php endif; ?>
        <?php endif; ?>
        <?php if (Auth::hasPermission('users.delete')): ?>
        <form method="POST" action="<?= url('users/' . $targetUser['id'] . '/delete') ?>" style="display:inline" data-confirm="Xóa người dùng này? Thao tác không thể hoàn tác." data-confirm-title="Xóa người dùng">
            <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
            <button type="submit" class="btn btn-danger">Xóa</button>
        </form>
        <?php endif; ?>
    <?php endif; ?>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3>Thông tin cơ bản</h3></div>
            <div class="card-body">
                <table class="table">
                    <tr><th>Username:</th><td><?= e($targetUser['username']) ?></td></tr>
                    <tr><th>Email:</th><td><?= e($targetUser['email']) ?></td></tr>
                    <tr><th>Họ tên:</th><td><?= e($targetUser['full_name']) ?></td></tr>
                    <tr><th>Điện thoại:</th><td><?= e($targetUser['phone'] ?? '-') ?></td></tr>
                    <tr><th>Loại:</th><td><?= e($targetUser['user_type']) ?></td></tr>
                    <tr><th>Trạng thái:</th><td><?= (int)$targetUser['status'] === 1 ? 'Hoạt động' : 'Bị khóa' ?></td></tr>
                    <tr><th>Ngày tạo:</th><td><?= e(formatDateTime($targetUser['created_at'])) ?></td></tr>
                    <tr><th>Đăng nhập cuối:</th><td><?= e(formatDateTime($targetUser['last_login_at'])) ?></td></tr>
                </table>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3>Vai trò</h3></div>
            <div class="card-body">
                <?php if (empty($targetUser['roles'])): ?>
                <p class="text-muted">Chưa có vai trò nào.</p>
                <?php else: ?>
                <ul>
                    <?php foreach ($targetUser['roles'] as $role): ?>
                    <li><strong><?= e($role['display_name']) ?></strong> <small class="text-muted">(<?= e($role['name']) ?>)</small></li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>