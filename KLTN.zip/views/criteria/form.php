<?php
/** @var array|null $criterion */
/** @var array $kpis */
$isEdit = !empty($criterion);
$c = $criterion ?? [];
?>
<div class="page-header">
    <h1 class="page-title"><?= $isEdit ? 'Sửa' : 'Tạo' ?> Tiêu chí</h1>
    <a href="<?= url('criteria') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? url('criteria/' . $c['id']) : url('criteria') ?>">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>KPI <span class="required">*</span></label>
                        <select name="kpi_id" required class="form-control">
                            <option value="">-- Chọn --</option>
                            <?php foreach ($kpis as $k): ?>
                            <option value="<?= $k['id'] ?>" <?= (int)($c['kpi_id'] ?? $kpiId ?? 0) === (int)$k['id'] ? 'selected' : '' ?>><?= e($k['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <?php if (!$isEdit): ?>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Mã <span class="required">*</span></label>
                        <input type="text" name="code" value="<?= e($c['code'] ?? '') ?>" required pattern="[A-Za-z0-9_-]+" class="form-control">
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label>Tên tiêu chí <span class="required">*</span></label>
                <input type="text" name="name" value="<?= e($c['name'] ?? '') ?>" required class="form-control">
            </div>

            <div class="form-group">
                <label>Mô tả</label>
                <textarea name="description" rows="2" class="form-control"><?= e($c['description'] ?? '') ?></textarea>
            </div>

            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Loại đánh giá</label>
                        <select name="evaluation_type" class="form-control">
                            <option value="score" <?= ($c['evaluation_type'] ?? '') === 'score' ? 'selected' : '' ?>>Điểm</option>
                            <option value="rating" <?= ($c['evaluation_type'] ?? '') === 'rating' ? 'selected' : '' ?>>Rating</option>
                            <option value="yesno" <?= ($c['evaluation_type'] ?? '') === 'yesno' ? 'selected' : '' ?>>Có/Không</option>
                            <option value="text" <?= ($c['evaluation_type'] ?? '') === 'text' ? 'selected' : '' ?>>Văn bản</option>
                            <option value="number" <?= ($c['evaluation_type'] ?? '') === 'number' ? 'selected' : '' ?>>Số</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Trọng số (%) <span class="required">*</span></label>
                        <input type="number" name="weight" value="<?= e($c['weight'] ?? 0) ?>" min="0" max="100" step="0.01" required class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Thứ tự</label>
                        <input type="number" name="sort_order" value="<?= e($c['sort_order'] ?? 0) ?>" class="form-control">
                    </div>
                </div>
            </div>

            <h3 class="form-section-title">Thang điểm</h3>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Điểm tối thiểu</label>
                        <input type="number" name="min_score" value="<?= e($c['min_score'] ?? 1) ?>" step="0.01" required class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Điểm tối đa</label>
                        <input type="number" name="max_score" value="<?= e($c['max_score'] ?? 5) ?>" step="0.01" required class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Bước điểm</label>
                        <input type="number" name="score_step" value="<?= e($c['score_step'] ?? 1) ?>" step="0.01" class="form-control">
                    </div>
                </div>
            </div>

            <?php if ($isEdit): ?>
            <div class="form-group">
                <label>Trạng thái</label>
                <select name="status" class="form-control">
                    <option value="1" <?= (int)$c['status'] === 1 ? 'selected' : '' ?>>Hoạt động</option>
                    <option value="0" <?= (int)$c['status'] === 0 ? 'selected' : '' ?>>Tắt</option>
                </select>
            </div>
            <?php endif; ?>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Cập nhật' : 'Tạo' ?></button>
                <a href="<?= url('criteria') ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>