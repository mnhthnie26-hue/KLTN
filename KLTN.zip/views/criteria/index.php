<?php
/** @var array $grouped */
/** @var array $criteria */
/** @var array $pagination */
/** @var array $filters */
/** @var array $kpis */
?>
<div class="page-header">
    <h1 class="page-title">Quản lý Tiêu chí</h1>
    <?php if (Auth::hasPermission('criteria.create')): ?>
    <a href="<?= url('criteria/create') ?>" class="btn btn-primary">+ Tạo tiêu chí</a>
    <?php endif; ?>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('criteria') ?>" class="filter-form">
            <input type="text" name="search" value="<?= e($filters['search']) ?>" placeholder="Tìm kiếm..." class="form-control">
            <select name="kpi_id" class="form-control">
                <option value="">Tất cả KPI</option>
                <?php foreach ($kpis as $k): ?>
                <option value="<?= $k['id'] ?>" <?= (int)$filters['kpi_id'] === (int)$k['id'] ? 'selected' : '' ?>><?= e($k['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </form>

        <?php if (empty($criteria)): ?>
        <div class="empty-state"><p>Chưa có tiêu chí nào.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Mã</th>
                        <th>Tên</th>
                        <th>KPI</th>
                        <th>Nhóm</th>
                        <th>Trọng số</th>
                        <th>Thang điểm</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($criteria as $c): ?>
                    <tr>
                        <td><code><?= e($c['code']) ?></code></td>
                        <td><?= e($c['name']) ?></td>
                        <td><?= e($c['kpi_name']) ?></td>
                        <td><small><?= e($c['group_name']) ?></small></td>
                        <td><strong><?= e(number_format((float)$c['weight'], 2)) ?>%</strong></td>
                        <td><?= e($c['min_score']) ?> - <?= e($c['max_score']) ?></td>
                        <td class="actions">
                            <?php if (Auth::hasPermission('criteria.update')): ?>
                            <a href="<?= url('criteria/' . $c['id'] . '/edit') ?>" class="btn btn-sm btn-secondary">Sửa</a>
                            <?php endif; ?>
                            <?php if (Auth::hasPermission('criteria.delete')): ?>
                            <form method="POST" action="<?= url('criteria/' . $c['id'] . '/delete') ?>" style="display:inline">
                                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                                <button type="submit" class="btn btn-sm btn-danger" data-confirm="Xóa tiêu chí này? Thao tác không thể hoàn tác." data-confirm-title="Xóa tiêu chí">Xóa</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= render_pagination($pagination, '?' . http_build_query(array_filter($filters))) ?>
        <?php endif; ?>
    </div>
</div>