<?php
/** @var array $grouped */
?>
<div class="page-header">
    <h1 class="page-title">Cài đặt Hệ thống</h1>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<form method="POST" action="<?= url('settings') ?>">
    <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

    <?php foreach ($grouped as $group => $settings): ?>
    <div class="card">
        <div class="card-header"><h3><?= e(ucfirst($group)) ?></h3></div>
        <div class="card-body">
            <?php foreach ($settings as $s): ?>
            <div class="form-group">
                <label>
                    <code><?= e($s['setting_key']) ?></code>
                    <?php if ($s['description']): ?>
                    <small class="text-muted"> - <?= e($s['description']) ?></small>
                    <?php endif; ?>
                </label>
                <?php
                $val = $s['setting_value'];
                $isJson = json_decode($val) !== null && !is_numeric($val) && $val !== '';
                $isLong = mb_strlen($val) > 100;
                if ($isJson || $isLong): ?>
                    <textarea name="settings[<?= e($s['setting_key']) ?>]" class="form-control" rows="2"><?= e($val) ?></textarea>
                <?php else: ?>
                    <input type="text" name="settings[<?= e($s['setting_key']) ?>]" value="<?= e($val) ?>" class="form-control">
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php endforeach; ?>

    <div class="form-actions">
        <button type="submit" class="btn btn-primary">Lưu cài đặt</button>
    </div>
</form>