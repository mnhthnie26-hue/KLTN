<?php
/** @var array $stats */
require_once VIEWS_PATH . '/layouts/icons.php';
$st = $stats;
?>
<?php
$days = ['Chủ nhật', 'Thứ hai', 'Thứ ba', 'Thứ tư', 'Thứ năm', 'Thứ sáu', 'Thứ bảy'];
$todayLabel = $days[(int)date('w')] . ', ' . date('d/m/Y');
?>
<header class="welcome-banner">
    <div>
        <h1 id="dashboard-title">Tổng quan</h1>
    </div>
    <time class="welcome-date" datetime="<?= date('Y-m-d') ?>"><?= e($todayLabel) ?></time>
</header>

<section class="stat-grid" aria-label="Số liệu tổng quan">
    <div class="stat-card stat-card-primary">
        <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M9 8a3 3 0 1 0 0 .01M2.5 20a6.5 6.5 0 0 1 13 0M16 5.5a3 3 0 0 1 0 6M18 14.5a6.5 6.5 0 0 1 3.5 5.5"/></svg></div>
        <div class="stat-label">Tổng người dùng</div>
        <div class="stat-value"><?= number_format($st['total_users']) ?></div>
        <div class="stat-trend">SV: <?= $st['total_students'] ?> | GV: <?= $st['total_lecturers'] ?> | QL: <?= $st['total_managers'] ?></div>
    </div>
    <div class="stat-card stat-card-info">
        <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/></svg></div>
        <div class="stat-label">Tổng KPI</div>
        <div class="stat-value"><?= number_format($st['total_kpis']) ?></div>
        <div class="stat-trend"><?= number_format($st['total_criteria']) ?> tiêu chí</div>
    </div>
    <div class="stat-card stat-card-success">
        <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h4"/></svg></div>
        <div class="stat-label">Khảo sát</div>
        <div class="stat-value"><?= number_format($st['total_surveys']) ?></div>
        <div class="stat-trend"><?= $st['active_surveys'] ?> đang mở</div>
    </div>
    <div class="stat-card stat-card-warning">
        <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M21 12a8 8 0 0 1-11.6 7.1L4 20l1-4.6A8 8 0 1 1 21 12z"/></svg></div>
        <div class="stat-label">Phản hồi</div>
        <div class="stat-value"><?= number_format($st['total_responses']) ?></div>
        <div class="stat-trend">Tổng lượt</div>
    </div>
    <div class="stat-card stat-card-danger">
        <div class="stat-icon" aria-hidden="true"><svg viewBox="0 0 24 24" focusable="false"><path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/></svg></div>
        <div class="stat-label">Điểm chất lượng TB</div>
        <div class="stat-value"><?= number_format($st['avg_quality'], 1) ?></div>
        <div class="stat-trend">Thang 0-100</div>
    </div>
    <div class="stat-card stat-card-info">
        <div class="stat-icon" aria-hidden="true"><?= icon('layers') ?></div>
        <div class="stat-label">Nhóm KPI</div>
        <div class="stat-value"><?= number_format($st['total_groups']) ?></div>
        <div class="stat-trend">Đang quản lý</div>
    </div>
    <div class="stat-card stat-card-warning">
        <div class="stat-icon" aria-hidden="true"><?= icon('eval') ?></div>
        <div class="stat-label">Lượt đánh giá</div>
        <div class="stat-value"><?= number_format($st['total_evals']) ?></div>
        <div class="stat-trend">Đã tạo trong hệ thống</div>
    </div>
    <div class="stat-card stat-card-primary">
        <div class="stat-icon" aria-hidden="true"><?= icon('clock') ?></div>
        <div class="stat-label">Khảo sát nháp</div>
        <div class="stat-value"><?= number_format($st['draft_surveys']) ?></div>
        <div class="stat-trend">Chưa công bố</div>
    </div>
    <div class="stat-card stat-card-success">
        <div class="stat-icon" aria-hidden="true"><?= icon('check-circle') ?></div>
        <div class="stat-label">Khảo sát đã đóng</div>
        <div class="stat-value"><?= number_format($st['closed_surveys']) ?></div>
        <div class="stat-trend">Đóng hoặc lưu trữ</div>
    </div>
    <div class="stat-card stat-card-danger">
        <div class="stat-icon" aria-hidden="true"><?= icon('lock') ?></div>
        <div class="stat-label">Tài khoản bị khóa</div>
        <div class="stat-value"><?= number_format($st['locked_users']) ?></div>
        <div class="stat-trend">Trên tổng <?= number_format($st['total_users']) ?> người dùng</div>
    </div>
</section>

<?php
$shortcuts = [
    ['Tạo khảo sát', 'surveys/create', 'plus-circle', 'survey.create'],
    ['Khảo sát',     'surveys',        'survey',      'survey.view'],
    ['KPI',          'kpis',           'kpi',         'kpi.view'],
    ['Tiêu chí',     'criteria',       'criteria',    'kpi.view'],
    ['Thống kê',     'analysis/statistics', 'stats',  'analysis.statistics'],
    ['AHP',          'analysis/ahp',   'ahp',         'analysis.ahp'],
    ['Xếp hạng',     'analysis/ranking', 'rank',      'ranking.view'],
    ['Đánh giá',     'evaluations',    'eval',        'evaluation.view'],
    ['Báo cáo',      'reports',        'report',      'report.view'],
    ['Người dùng',   'users',          'users',       'users.view'],
    ['Vai trò',      'roles',          'roles',       'roles.view'],
    ['Cài đặt',      'settings',       'settings',    'settings.view'],
];
$shortcuts = array_filter($shortcuts, static fn($x) => Auth::hasPermission($x[3]));
?>
<?php if ($shortcuts): ?>
<section class="card" aria-label="Truy cập nhanh">
    <div class="card-header"><h3 class="card-title-icon" style="--ti:var(--c-violet)"><?= icon('dashboard') ?>Truy cập nhanh</h3></div>
    <div class="card-body">
        <div class="shortcut-grid">
            <?php foreach ($shortcuts as [$label, $href, $ic]): ?>
            <a class="shortcut" href="<?= url($href) ?>"><?= icon($ic) ?><span><?= e($label) ?></span></a>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<div class="chart-grid">
    <div class="card">
        <div class="card-header"><h3 class="card-title-icon" style="--ti:var(--c-violet)"><?= icon('kpi') ?>Điểm trung bình theo KPI</h3></div>
        <div class="card-body">
            <div class="chart-container">
                <canvas id="chartKpiScores" role="img" aria-label="Biểu đồ điểm trung bình theo KPI"></canvas>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header"><h3 class="card-title-icon" style="--ti:var(--c-orange)"><?= icon('donut') ?>Phân bố xếp loại</h3></div>
        <div class="card-body">
            <div class="chart-container">
                <canvas id="chartDistribution" role="img" aria-label="Biểu đồ phân bố xếp loại"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="chart-grid">
    <div class="card">
        <div class="card-header"><h3 class="card-title-icon" style="--ti:var(--c-green)"><?= icon('trend') ?>Xu hướng điểm theo thời gian</h3></div>
        <div class="card-body">
            <div class="chart-container">
                <canvas id="chartTrend" role="img" aria-label="Biểu đồ xu hướng điểm theo thời gian"></canvas>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header"><h3 class="card-title-icon" style="--ti:var(--c-pink)"><?= icon('check-circle') ?>Tỷ lệ hoàn thành khảo sát</h3></div>
        <div class="card-body">
            <div class="chart-container">
                <canvas id="chartCompletion" role="img" aria-label="Biểu đồ tỷ lệ hoàn thành khảo sát"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="row row-equal">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3 class="card-title-icon" style="--ti:#3aa7d6"><?= icon('survey') ?>Khảo sát gần đây</h3><?php if (Auth::hasPermission('survey.view')): ?><a class="card-link" href="<?= url('surveys') ?>">Xem tất cả</a><?php endif; ?></div>
            <div class="card-body">
                <?php if (empty($recentSurveys)): ?>
                <p class="text-muted">Chưa có khảo sát nào.</p>
                <?php else: ?>
                <div class="table-responsive"><table class="table">
                    <thead>
                        <tr><th>Tiêu đề</th><th>Trạng thái</th><th>Phản hồi</th><th>Ngày tạo</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentSurveys as $s): ?>
                        <tr>
                            <td><a href="<?= url('surveys/' . $s['id']) ?>"><?= e($s['title']) ?></a></td>
                            <td>
                                <?php
                                $sm = [
                                    'draft'    => '<span class="badge">Nháp</span>',
                                    'published'=> '<span class="badge badge-success">Đang mở</span>',
                                    'closed'   => '<span class="badge badge-warning">Đã đóng</span>',
                                    'archived' => '<span class="badge badge-secondary">Lưu trữ</span>',
                                ];
                                echo $sm[$s['status']] ?? e($s['status']);
                                ?>
                            </td>
                            <td><span class="badge badge-info"><?= (int)$s['response_count'] ?></span></td>
                            <td><?= e(formatDateTime($s['created_at'])) ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3 class="card-title-icon" style="--ti:var(--c-orange)"><?= icon('eval') ?>Đánh giá gần đây</h3><?php if (Auth::hasPermission('evaluation.view')): ?><a class="card-link" href="<?= url('evaluations') ?>">Xem tất cả</a><?php endif; ?></div>
            <div class="card-body">
                <?php if (empty($recentEvaluations)): ?>
                <p class="text-muted">Chưa có đánh giá nào.</p>
                <?php else: ?>
                <div class="table-responsive"><table class="table">
                    <thead>
                        <tr><th>Tên</th><th>KPI</th><th>Kỳ</th><th>Điểm</th><th>Xếp loại</th></tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recentEvaluations as $e): ?>
                        <tr>
                            <td><a href="<?= url('evaluations/' . $e['id']) ?>"><?= e($e['name']) ?></a></td>
                            <td><?= e($e['kpi_name'] ?? '-') ?></td>
                            <td><?= e($e['period'] ?? '-') ?></td>
                            <td><strong><?= $e['normalized_score'] !== null ? number_format((float)$e['normalized_score'], 2) : '-' ?></strong></td>
                            <td><?= e($e['classification'] ?? '-') ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row row-equal">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3 class="card-title-icon" style="--ti:var(--c-green)"><?= icon('rank') ?>KPI điểm cao nhất</h3><?php if (Auth::hasPermission('ranking.view')): ?><a class="card-link" href="<?= url('analysis/ranking') ?>">Xếp hạng</a><?php endif; ?></div>
            <div class="card-body">
                <?php if (empty($topKpis)): ?>
                <p class="text-muted">Chưa có điểm đánh giá nào.</p>
                <?php else: ?>
                <ol class="rank-list">
                    <?php foreach ($topKpis as $i => $k): $sc = max(0, min(100, (float)$k['avg_score'])); ?>
                    <li>
                        <span class="rank-no"><?= $i + 1 ?></span>
                        <div class="rank-body">
                            <div class="rank-name"><span><?= e($k['name']) ?></span><strong><?= number_format($sc, 1) ?></strong></div>
                            <div class="meter"><i style="width: <?= $sc ?>%"></i></div>
                        </div>
                    </li>
                    <?php endforeach; ?>
                </ol>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3 class="card-title-icon" style="--ti:var(--c-pink)"><?= icon('check-circle') ?>Khảo sát đang mở</h3><?php if (Auth::hasPermission('survey.view')): ?><a class="card-link" href="<?= url('surveys') ?>">Xem tất cả</a><?php endif; ?></div>
            <div class="card-body">
                <?php if (empty($activeSurveys)): ?>
                <p class="text-muted">Hiện không có khảo sát nào đang mở.</p>
                <?php else: ?>
                <ul class="progress-list">
                    <?php foreach ($activeSurveys as $a):
                        $tot = (int)$a['total']; $done = (int)$a['completed'];
                        $pct = $tot > 0 ? round($done / $tot * 100) : 0; ?>
                    <li>
                        <div class="rank-name">
                            <a href="<?= url('surveys/' . $a['id']) ?>"><?= e($a['title']) ?></a>
                            <strong><?= $done ?>/<?= $tot ?></strong>
                        </div>
                        <div class="meter meter-green"><i style="width: <?= $pct ?>%"></i></div>
                        <small class="text-muted"><?= $pct ?>% hoàn thành<?= !empty($a['end_date']) ? ' · hạn ' . e(formatDateTime($a['end_date'])) : '' ?></small>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if (Auth::hasPermission('audit.view')): ?>
<div class="card">
    <div class="card-header"><h3 class="card-title-icon" style="--ti:#3aa7d6"><?= icon('audit') ?>Hoạt động gần đây</h3><a class="card-link" href="<?= url('audit') ?>">Xem tất cả</a></div>
    <div class="card-body">
        <?php if (empty($recentActivity)): ?>
        <p class="text-muted">Chưa có hoạt động nào.</p>
        <?php else: ?>
        <div class="table-responsive"><table class="table">
            <thead><tr><th>Thời gian</th><th>Người dùng</th><th>Hành động</th><th>Module</th><th>Mô tả</th></tr></thead>
            <tbody>
                <?php foreach ($recentActivity as $log): ?>
                <tr>
                    <td><?= e(formatDateTime($log['created_at'])) ?></td>
                    <td><?= e($log['user_name'] ?? 'Hệ thống') ?></td>
                    <td><span class="badge"><?= e($log['action']) ?></span></td>
                    <td><?= e($log['module']) ?></td>
                    <td><?= e($log['description'] ?? '') ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table></div>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<script>
window.dashboardData = {
    chartDataUrl: <?= json_encode(url('analysis/dashboard-data')) ?>,
    kpiScores: <?= json_encode($kpiScores) ?>,
    recentEvaluations: <?= json_encode($recentEvaluations) ?>,
    completionRate: <?= json_encode($completionRate) ?>
};
</script>
<script src="<?= asset('js/dashboard.js') ?>" defer></script>