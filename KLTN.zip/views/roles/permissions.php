<?php
/** @var array $roles */
/** @var array $permissions */
?>
<div class="page-header">
    <h1 class="page-title">Phân quyền</h1>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <h2 class="section-title">Ma trận Vai trò - Module</h2>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Module</th>
                        <?php foreach ($roles as $role): ?>
                        <th><?= e($role['display_name']) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($permissions as $module => $perms): ?>
                    <tr>
                        <td><strong><?= e(ucfirst($module)) ?></strong></td>
                        <?php
                        $roleHasModule = [];
                        foreach ($roles as $role) {
                            $modulePerms = array_filter($perms, fn($p) => true);
                            $roleHasModule[$role['id']] = false;
                            // Note: In production, query actual role permissions
                        }
                        ?>
                        <?php foreach ($roles as $role): ?>
                        <td>
                            <?php
                            $rolePerms = Database::getInstance()->fetchAll(
                                'SELECT p.module FROM permissions p
                                 INNER JOIN role_permissions rp ON p.id = rp.permission_id
                                 WHERE rp.role_id = ? AND p.module = ?',
                                [$role['id'], $module]
                            );
                            ?>
                            <?php if (!empty($rolePerms)): ?>
                            <span class="badge badge-success"><?= count($rolePerms) ?> quyền</span>
                            <?php else: ?>
                            <span class="badge">-</span>
                            <?php endif; ?>
                        </td>
                        <?php endforeach; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>