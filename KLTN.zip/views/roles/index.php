<?php
/** @var array $roles */
/** @var array $pagination */
/** @var string $search */
?>
<div class="page-header">
    <h1 class="page-title">Quản lý Vai trò</h1>
    <?php if (Auth::hasPermission('roles.create')): ?>
    <a href="<?= url('roles/create') ?>" class="btn btn-primary">+ Tạo vai trò</a>
    <?php endif; ?>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('roles') ?>" class="filter-form">
            <input type="text" name="search" value="<?= e($search) ?>" placeholder="Tìm kiếm vai trò..." class="form-control">
        </form>

        <?php if (empty($roles)): ?>
        <div class="empty-state">
            <p>Chưa có vai trò nào.</p>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Tên (name)</th>
                        <th>Tên hiển thị</th>
                        <th>Mô tả</th>
                        <th>Hệ thống</th>
                        <th>Số user</th>
                        <th>Trạng thái</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($roles as $i => $role): ?>
                    <tr>
                        <td><?= ($pagination['current_page'] - 1) * $pagination['per_page'] + $i + 1 ?></td>
                        <td><code><?= e($role['name']) ?></code></td>
                        <td><strong><?= e($role['display_name']) ?></strong></td>
                        <td><?= e($role['description'] ?? '') ?></td>
                        <td><?= (int)$role['is_system'] === 1 ? '<span class="badge badge-info">System</span>' : '<span class="badge">Custom</span>' ?></td>
                        <td><?= (int)($role['user_count'] ?? 0) ?></td>
                        <td><?= (int)$role['status'] === 1 ? '<span class="badge badge-success">Hoạt động</span>' : '<span class="badge badge-secondary">Tắt</span>' ?></td>
                        <td class="actions">
                            <?php if (Auth::hasPermission('roles.update')): ?>
                            <a href="<?= url('roles/' . $role['id'] . '/edit') ?>" class="btn btn-sm btn-secondary">Sửa</a>
                            <?php endif; ?>
                            <?php if (Auth::hasPermission('roles.delete') && (int)$role['is_system'] === 0): ?>
                            <form method="POST" action="<?= url('roles/' . $role['id'] . '/delete') ?>" style="display:inline" data-confirm="Bạn có chắc chắn muốn xóa vai trò này? Thao tác không thể hoàn tác." data-confirm-title="Xóa vai trò">
                                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                                <button type="submit" class="btn btn-sm btn-danger">Xóa</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= render_pagination($pagination, '?' . http_build_query(array_filter(['search' => $search]))) ?>
        <?php endif; ?>
    </div>
</div>