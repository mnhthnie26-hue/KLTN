<?php
/** @var array|null $role */
/** @var array $permissions */
/** @var array $rolePermIds */
$isEdit = !empty($role);
?>
<div class="page-header">
    <h1 class="page-title"><?= $isEdit ? 'Sửa' : 'Tạo' ?> Vai trò</h1>
    <a href="<?= url('roles') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? url('roles/' . $role['id']) : url('roles') ?>">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tên (slug) <span class="required">*</span></label>
                        <input type="text" name="name" value="<?= e($role['name'] ?? '') ?>" required pattern="[a-zA-Z0-9_-]+" <?= $isEdit ? 'readonly' : '' ?> class="form-control">
                        <small class="form-hint">Chỉ chứa chữ, số, gạch dưới, gạch ngang. Không thể thay đổi sau khi tạo.</small>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tên hiển thị <span class="required">*</span></label>
                        <input type="text" name="display_name" value="<?= e($role['display_name'] ?? '') ?>" required class="form-control">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Mô tả</label>
                <textarea name="description" class="form-control" rows="2"><?= e($role['description'] ?? '') ?></textarea>
            </div>

            <div class="form-group">
                <label>Thứ tự hiển thị</label>
                <input type="number" name="sort_order" value="<?= e($role['sort_order'] ?? 0) ?>" class="form-control" style="max-width:200px">
            </div>

            <h3 class="form-section-title">Phân quyền</h3>

            <div class="permissions-grid">
                <?php foreach ($permissions as $module => $perms): ?>
                <div class="permission-module">
                    <h4 class="module-title"><?= e(ucfirst($module)) ?></h4>
                    <?php foreach ($perms as $perm): ?>
                    <label class="permission-check">
                        <input
                            type="checkbox"
                            name="permissions[]"
                            value="<?= $perm['id'] ?>"
                            <?= in_array((int)$perm['id'], $rolePermIds ?? [], true) ? 'checked' : '' ?>
                        >
                        <span><?= e($perm['display_name']) ?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Cập nhật' : 'Tạo' ?></button>
                <a href="<?= url('roles') ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>