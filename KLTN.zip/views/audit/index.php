<?php
/** @var array $logs */
/** @var array $filters */
/** @var array $actions */
/** @var array $modules */
?>
<div class="page-header">
    <h1 class="page-title">Nhật ký Hoạt động</h1>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('audit') ?>" class="filter-form">
            <select name="action" class="form-control">
                <option value="">Tất cả hành động</option>
                <?php foreach ($actions as $a): ?>
                <option value="<?= e($a['action']) ?>" <?= $filters['action'] === $a['action'] ? 'selected' : '' ?>><?= e($a['action']) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="module" class="form-control">
                <option value="">Tất cả module</option>
                <?php foreach ($modules as $m): ?>
                <option value="<?= e($m['module']) ?>" <?= $filters['module'] === $m['module'] ? 'selected' : '' ?>><?= e($m['module']) ?></option>
                <?php endforeach; ?>
            </select>
        </form>

        <?php if (empty($logs)): ?>
        <div class="empty-state"><p>Chưa có log nào.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Thời gian</th>
                        <th>User</th>
                        <th>Hành động</th>
                        <th>Module</th>
                        <th>Mô tả</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                    <tr>
                        <td><?= e(formatDateTime($log['created_at'])) ?></td>
                        <td><?= e($log['user_name'] ?? 'Hệ thống') ?></td>
                        <td><span class="badge"><?= e($log['action']) ?></span></td>
                        <td><?= e($log['module']) ?></td>
                        <td><?= e($log['description'] ?? '') ?></td>
                        <td><?= e($log['ip_address']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= render_pagination($pagination, '?' . http_build_query(array_filter($filters))) ?>
        <?php endif; ?>
    </div>
</div>