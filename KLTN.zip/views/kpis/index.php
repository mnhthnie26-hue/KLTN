<?php
/** @var array $kpis */
/** @var array $pagination */
/** @var array $filters */
/** @var array $groups */
?>
<div class="page-header">
    <h1 class="page-title">Quản lý KPI</h1>
    <div>
        <a href="<?= url('kpi-groups') ?>" class="btn btn-secondary">Nhóm KPI</a>
        <?php if (Auth::hasPermission('kpi.create')): ?>
        <a href="<?= url('kpis/create') ?>" class="btn btn-primary">+ Tạo KPI</a>
        <?php endif; ?>
    </div>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('kpis') ?>" class="filter-form">
            <input type="text" name="search" value="<?= e($filters['search']) ?>" placeholder="Tìm kiếm..." class="form-control">
            <select name="kpi_group_id" class="form-control">
                <option value="">Tất cả nhóm</option>
                <?php foreach ($groups as $g): ?>
                <option value="<?= $g['id'] ?>" <?= (int)$filters['kpi_group_id'] === (int)$g['id'] ? 'selected' : '' ?>><?= e($g['name']) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="status" class="form-control">
                <option value="">Tất cả</option>
                <option value="1" <?= $filters['status'] === '1' ? 'selected' : '' ?>>Hoạt động</option>
                <option value="0" <?= $filters['status'] === '0' ? 'selected' : '' ?>>Tắt</option>
            </select>
        </form>

        <?php if (empty($kpis)): ?>
        <div class="empty-state"><p>Chưa có KPI nào.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Mã</th>
                        <th>Tên</th>
                        <th>Nhóm</th>
                        <th>Thang điểm</th>
                        <th>Tiêu chí</th>
                        <th>Trạng thái</th>
                        <th>Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($kpis as $k): ?>
                    <tr>
                        <td><code><?= e($k['code']) ?></code></td>
                        <td><strong><?= e($k['name']) ?></strong></td>
                        <td><?= e($k['group_name']) ?></td>
                        <td><?= e($k['min_score']) ?> - <?= e($k['max_score']) ?> (bước <?= e($k['score_step']) ?>)</td>
                        <td><span class="badge badge-info"><?= (int)$k['criteria_count'] ?> tiêu chí</span></td>
                        <td><?= (int)$k['status'] === 1 ? '<span class="badge badge-success">Hoạt động</span>' : '<span class="badge">Tắt</span>' ?></td>
                        <td class="actions">
                            <a href="<?= url('kpis/' . $k['id']) ?>" class="btn btn-sm btn-secondary">Xem</a>
                            <?php if (Auth::hasPermission('criteria.create')): ?>
                            <a href="<?= url('criteria/create?kpi_id=' . $k['id']) ?>" class="btn btn-sm btn-secondary">+ Tiêu chí</a>
                            <?php endif; ?>
                            <?php if (Auth::hasPermission('kpi.update')): ?>
                            <a href="<?= url('kpis/' . $k['id'] . '/edit') ?>" class="btn btn-sm btn-secondary">Sửa</a>
                            <?php endif; ?>
                            <?php if (Auth::hasPermission('kpi.delete')): ?>
                            <form method="POST" action="<?= url('kpis/' . $k['id'] . '/delete') ?>" style="display:inline">
                                <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                                <button type="submit" class="btn btn-sm btn-danger" data-confirm="Xóa KPI này? Thao tác không thể hoàn tác." data-confirm-title="Xóa KPI">Xóa</button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?= render_pagination($pagination, '?' . http_build_query(array_filter($filters))) ?>
        <?php endif; ?>
    </div>
</div>