<?php
/** @var array $groups */
?>
<div class="page-header">
    <h1 class="page-title">Nhóm KPI</h1>
    <a href="<?= url('kpis') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
    <?php if (Auth::hasPermission('kpi_group.create')): ?>
    <a href="<?= url('kpi-groups/create') ?>" class="btn btn-primary">+ Tạo nhóm</a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-body">
        <?php if (empty($groups)): ?>
        <div class="empty-state"><p>Chưa có nhóm KPI.</p></div>
        <?php else: ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Mã</th>
                    <th>Tên</th>
                    <th>Mô tả</th>
                    <th>Số KPI</th>
                    <th>Trạng thái</th>
                    <th>Thao tác</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($groups as $g): ?>
                <tr>
                    <td><code><?= e($g['code']) ?></code></td>
                    <td><strong><?= e($g['name']) ?></strong></td>
                    <td><?= e($g['description'] ?? '') ?></td>
                    <td><span class="badge badge-info"><?= (int)$g['kpi_count'] ?> KPI</span></td>
                    <td><?= (int)$g['status'] === 1 ? '<span class="badge badge-success">Hoạt động</span>' : '<span class="badge">Tắt</span>' ?></td>
                    <td class="actions">
                        <?php if (Auth::hasPermission('kpi_group.update')): ?>
                        <a href="<?= url('kpi-groups/' . $g['id'] . '/edit') ?>" class="btn btn-sm btn-secondary">Sửa</a>
                        <?php endif; ?>
                        <?php if (Auth::hasPermission('kpi_group.delete') && (int)$g['kpi_count'] === 0): ?>
                        <form method="POST" action="<?= url('kpi-groups/' . $g['id'] . '/delete') ?>" style="display:inline">
                            <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                            <button type="submit" class="btn btn-sm btn-danger" data-confirm="Xóa nhóm KPI này? Thao tác không thể hoàn tác." data-confirm-title="Xóa nhóm KPI">Xóa</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
</div>