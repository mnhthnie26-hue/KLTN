<?php
/** @var array|null $group */
$isEdit = !empty($group);
$g = $group ?? [];
?>
<div class="page-header">
    <h1 class="page-title"><?= $isEdit ? 'Sửa' : 'Tạo' ?> Nhóm KPI</h1>
    <a href="<?= url('kpi-groups') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? url('kpi-groups/' . $g['id']) : url('kpi-groups') ?>">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

            <div class="row">
                <?php if (!$isEdit): ?>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Mã <span class="required">*</span></label>
                        <input type="text" name="code" value="<?= e($g['code'] ?? '') ?>" required pattern="[A-Za-z0-9_-]+" class="form-control">
                    </div>
                </div>
                <?php endif; ?>
                <div class="col-md-<?= $isEdit ? '8' : '4' ?>">
                    <div class="form-group">
                        <label>Tên <span class="required">*</span></label>
                        <input type="text" name="name" value="<?= e($g['name'] ?? '') ?>" required class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Thứ tự</label>
                        <input type="number" name="sort_order" value="<?= e($g['sort_order'] ?? 0) ?>" class="form-control">
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Mô tả</label>
                <textarea name="description" rows="2" class="form-control"><?= e($g['description'] ?? '') ?></textarea>
            </div>

            <?php if ($isEdit): ?>
            <div class="form-group">
                <label>Trạng thái</label>
                <select name="status" class="form-control">
                    <option value="1" <?= (int)$g['status'] === 1 ? 'selected' : '' ?>>Hoạt động</option>
                    <option value="0" <?= (int)$g['status'] === 0 ? 'selected' : '' ?>>Tắt</option>
                </select>
            </div>
            <?php endif; ?>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Cập nhật' : 'Tạo' ?></button>
                <a href="<?= url('kpi-groups') ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>