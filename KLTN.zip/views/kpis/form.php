<?php
/** @var array|null $kpi */
/** @var array $groups */
$isEdit = !empty($kpi);
$kpiData = $kpi ?? [];
?>
<div class="page-header">
    <h1 class="page-title"><?= $isEdit ? 'Sửa' : 'Tạo' ?> KPI</h1>
    <a href="<?= url('kpis') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? url('kpis/' . $kpi['id']) : url('kpis') ?>">
            <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">

            <div class="row">
                <?php if (!$isEdit): ?>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Mã KPI <span class="required">*</span></label>
                        <input type="text" name="code" value="<?= e($kpiData['code'] ?? '') ?>" required pattern="[A-Za-z0-9_-]+" class="form-control">
                    </div>
                </div>
                <?php endif; ?>
                <div class="col-md-<?= $isEdit ? '6' : '4' ?>">
                    <div class="form-group">
                        <label>Tên KPI <span class="required">*</span></label>
                        <input type="text" name="name" value="<?= e($kpiData['name'] ?? '') ?>" required class="form-control">
                    </div>
                </div>
                <div class="col-md-<?= $isEdit ? '6' : '4' ?>">
                    <div class="form-group">
                        <label>Nhóm KPI <span class="required">*</span></label>
                        <select name="kpi_group_id" required class="form-control">
                            <option value="">-- Chọn --</option>
                            <?php foreach ($groups as $g): ?>
                            <option value="<?= $g['id'] ?>" <?= (int)($kpiData['kpi_group_id'] ?? 0) === (int)$g['id'] ? 'selected' : '' ?>><?= e($g['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-group">
                <label>Mô tả</label>
                <textarea name="description" rows="3" class="form-control"><?= e($kpiData['description'] ?? '') ?></textarea>
            </div>

            <h3 class="form-section-title">Thang điểm</h3>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Điểm tối thiểu</label>
                        <input type="number" name="min_score" value="<?= e($kpiData['min_score'] ?? $minScore ?? 1) ?>" step="0.01" required class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Điểm tối đa</label>
                        <input type="number" name="max_score" value="<?= e($kpiData['max_score'] ?? $maxScore ?? 5) ?>" step="0.01" required class="form-control">
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label>Bước điểm</label>
                        <input type="number" name="score_step" value="<?= e($kpiData['score_step'] ?? $step ?? 1) ?>" step="0.01" required class="form-control">
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Thứ tự</label>
                        <input type="number" name="sort_order" value="<?= e($kpiData['sort_order'] ?? 0) ?>" class="form-control">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Trạng thái</label>
                        <select name="status" class="form-control">
                            <option value="1" <?= !isset($kpiData['status']) || (int)$kpiData['status'] === 1 ? 'selected' : '' ?>>Hoạt động</option>
                            <option value="0" <?= isset($kpiData['status']) && (int)$kpiData['status'] === 0 ? 'selected' : '' ?>>Tắt</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Cập nhật' : 'Tạo' ?></button>
                <a href="<?= url('kpis') ?>" class="btn btn-secondary">Hủy</a>
            </div>
        </form>
    </div>
</div>