<?php
/** @var array $kpi */
/** @var bool $weightValid */
?>
<div class="page-header">
    <h1 class="page-title"><?= e($kpi['name']) ?></h1>
    <a href="<?= url('kpis') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
    <?php if (Auth::hasPermission('kpi.update')): ?>
    <a href="<?= url('kpis/' . $kpi['id'] . '/edit') ?>" class="btn btn-primary">Sửa KPI</a>
    <?php endif; ?>
    <?php if (Auth::hasPermission('kpi.delete')): ?>
    <form method="POST" action="<?= url('kpis/' . $kpi['id'] . '/delete') ?>" style="display:inline" data-confirm="Xóa KPI này? Toàn bộ tiêu chí liên quan cũng sẽ bị ảnh hưởng." data-confirm-title="Xóa KPI">
        <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
        <button type="submit" class="btn btn-danger">Xóa</button>
    </form>
    <?php endif; ?>
</div>

<div class="row">
    <div class="col-md-4">
        <div class="card">
            <div class="card-header"><h3>Thông tin</h3></div>
            <div class="card-body">
                <p><strong>Mã:</strong> <code><?= e($kpi['code']) ?></code></p>
                <p><strong>Nhóm:</strong> <?= e($kpi['group_name']) ?></p>
                <p><strong>Thang điểm:</strong> <?= e($kpi['min_score']) ?> - <?= e($kpi['max_score']) ?> (bước <?= e($kpi['score_step']) ?>)</p>
                <p><strong>Mô tả:</strong> <?= e($kpi['description'] ?? '') ?></p>
                <p><strong>Trạng thái:</strong> <?= (int)$kpi['status'] === 1 ? '<span class="badge badge-success">Hoạt động</span>' : '<span class="badge">Tắt</span>' ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h3>Tiêu chí (<?= count($kpi['criteria']) ?>)</h3>
                <div>
                    <strong>Tổng trọng số: <?= e(number_format((float)$kpi['total_weight'], 2)) ?>%</strong>
                    <?php if ($weightValid): ?>
                    <span class="badge badge-success">Hợp lệ</span>
                    <?php else: ?>
                    <span class="badge badge-warning">Tổng phải = 100%</span>
                    <?php endif; ?>
                    <?php if (Auth::hasPermission('criteria.create')): ?>
                    <a href="<?= url('criteria/create?kpi_id=' . $kpi['id']) ?>" class="btn btn-sm btn-primary">+ Thêm tiêu chí</a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="card-body">
                <?php if (empty($kpi['criteria'])): ?>
                <p class="text-muted">Chưa có tiêu chí.</p>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Mã</th>
                                <th>Tên</th>
                                <th>Loại</th>
                                <th>Trọng số</th>
                                <th>Thang điểm</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($kpi['criteria'] as $c): ?>
                            <tr>
                                <td><code><?= e($c['code']) ?></code></td>
                                <td><?= e($c['name']) ?></td>
                                <td><?= e($c['evaluation_type']) ?></td>
                                <td><strong><?= e(number_format((float)$c['weight'], 2)) ?>%</strong></td>
                                <td><?= e($c['min_score']) ?> - <?= e($c['max_score']) ?></td>
                                <td class="actions">
                                    <?php if (Auth::hasPermission('criteria.update')): ?>
                                    <a href="<?= url('criteria/' . $c['id'] . '/edit') ?>" class="btn btn-sm btn-secondary">Sửa</a>
                                    <?php endif; ?>
                                    <?php if (Auth::hasPermission('criteria.delete')): ?>
                                    <form method="POST" action="<?= url('criteria/' . $c['id'] . '/delete') ?>" style="display:inline">
                                        <input type="hidden" name="_csrf_token" value="<?= Session::csrfToken() ?>">
                                        <button type="submit" class="btn btn-sm btn-danger" data-confirm="Xóa tiêu chí này? Thao tác không thể hoàn tác." data-confirm-title="Xóa tiêu chí">Xóa</button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>