<?php
/** @var array $kpis */
/** @var array $criteria */
/** @var array $currentMatrix */
?>
<div class="page-header">
    <h1 class="page-title">Phân tích AHP</h1>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
            <div class="card-header"><h3>Tạo ma trận AHP</h3></div>
            <div class="card-body">
                <form method="GET" action="<?= url('analysis/ahp') ?>" id="kpiForm">
                    <div class="form-group">
                        <label>Chọn KPI</label>
                        <select name="kpi_id" class="form-control" onchange="this.form.submit()">
                            <option value="">-- Chọn --</option>
                            <?php foreach ($kpis as $k): ?>
                            <option value="<?= $k['id'] ?>" <?= (int)($currentKpiId ?? 0) === (int)$k['id'] ? 'selected' : '' ?>><?= e($k['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>

                <?php if (!empty($criteria) && count($criteria) >= 2): ?>
                <hr>
                <p class="text-muted">Điền ma trận so sánh cặp theo thang 1-9</p>

                <form method="POST" action="<?= url('analysis/ahp') ?>" id="ahpForm">
                    <input type="hidden" name="_csrf_token" value="<?= e($csrf_token) ?>">
                    <input type="hidden" name="kpi_id" value="<?= $currentKpiId ?>">
                    <input type="hidden" name="matrix" id="matrixData">

                    <?php foreach ($criteria as $i => $c): ?>
                    <input type="hidden" name="criteria_ids[]" value="<?= $c['id'] ?>">
                    <?php endforeach; ?>

                    <div class="form-group">
                        <label>Tên ma trận <span class="required">*</span></label>
                        <input type="text" name="name" value="AHP <?= e($criteria[0]['name'] ?? '') ?>" required class="form-control">
                    </div>

                    <div class="ahp-wrap" style="--ahp-min: <?= (count($criteria) + 1) * 130 ?>px">
                        <table class="table" id="ahpMatrixTable">
                            <thead>
                                <tr>
                                    <th></th>
                                    <?php foreach ($criteria as $c): ?>
                                    <th><?= e($c['name']) ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($criteria as $i => $c): ?>
                                <tr>
                                    <th><?= e($c['name']) ?></th>
                                    <?php for ($j = 0; $j < count($criteria); $j++): ?>
                                    <td>
                                        <?php if ($i === $j): ?>
                                        <strong>1</strong>
                                        <?php elseif ($i < $j): ?>
                                        <select class="form-control ahp-input" data-i="<?= $i ?>" data-j="<?= $j ?>">
                                            <?php for ($v = 1; $v <= 9; $v++): ?>
                                            <option value="<?= $v ?>"><?= $v ?></option>
                                            <?php endfor; ?>
                                        </select>
                                        <?php else: ?>
                                        <span class="ahp-mirror" data-i="<?= $i ?>" data-j="<?= $j ?>">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <?php endfor; ?>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">Tính AHP</button>
                </form>
                <?php elseif (!empty($criteria)): ?>
                <p class="text-muted">KPI cần ít nhất 2 tiêu chí để tính AHP.</p>
                <?php endif; ?>
            </div>
</div>

<div class="row">
    <div class="col-md-6">
        <?php if ($currentMatrix): ?>
        <div class="card">
            <div class="card-header">
                <h3><?= e($currentMatrix['name']) ?></h3>
            </div>
            <div class="card-body">
                <?php if ($currentMatrix['consistency']): ?>
                <div class="row ahp-stats">
                    <div class="col-md-3">
                        <div class="stat-label">λ max</div>
                        <strong><?= number_format((float)$currentMatrix['consistency']['lambda_max'], 4) ?></strong>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-label">CI</div>
                        <strong><?= number_format((float)$currentMatrix['consistency']['consistency_index'], 4) ?></strong>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-label">CR</div>
                        <strong><?= number_format((float)$currentMatrix['consistency']['consistency_ratio'], 4) ?></strong>
                    </div>
                    <div class="col-md-3">
                        <div class="stat-label">Tính nhất quán</div>
                        <?php if ((int)$currentMatrix['consistency']['is_consistent'] === 1): ?>
                        <span class="badge badge-success">Nhất quán</span>
                        <?php else: ?>
                        <span class="badge badge-warning">Chưa nhất quán</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ((int)$currentMatrix['consistency']['is_consistent'] === 0): ?>
                <div class="alert alert-warning mt-2">
                    CR &gt; 0.1. Ma trận chưa nhất quán, vui lòng kiểm tra lại các đánh giá.
                </div>
                <?php endif; ?>
                <?php endif; ?>

                <h4 class="mt-3">Trọng số</h4>
                <table class="table">
                    <thead><tr><th>Hạng</th><th>Tiêu chí</th><th>Trọng số</th></tr></thead>
                    <tbody>
                        <?php foreach ($currentMatrix['weights'] as $w): ?>
                        <tr>
                            <td><?= (int)$w['rank'] ?></td>
                            <td><?= e($w['criterion_name']) ?></td>
                            <td><strong><?= number_format((float)$w['weight'] * 100, 2) ?>%</strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php else: ?>
        <div class="card">
            <div class="card-header"><h3>Kết quả AHP</h3></div>
            <div class="card-body"><p class="text-muted">Chọn một ma trận đã lưu hoặc tính ma trận mới để xem trọng số.</p></div>
        </div>
        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header"><h3>Ma trận đã lưu</h3></div>
            <div class="card-body">
                <?php if (empty($matrices)): ?>
                <p class="text-muted">Chưa có ma trận nào.</p>
                <?php else: ?>
                <table class="table">
                    <thead><tr><th>Tên</th><th>KPI</th><th>Ngày tạo</th><th>Thao tác</th></tr></thead>
                    <tbody>
                        <?php foreach ($matrices as $m): ?>
                        <tr>
                            <td><?= e($m['name']) ?></td>
                            <td><?= e($m['kpi_name'] ?? '-') ?></td>
                            <td><?= e(formatDateTime($m['created_at'])) ?></td>
                            <td><a href="<?= url('analysis/ahp?matrix_id=' . $m['id']) ?>" class="btn btn-sm btn-secondary">Xem</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
(function() {
    // Update mirror values
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('ahp-input')) {
            const i = parseInt(e.target.dataset.i);
            const j = parseInt(e.target.dataset.j);
            const v = parseInt(e.target.value);
            // Mirror
            const mirror = document.querySelector('.ahp-mirror[data-i="' + j + '"][data-j="' + i + '"]');
            if (mirror) {
                mirror.textContent = (1 / v).toFixed(3);
            }
            buildMatrix();
        }
    });

    function buildMatrix() {
        const criteriaCount = document.querySelectorAll('input[name="criteria_ids[]"]').length;
        const matrix = [];
        for (let i = 0; i < criteriaCount; i++) {
            matrix[i] = [];
            for (let j = 0; j < criteriaCount; j++) {
                if (i === j) {
                    matrix[i][j] = 1;
                } else if (i < j) {
                    const input = document.querySelector('.ahp-input[data-i="' + i + '"][data-j="' + j + '"]');
                    matrix[i][j] = input ? parseInt(input.value) : 1;
                } else {
                    const input = document.querySelector('.ahp-input[data-i="' + j + '"][data-j="' + i + '"]');
                    const v = input ? parseInt(input.value) : 1;
                    matrix[i][j] = 1 / v;
                }
            }
        }
        document.getElementById('matrixData').value = JSON.stringify(matrix);
    }

    // Initial build
    buildMatrix();
})();
</script>