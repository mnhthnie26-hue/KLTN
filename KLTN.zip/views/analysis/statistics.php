<?php
/** @var array $surveys */
/** @var array $stats */
?>
<div class="page-header">
    <h1 class="page-title">Thống kê</h1>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('analysis/statistics') ?>" class="filter-form">
            <select name="survey_id" class="form-control">
                <option value="">-- Chọn khảo sát --</option>
                <?php foreach ($surveys as $s): ?>
                <option value="<?= $s['id'] ?>" <?= (int)($surveyId ?? 0) === (int)$s['id'] ? 'selected' : '' ?>><?= e($s['title']) ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
</div>

<?php if ($stats && !empty($stats['questions'])): ?>
<div class="card">
    <div class="card-header">
        <h3>Thống kê: <?= e($stats['survey']['title']) ?></h3>
        <span class="badge badge-info"><?= $stats['response_count'] ?> phản hồi</span>
    </div>
    <div class="card-body">
        <?php foreach ($stats['questions'] as $i => $q): ?>
        <div class="card mb-2" style="background: #f9fafb;">
            <div class="card-body">
                <h4>Câu <?= $i + 1 ?>: <?= e($q['question']['question_text']) ?></h4>
                <div class="row">
                    <div class="col-md-3"><div class="stat-label">Số phản hồi</div><strong><?= $q['count'] ?></strong></div>
                    <div class="col-md-3"><div class="stat-label">Mean</div><strong><?= number_format($q['mean'], 2) ?></strong></div>
                    <div class="col-md-3"><div class="stat-label">Median</div><strong><?= number_format($q['median'], 2) ?></strong></div>
                    <div class="col-md-3"><div class="stat-label">Std Dev</div><strong><?= number_format($q['std_dev'], 2) ?></strong></div>
                </div>
                <div class="row mt-2">
                    <div class="col-md-12">
                        <strong>Min:</strong> <?= number_format($q['min'], 2) ?> |
                        <strong>Max:</strong> <?= number_format($q['max'], 2) ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php else: ?>
<div class="empty-state"><p>Chọn khảo sát để xem thống kê.</p></div>
<?php endif; ?>