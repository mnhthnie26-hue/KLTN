<?php
/** @var array $rankings */
/** @var string $rankType */
?>
<div class="page-header">
    <h1 class="page-title">Xếp hạng</h1>
    <a href="<?= url('dashboard') ?>" class="btn btn-secondary btn-back">&laquo; Quay lại</a>
</div>

<div class="card">
    <div class="card-body">
        <form method="GET" action="<?= url('analysis/ranking') ?>" class="filter-form">
            <select name="type" class="form-control">
                <option value="overall" <?= $rankType === 'overall' ? 'selected' : '' ?>>Tổng thể</option>
                <option value="kpi" <?= $rankType === 'kpi' ? 'selected' : '' ?>>Theo KPI</option>
                <option value="criterion" <?= $rankType === 'criterion' ? 'selected' : '' ?>>Theo tiêu chí</option>
            </select>
            <input type="text" name="period" value="<?= e($period) ?>" placeholder="Kỳ (2025-H1)" class="form-control">
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <?php if (empty($rankings)): ?>
        <div class="empty-state"><p>Chưa có dữ liệu xếp hạng.</p></div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Hạng</th>
                        <th>Tên</th>
                        <th>KPI</th>
                        <th>Điểm</th>
                        <th>Xếp loại</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($rankings as $r): ?>
                    <tr>
                        <td>
                            <?php if ((int)$r['rank'] <= 3): ?>
                            <span class="badge badge-<?= (int)$r['rank'] === 1 ? 'success' : ((int)$r['rank'] === 2 ? 'info' : 'warning') ?>">#<?= $r['rank'] ?></span>
                            <?php else: ?>
                            #<?= $r['rank'] ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= e($r['name'] ?? $r['kpi_name'] ?? '-') ?></strong>
                        </td>
                        <td><?= e($r['kpi_name'] ?? '-') ?></td>
                        <td><strong><?= number_format((float)($r['avg_score'] ?? $r['normalized_score'] ?? 0), 2) ?></strong></td>
                        <td><?= e($r['classification'] ?? '') ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
</div>