<?php
/**
 * Generic 404 error page - self-contained HTML.
 * Included directly from Router::handleNotFound.
 */
http_response_code(404);
?><!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang không tồn tại | <?= htmlspecialchars(defined('APP_NAME') ? APP_NAME : '') ?></title>
    <style>
        body{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#f8fafc;color:#222;margin:0;padding:40px 16px}
        .error-page{max-width:560px;margin:60px auto;text-align:center;background:#fff;border-radius:12px;padding:48px 32px;box-shadow:0 1px 3px rgba(0,0,0,.05)}
        .error-code{font-size:96px;font-weight:800;color:#0ea5e9;line-height:1;margin-bottom:16px}
        h1{margin:0 0 12px;font-size:24px}
        p{margin:8px 0;color:#64748b}
        .btn{display:inline-block;margin-top:24px;padding:10px 20px;border-radius:8px;background:#2563eb;color:#fff;text-decoration:none;font-weight:500}
        .btn:hover{background:#1d4ed8}
    </style>
</head>
<body>
    <div class="error-page">
        <div class="error-code">404</div>
        <h1>Trang không tồn tại</h1>
        <p>Trang bạn đang tìm kiếm không tồn tại hoặc đã được di chuyển.</p>
        <a href="<?= htmlspecialchars((defined('APP_URL') ? APP_URL : '') . '/dashboard') ?>" class="btn">Về Tổng quan</a>
    </div>
</body>
</html>