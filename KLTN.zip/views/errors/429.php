<?php
/**
 * Generic 429 error page - self-contained HTML.
 *
 * @var int|null $retry_after
 */
http_response_code(429);
?><!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quá nhiều yêu cầu | <?= htmlspecialchars(defined('APP_NAME') ? APP_NAME : '') ?></title>
    <style>
        body{font-family:system-ui,Segoe UI,Arial,sans-serif;background:#f8fafc;color:#222;margin:0;padding:40px 16px}
        .error-page{max-width:560px;margin:60px auto;text-align:center;background:#fff;border-radius:12px;padding:48px 32px;box-shadow:0 1px 3px rgba(0,0,0,.05)}
        .error-code{font-size:96px;font-weight:800;color:#ef4444;line-height:1;margin-bottom:16px}
        h1{margin:0 0 12px;font-size:24px}
        p{margin:8px 0;color:#64748b}
        .btn{display:inline-block;margin-top:24px;padding:10px 20px;border-radius:8px;background:#2563eb;color:#fff;text-decoration:none;font-weight:500}
        .btn:hover{background:#1d4ed8}
    </style>
</head>
<body>
    <div class="error-page">
        <div class="error-code">429</div>
        <h1>Quá nhiều yêu cầu</h1>
        <p>Bạn đã thực hiện quá nhiều yêu cầu. Vui lòng thử lại sau <?= isset($retry_after) ? ceil($retry_after/60) . ' phút' : 'một lúc' ?>.</p>
        <a href="<?= htmlspecialchars((defined('APP_URL') ? APP_URL : '') . '/dashboard') ?>" class="btn">Về Tổng quan</a>
    </div>
</body>
</html>