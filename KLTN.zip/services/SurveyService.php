<?php
/**
 * SurveyService
 */

declare(strict_types=1);

class SurveyService
{
    private SurveyRepository $surveyRepo;
    private ResponseRepository $responseRepo;
    private KpiService $kpiService;

    public function __construct()
    {
        $this->surveyRepo = new SurveyRepository();
        $this->responseRepo = new ResponseRepository();
        $this->kpiService = new KpiService();
    }

    public function list(int $page, int $perPage, array $filters): array
    {
        return $this->surveyRepo->getList($page, $perPage, $filters);
    }

    public function get(int $id): ?array
    {
        $survey = $this->surveyRepo->getWithKpi($id);
        if (!$survey) return null;
        $survey['questions'] = $this->surveyRepo->getQuestionsWithOptions($id);
        $survey['response_count'] = $this->responseRepo->getCompletedCount($id);
        return $survey;
    }

    public function create(array $data): array
    {
        $validator = Validator::make($data, [
            'code'  => 'required|string|max:50|unique:surveys,code',
            'title' => 'required|string|max:255',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $first = reset($errors);
            return ['success' => false, 'message' => $first[0] ?? 'Dữ liệu không hợp lệ', 'errors' => $errors];
        }

        // Validate KPI weight if linked
        if (!empty($data['kpi_id'])) {
            $kpi = (new KpiRepository())->find((int)$data['kpi_id']);
            if (!$kpi) {
                return ['success' => false, 'message' => 'KPI không tồn tại'];
            }
            // Check total weight = 100 only if has criteria
            $criteria = (new CriterionRepository())->getByKpi((int)$data['kpi_id']);
            if (!empty($criteria)) {
                $totalWeight = array_sum(array_column($criteria, 'weight'));
                if (abs($totalWeight - 100) > 0.01) {
                    return ['success' => false, 'message' => 'Tổng trọng số KPI phải = 100%. Hiện tại: ' . number_format($totalWeight, 2) . '%'];
                }
            }
        }

        try {
            $id = $this->surveyRepo->create([
                'code'                 => Security::sanitize($data['code']),
                'title'                => Security::sanitize($data['title']),
                'description'          => Security::sanitize($data['description'] ?? ''),
                'kpi_id'               => !empty($data['kpi_id']) ? (int)$data['kpi_id'] : null,
                'target_type'          => $data['target_type'] ?? 'all',
                'start_date'           => !empty($data['start_date']) ? date('Y-m-d H:i:s', strtotime($data['start_date'])) : null,
                'end_date'             => !empty($data['end_date']) ? date('Y-m-d H:i:s', strtotime($data['end_date'])) : null,
                'one_response_per_user'=> isset($data['one_response_per_user']) ? 1 : 0,
                'allow_anonymous'      => isset($data['allow_anonymous']) ? 1 : 0,
                'status'               => 'draft',
                'created_by'           => Auth::id(),
            ]);

            Logger::getInstance()->audit(AUDIT_CREATE, 'survey', Auth::id(), $id, null, $data, 'Tạo khảo sát');
            return ['success' => true, 'message' => 'Đã tạo khảo sát. Vui lòng thêm câu hỏi.', 'id' => $id];
        } catch (Throwable $e) {
            ErrorLog::error('[SurveyService::create] failed', $data, $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra'];
        }
    }

    public function update(int $id, array $data): array
    {
        $survey = $this->surveyRepo->find($id);
        if (!$survey) return ['success' => false, 'message' => 'Khảo sát không tồn tại'];

        // Only non-admin users with explicit permission are blocked from editing published surveys.
        // Admin (user_type='admin') can always edit everything.
        if ($survey['status'] === 'published' && !Auth::isAdmin()) {
            return ['success' => false, 'message' => 'Khảo sát đã publish, không thể sửa'];
        }

        try {
            $this->surveyRepo->update($id, [
                'title'                => Security::sanitize($data['title']),
                'description'          => Security::sanitize($data['description'] ?? ''),
                'kpi_id'               => !empty($data['kpi_id']) ? (int)$data['kpi_id'] : null,
                'target_type'          => $data['target_type'] ?? 'all',
                'start_date'           => !empty($data['start_date']) ? date('Y-m-d H:i:s', strtotime($data['start_date'])) : null,
                'end_date'             => !empty($data['end_date']) ? date('Y-m-d H:i:s', strtotime($data['end_date'])) : null,
                'one_response_per_user'=> isset($data['one_response_per_user']) ? 1 : 0,
                'allow_anonymous'      => isset($data['allow_anonymous']) ? 1 : 0,
            ]);

            Logger::getInstance()->audit(AUDIT_UPDATE, 'survey', Auth::id(), $id, $survey, $data, 'Cập nhật khảo sát');
            return ['success' => true, 'message' => 'Đã cập nhật khảo sát'];
        } catch (Throwable $e) {
            ErrorLog::error('[SurveyService::update] failed', ['id' => $id], $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra'];
        }
    }

    public function delete(int $id): array
    {
        $survey = $this->surveyRepo->find($id);
        if (!$survey) return ['success' => false, 'message' => 'Khảo sát không tồn tại'];

        $hasResponses = $this->responseRepo->getCompletedCount($id) > 0;
        if ($hasResponses) {
            // Soft delete to preserve history
            $this->surveyRepo->softDelete($id);
            Logger::getInstance()->audit(AUDIT_DELETE, 'survey', Auth::id(), $id, $survey, null, 'Xóa mềm khảo sát');
            return ['success' => true, 'message' => 'Đã xóa khảo sát (đã có phản hồi, dữ liệu được lưu lại)'];
        }

        $this->surveyRepo->softDelete($id);
        Logger::getInstance()->audit(AUDIT_DELETE, 'survey', Auth::id(), $id, $survey, null, 'Xóa khảo sát');
        return ['success' => true, 'message' => 'Đã xóa khảo sát'];
    }

    public function publish(int $id): array
    {
        $survey = $this->surveyRepo->getWithKpi($id);
        if (!$survey) return ['success' => false, 'message' => 'Khảo sát không tồn tại'];

        // Must have at least 1 question
        $questions = $this->surveyRepo->getQuestions($id);
        if (empty($questions)) {
            return ['success' => false, 'message' => 'Khảo sát phải có ít nhất 1 câu hỏi'];
        }

        // If linked to KPI, check weight
        if ($survey['kpi_id']) {
            $criteria = (new CriterionRepository())->getByKpi((int)$survey['kpi_id']);
            if (!empty($criteria)) {
                $totalWeight = array_sum(array_column($criteria, 'weight'));
                if (abs($totalWeight - 100) > 0.01) {
                    return ['success' => false, 'message' => 'Tổng trọng số KPI phải = 100% mới có thể publish'];
                }
            }
        }

        $this->surveyRepo->publish($id);
        Logger::getInstance()->audit(AUDIT_PUBLISH, 'survey', Auth::id(), $id, $survey, null, 'Publish khảo sát');
        return ['success' => true, 'message' => 'Đã publish khảo sát'];
    }

    public function close(int $id): array
    {
        $survey = $this->surveyRepo->find($id);
        if (!$survey) return ['success' => false, 'message' => 'Khảo sát không tồn tại'];

        $this->surveyRepo->close($id);
        Logger::getInstance()->audit(AUDIT_UPDATE, 'survey', Auth::id(), $id, $survey, null, 'Đóng khảo sát');
        return ['success' => true, 'message' => 'Đã đóng khảo sát'];
    }

    public function duplicate(int $id): array
    {
        $survey = $this->surveyRepo->getWithKpi($id);
        if (!$survey) return ['success' => false, 'message' => 'Khảo sát không tồn tại'];

        try {
            $newId = $this->surveyRepo->create([
                'code'                 => $survey['code'] . '_COPY_' . time(),
                'title'                => $survey['title'] . ' (Bản sao)',
                'description'          => $survey['description'],
                'kpi_id'               => $survey['kpi_id'],
                'target_type'          => $survey['target_type'],
                'one_response_per_user'=> $survey['one_response_per_user'],
                'allow_anonymous'      => $survey['allow_anonymous'],
                'status'               => 'draft',
                'created_by'           => Auth::id(),
            ]);

            // Duplicate questions
            $questions = $this->surveyRepo->getQuestionsWithOptions($id);
            foreach ($questions as $q) {
                $newQId = Database::getInstance()->insert('survey_questions', [
                    'survey_id'     => $newId,
                    'criterion_id'  => $q['criterion_id'],
                    'question_text' => $q['question_text'],
                    'question_type' => $q['question_type'],
                    'is_required'   => $q['is_required'],
                    'min_value'     => $q['min_value'],
                    'max_value'     => $q['max_value'],
                    'sort_order'    => $q['sort_order'],
                ]);

                foreach ($q['options'] as $opt) {
                    Database::getInstance()->insert('survey_options', [
                        'question_id'  => $newQId,
                        'option_text'  => $opt['option_text'],
                        'option_value' => $opt['option_value'],
                        'sort_order'   => $opt['sort_order'],
                    ]);
                }
            }

            return ['success' => true, 'message' => 'Đã sao chép khảo sát', 'id' => $newId];
        } catch (Throwable $e) {
            ErrorLog::error('[SurveyService::duplicate] failed', ['id' => $id], $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra'];
        }
    }

    public function saveQuestions(int $surveyId, array $questionsData): array
    {
        $db = Database::getInstance();
        return $db->transaction(function() use ($db, $surveyId, $questionsData) {
            // Delete all existing questions (cascade options)
            $db->query('DELETE FROM survey_questions WHERE survey_id = ?', [$surveyId]);

            foreach ($questionsData as $i => $q) {
                $questionId = $db->insert('survey_questions', [
                    'survey_id'     => $surveyId,
                    'criterion_id'  => !empty($q['criterion_id']) ? (int)$q['criterion_id'] : null,
                    'question_text' => Security::sanitize($q['question_text'] ?? ''),
                    'question_type' => $q['question_type'] ?? 'text',
                    'is_required'   => isset($q['is_required']) ? 1 : 0,
                    'min_value'     => !empty($q['min_value']) ? (float)$q['min_value'] : null,
                    'max_value'     => !empty($q['max_value']) ? (float)$q['max_value'] : null,
                    'sort_order'    => $i,
                ]);

                if (!empty($q['options']) && is_array($q['options'])) {
                    foreach ($q['options'] as $j => $opt) {
                        $db->insert('survey_options', [
                            'question_id'  => $questionId,
                            'option_text'  => Security::sanitize($opt['text'] ?? ''),
                            'option_value' => isset($opt['value']) && $opt['value'] !== '' ? (float)$opt['value'] : null,
                            'sort_order'   => $j,
                        ]);
                    }
                }
            }

            Logger::getInstance()->audit(AUDIT_UPDATE, 'survey', Auth::id(), $surveyId, null, ['question_count' => count($questionsData)], 'Lưu câu hỏi khảo sát');
            return ['success' => true, 'message' => 'Đã lưu câu hỏi'];
        });
    }
}