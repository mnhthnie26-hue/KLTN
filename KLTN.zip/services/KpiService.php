<?php
/**
 * KpiService - Business logic for KPI management
 */

declare(strict_types=1);

class KpiService
{
    private KpiRepository $kpiRepo;
    private KpiGroupRepository $groupRepo;
    private CriterionRepository $criteriaRepo;

    public function __construct()
    {
        $this->kpiRepo = new KpiRepository();
        $this->groupRepo = new KpiGroupRepository();
        $this->criteriaRepo = new CriterionRepository();
    }

    public function getKpis(int $page, int $perPage, array $filters): array
    {
        $db = Database::getInstance();
        $where = ['k.deleted_at IS NULL'];
        $params = [];

        if (!empty($filters['search'])) {
            $where[] = '(k.code LIKE ? OR k.name LIKE ?)';
            $term = '%' . $filters['search'] . '%';
            $params[] = $term;
            $params[] = $term;
        }
        if (!empty($filters['kpi_group_id'])) {
            $where[] = 'k.kpi_group_id = ?';
            $params[] = (int)$filters['kpi_group_id'];
        }
        if (isset($filters['status']) && $filters['status'] !== '') {
            $where[] = 'k.status = ?';
            $params[] = (int)$filters['status'];
        }

        $whereSql = implode(' AND ', $where);
        $total = (int)$db->fetchValue("SELECT COUNT(*) FROM kpis k WHERE {$whereSql}", $params);
        $offset = ($page - 1) * $perPage;

        $items = $db->fetchAll(
            "SELECT k.*, kg.name AS group_name, kg.code AS group_code,
                    (SELECT COUNT(*) FROM criteria c WHERE c.kpi_id = k.id AND c.deleted_at IS NULL) AS criteria_count
             FROM kpis k
             INNER JOIN kpi_groups kg ON k.kpi_group_id = kg.id
             WHERE {$whereSql}
             ORDER BY kg.sort_order, k.sort_order, k.id
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return [
            'items' => $items,
            'total' => $total,
            'pagination' => paginate($total, $page, $perPage),
        ];
    }

    public function getKpi(int $id): ?array
    {
        $kpi = $this->kpiRepo->getWithGroup($id);
        if (!$kpi) return null;
        $kpi['criteria'] = $this->criteriaRepo->getByKpi($id);
        $kpi['total_weight'] = $this->criteriaRepo->getTotalWeight($id);
        return $kpi;
    }

    public function createKpi(array $data): array
    {
        $validator = Validator::make($data, [
            'code'        => 'required|string|max:50|unique:kpis,code',
            'name'        => 'required|string|max:200',
            'kpi_group_id'=> 'required|integer',
            'min_score'   => 'required|numeric',
            'max_score'   => 'required|numeric',
            'score_step'  => 'required|numeric',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $first = reset($errors);
            return ['success' => false, 'message' => $first[0] ?? 'Dữ liệu không hợp lệ', 'errors' => $errors];
        }

        if ((float)$data['max_score'] <= (float)$data['min_score']) {
            return ['success' => false, 'message' => 'Điểm tối đa phải lớn hơn điểm tối thiểu'];
        }

        try {
            $kpiId = $this->kpiRepo->create([
                'kpi_group_id' => (int)$data['kpi_group_id'],
                'code'         => Security::sanitize($data['code']),
                'name'         => Security::sanitize($data['name']),
                'description'  => Security::sanitize($data['description'] ?? ''),
                'min_score'    => (float)$data['min_score'],
                'max_score'    => (float)$data['max_score'],
                'score_step'   => (float)$data['score_step'],
                'sort_order'   => (int)($data['sort_order'] ?? 0),
                'status'       => isset($data['status']) ? (int)$data['status'] : 1,
                'created_by'   => Auth::id(),
            ]);

            Logger::getInstance()->audit(AUDIT_CREATE, 'kpi', Auth::id(), $kpiId, null, $data, 'Tạo KPI');
            return ['success' => true, 'message' => 'Đã tạo KPI thành công', 'id' => $kpiId];
        } catch (Throwable $e) {
            ErrorLog::error('[KpiService::createKpi] failed', $data, $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra'];
        }
    }

    public function updateKpi(int $id, array $data): array
    {
        $kpi = $this->kpiRepo->find($id);
        if (!$kpi) return ['success' => false, 'message' => 'KPI không tồn tại'];

        $validator = Validator::make($data, [
            'name'        => 'required|string|max:200',
            'kpi_group_id'=> 'required|integer',
            'min_score'   => 'required|numeric',
            'max_score'   => 'required|numeric',
            'score_step'  => 'required|numeric',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $first = reset($errors);
            return ['success' => false, 'message' => $first[0] ?? 'Dữ liệu không hợp lệ', 'errors' => $errors];
        }

        if ((float)$data['max_score'] <= (float)$data['min_score']) {
            return ['success' => false, 'message' => 'Điểm tối đa phải lớn hơn điểm tối thiểu'];
        }

        try {
            $this->kpiRepo->update($id, [
                'kpi_group_id' => (int)$data['kpi_group_id'],
                'name'         => Security::sanitize($data['name']),
                'description'  => Security::sanitize($data['description'] ?? ''),
                'min_score'    => (float)$data['min_score'],
                'max_score'    => (float)$data['max_score'],
                'score_step'   => (float)$data['score_step'],
                'sort_order'   => (int)($data['sort_order'] ?? 0),
                'status'       => isset($data['status']) ? (int)$data['status'] : 1,
            ]);

            Logger::getInstance()->audit(AUDIT_UPDATE, 'kpi', Auth::id(), $id, $kpi, $data, 'Cập nhật KPI');
            return ['success' => true, 'message' => 'Đã cập nhật KPI'];
        } catch (Throwable $e) {
            ErrorLog::error('[KpiService::updateKpi] failed', ['id' => $id], $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra'];
        }
    }

    public function deleteKpi(int $id): array
    {
        $kpi = $this->kpiRepo->find($id);
        if (!$kpi) return ['success' => false, 'message' => 'KPI không tồn tại'];

        // Check if KPI is used in survey
        $used = (int)Database::getInstance()->fetchValue(
            'SELECT COUNT(*) FROM surveys WHERE kpi_id = ? AND deleted_at IS NULL',
            [$id]
        );
        if ($used > 0) {
            return ['success' => false, 'message' => 'KPI đang được sử dụng trong khảo sát, không thể xóa'];
        }

        $this->kpiRepo->softDelete($id);
        // Also soft delete criteria
        Database::getInstance()->query(
            'UPDATE criteria SET deleted_at = ?, status = 0 WHERE kpi_id = ?',
            [date('Y-m-d H:i:s'), $id]
        );

        Logger::getInstance()->audit(AUDIT_DELETE, 'kpi', Auth::id(), $id, $kpi, null, 'Xóa KPI');
        return ['success' => true, 'message' => 'Đã xóa KPI'];
    }

    public function validateTotalWeight(int $kpiId): bool
    {
        $total = $this->criteriaRepo->getTotalWeight($kpiId);
        return abs($total - 100.0) < 0.01;
    }
}