<?php
/**
 * AHPService - Analytic Hierarchy Process
 */

declare(strict_types=1);

class AHPService
{
    private Database $db;
    private array $randomIndex;

    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->randomIndex = getSetting('ahp.random_index', [
            1 => 0, 2 => 0, 3 => 0.58, 4 => 0.9, 5 => 1.12, 6 => 1.24,
            7 => 1.32, 8 => 1.41, 9 => 1.45, 10 => 1.49,
        ]);
    }

    /**
     * Calculate AHP from pairwise matrix
     * @param array $matrix n x n matrix
     * @return array weights, lambda_max, ci, cr
     */
    public function calculate(array $matrix): array
    {
        $n = count($matrix);
        if ($n < 2) {
            return ['error' => 'Cần ít nhất 2 tiêu chí'];
        }

        // 1. Sum each column
        $colSums = array_fill(0, $n, 0);
        for ($j = 0; $j < $n; $j++) {
            for ($i = 0; $i < $n; $i++) {
                $colSums[$j] += (float)$matrix[$i][$j];
            }
        }

        // 2. Normalize matrix
        $normalized = [];
        for ($i = 0; $i < $n; $i++) {
            for ($j = 0; $j < $n; $j++) {
                $normalized[$i][$j] = $colSums[$j] > 0 ? (float)$matrix[$i][$j] / $colSums[$j] : 0;
            }
        }

        // 3. Priority vector (average of each row)
        $weights = [];
        for ($i = 0; $i < $n; $i++) {
            $rowSum = array_sum($normalized[$i]);
            $weights[$i] = $rowSum / $n;
        }

        // 4. Lambda max
        $weightedSum = array_fill(0, $n, 0);
        for ($i = 0; $i < $n; $i++) {
            for ($j = 0; $j < $n; $j++) {
                $weightedSum[$i] += (float)$matrix[$i][$j] * $weights[$j];
            }
        }

        $consistencyVector = [];
        for ($i = 0; $i < $n; $i++) {
            $consistencyVector[$i] = $weights[$i] > 0 ? $weightedSum[$i] / $weights[$i] : 0;
        }
        $lambdaMax = array_sum($consistencyVector) / $n;

        // 5. CI, CR
        $ci = ($n > 1) ? ($lambdaMax - $n) / ($n - 1) : 0;
        $ri = $this->randomIndex[$n] ?? 1.59;
        $cr = $ri > 0 ? $ci / $ri : 0;
        $isConsistent = $cr <= (float)getSetting('ahp.max_consistency_ratio', 0.1);

        return [
            'weights'      => $weights,
            'lambda_max'   => $lambdaMax,
            'ci'           => $ci,
            'cr'           => $cr,
            'ri'           => $ri,
            'is_consistent'=> $isConsistent,
            'normalized'   => $normalized,
        ];
    }

    public function saveMatrix(string $name, ?int $kpiId, array $criteriaIds, array $matrix): int
    {
        return $this->db->transaction(function() use ($name, $kpiId, $criteriaIds, $matrix) {
            $result = $this->calculate($matrix);
            if (isset($result['error'])) {
                throw new RuntimeException($result['error']);
            }

            $matrixId = $this->db->insert('ahp_matrices', [
                'name'        => Security::sanitize($name),
                'kpi_id'      => $kpiId,
                'criteria_ids'=> json_encode($criteriaIds),
                'matrix_data' => json_encode($matrix),
                'created_by'  => Auth::id(),
            ]);

            // Save weights
            foreach ($criteriaIds as $i => $criterionId) {
                $this->db->insert('ahp_weights', [
                    'matrix_id'   => $matrixId,
                    'criterion_id'=> (int)$criterionId,
                    'weight'      => $result['weights'][$i] ?? 0,
                    'rank'        => 0,
                ]);
            }

            // Update ranks
            $weightsWithIdx = [];
            foreach ($result['weights'] as $i => $w) {
                $weightsWithIdx[] = ['criterion_id' => $criteriaIds[$i] ?? 0, 'weight' => $w];
            }
            usort($weightsWithIdx, fn($a, $b) => $b['weight'] <=> $a['weight']);
            foreach ($weightsWithIdx as $rank => $w) {
                $this->db->update('ahp_weights', ['rank' => $rank + 1],
                    'matrix_id = :mid AND criterion_id = :cid',
                    ['mid' => $matrixId, 'cid' => $w['criterion_id']]
                );
            }

            // Save consistency
            $this->db->insert('ahp_consistency', [
                'matrix_id'           => $matrixId,
                'lambda_max'          => $result['lambda_max'],
                'consistency_index'   => $result['ci'],
                'consistency_ratio'   => $result['cr'],
                'random_index'        => $result['ri'],
                'is_consistent'       => $result['is_consistent'] ? 1 : 0,
            ]);

            return $matrixId;
        });
    }

    public function getMatrix(int $id): ?array
    {
        $row = $this->db->fetchOne('SELECT * FROM ahp_matrices WHERE id = ?', [$id]);
        if (!$row) return null;

        $row['matrix'] = json_decode($row['matrix_data'], true);
        $row['criterion_ids'] = json_decode($row['criteria_ids'], true);
        $row['weights'] = $this->db->fetchAll(
            'SELECT aw.*, c.name AS criterion_name, c.code AS criterion_code
             FROM ahp_weights aw
             INNER JOIN criteria c ON aw.criterion_id = c.id
             WHERE aw.matrix_id = ?
             ORDER BY aw.rank',
            [$id]
        );
        $row['consistency'] = $this->db->fetchOne(
            'SELECT * FROM ahp_consistency WHERE matrix_id = ?', [$id]
        );
        return $row;
    }

    public function getSaatyScale(): array
    {
        return [
            1 => 'Quan trọng ngang nhau',
            2 => 'Trung gian',
            3 => 'Quan trọng vừa phải',
            4 => 'Trung gian',
            5 => 'Quan trọng',
            6 => 'Trung gian',
            7 => 'Quan trọng hơn nhiều',
            8 => 'Trung gian',
            9 => 'Cực kỳ quan trọng',
        ];
    }
}