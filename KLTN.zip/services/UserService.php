<?php
/**
 * UserService - Business logic for users
 */

declare(strict_types=1);

class UserService
{
    private UserRepository $userRepo;
    private RoleRepository $roleRepo;

    public function __construct()
    {
        $this->userRepo = new UserRepository();
        $this->roleRepo = new RoleRepository();
    }

    public function listUsers(int $page, int $perPage, array $filters): array
    {
        return $this->userRepo->getUsers($page, $perPage, $filters);
    }

    public function getUser(int $id): ?array
    {
        return $this->userRepo->getWithRoles($id);
    }

    public function createUser(array $data, array $roleIds): array
    {
        $validator = Validator::make($data, [
            'username'     => 'required|string|min:3|max:100|username|unique:users,username',
            'email'        => 'required|email|max:150|unique:users,email',
            'password'     => 'required|min:' . (int)getSetting('security.password_min_length', 6),
            'full_name'    => 'required|string|max:200',
            'phone'        => 'phone',
            'user_type'    => 'required|in:admin,manager,lecturer,student',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $first = reset($errors);
            return ['success' => false, 'message' => $first[0] ?? 'Dữ liệu không hợp lệ', 'errors' => $errors];
        }

        try {
            $userId = $this->userRepo->createUser([
                'username'     => Security::sanitize($data['username']),
                'email'        => Security::sanitize($data['email']),
                'password'     => password_hash($data['password'], PASSWORD_BCRYPT),
                'full_name'    => Security::sanitize($data['full_name']),
                'phone'        => Security::sanitize($data['phone'] ?? ''),
                'user_type'    => $data['user_type'],
                'student_code' => Security::sanitize($data['student_code'] ?? ''),
                'lecturer_code'=> Security::sanitize($data['lecturer_code'] ?? ''),
                'faculty_id'   => !empty($data['faculty_id']) ? (int)$data['faculty_id'] : null,
                'department_id'=> !empty($data['department_id']) ? (int)$data['department_id'] : null,
                'class_name'   => Security::sanitize($data['class_name'] ?? ''),
                'position'     => Security::sanitize($data['position'] ?? ''),
                'status'       => isset($data['status']) ? (int)$data['status'] : 1,
                'must_change_password' => 1,
            ], $roleIds);

            Logger::getInstance()->audit(AUDIT_CREATE, 'users', Auth::id(), $userId, null, $data, 'Tạo người dùng');

            return ['success' => true, 'message' => 'Đã tạo người dùng thành công', 'id' => $userId];
        } catch (Throwable $e) {
            ErrorLog::error('[UserService::createUser] failed', ['username' => $data['username'] ?? null], $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra, vui lòng thử lại'];
        }
    }

    public function updateUser(int $id, array $data, ?array $roleIds = null): array
    {
        $user = $this->userRepo->find($id);
        if (!$user) {
            return ['success' => false, 'message' => 'Người dùng không tồn tại'];
        }

        $validator = Validator::make($data, [
            'email'        => 'required|email|max:150|unique:users,email,' . $id,
            'full_name'    => 'required|string|max:200',
            'phone'        => 'phone',
            'user_type'    => 'required|in:admin,manager,lecturer,student',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $first = reset($errors);
            return ['success' => false, 'message' => $first[0] ?? 'Dữ liệu không hợp lệ', 'errors' => $errors];
        }

        // Prevent self lock/disable
        $currentUserId = Auth::id();
        if ($currentUserId === $id) {
            if (isset($data['status']) && (int)$data['status'] === 0) {
                return ['success' => false, 'message' => 'Không thể vô hiệu hóa tài khoản của chính bạn'];
            }
        }

        // Don't allow self role change
        if ($currentUserId === $id && $roleIds !== null) {
            $oldRoles = $user['role_ids'] ?? [];
            $newRoles = $roleIds;
            sort($oldRoles);
            sort($newRoles);
            if ($oldRoles !== $newRoles) {
                return ['success' => false, 'message' => 'Không thể thay đổi vai trò của chính bạn'];
            }
        }

        try {
            $updateData = [
                'email'        => Security::sanitize($data['email']),
                'full_name'    => Security::sanitize($data['full_name']),
                'phone'        => Security::sanitize($data['phone'] ?? ''),
                'user_type'    => $data['user_type'],
                'student_code' => Security::sanitize($data['student_code'] ?? ''),
                'lecturer_code'=> Security::sanitize($data['lecturer_code'] ?? ''),
                'faculty_id'   => !empty($data['faculty_id']) ? (int)$data['faculty_id'] : null,
                'department_id'=> !empty($data['department_id']) ? (int)$data['department_id'] : null,
                'class_name'   => Security::sanitize($data['class_name'] ?? ''),
                'position'     => Security::sanitize($data['position'] ?? ''),
                'status'       => isset($data['status']) ? (int)$data['status'] : 1,
            ];

            $this->userRepo->updateUser($id, $updateData, $roleIds);

            Logger::getInstance()->audit(AUDIT_UPDATE, 'users', Auth::id(), $id, $user, $data, 'Cập nhật người dùng');

            // Refresh session if user updated self
            if ($currentUserId === $id) {
                $updated = Auth::loadUserWithRoles($id);
                Session::start();
                Session::set(Auth::SESSION_KEY, $updated);
            }

            return ['success' => true, 'message' => 'Đã cập nhật thông tin'];
        } catch (Throwable $e) {
            ErrorLog::error('[UserService::updateUser] failed', ['id' => $id], $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra'];
        }
    }

    public function deleteUser(int $id): array
    {
        $user = $this->userRepo->find($id);
        if (!$user) {
            return ['success' => false, 'message' => 'Người dùng không tồn tại'];
        }

        if (Auth::id() === $id) {
            return ['success' => false, 'message' => 'Không thể xóa tài khoản của chính bạn'];
        }

        // Prevent deleting last admin
        if ($user['user_type'] === 'admin') {
            $adminCount = (int)Database::getInstance()->fetchValue(
                "SELECT COUNT(*) FROM users WHERE user_type = 'admin' AND status = 1 AND deleted_at IS NULL"
            );
            if ($adminCount <= 1) {
                return ['success' => false, 'message' => 'Không thể xóa admin cuối cùng'];
            }
        }

        $this->userRepo->softDelete($id);
        Logger::getInstance()->audit(AUDIT_DELETE, 'users', Auth::id(), $id, $user, null, 'Xóa người dùng');

        return ['success' => true, 'message' => 'Đã xóa người dùng'];
    }

    public function lockUser(int $id): array
    {
        $user = $this->userRepo->find($id);
        if (!$user) return ['success' => false, 'message' => 'Người dùng không tồn tại'];
        if (Auth::id() === $id) return ['success' => false, 'message' => 'Không thể khóa chính bạn'];

        $this->userRepo->lock($id);
        Logger::getInstance()->audit(AUDIT_LOCK, 'users', Auth::id(), $id, $user, null, 'Khóa tài khoản');

        return ['success' => true, 'message' => 'Đã khóa tài khoản'];
    }

    public function unlockUser(int $id): array
    {
        $user = $this->userRepo->find($id);
        if (!$user) return ['success' => false, 'message' => 'Người dùng không tồn tại'];

        $this->userRepo->unlock($id);
        Logger::getInstance()->audit(AUDIT_UNLOCK, 'users', Auth::id(), $id, $user, null, 'Mở khóa tài khoản');

        return ['success' => true, 'message' => 'Đã mở khóa tài khoản'];
    }
}