<?php
/**
 * StatisticsService
 */

declare(strict_types=1);

class StatisticsService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function mean(array $values): float
    {
        if (empty($values)) return 0.0;
        return array_sum($values) / count($values);
    }

    public function median(array $values): float
    {
        if (empty($values)) return 0.0;
        $values = array_map('floatval', $values);
        sort($values);
        $n = count($values);
        $mid = (int)floor($n / 2);
        return ($n % 2 === 0) ? (float)(($values[$mid - 1] + $values[$mid]) / 2) : (float)$values[$mid];
    }

    public function stdDev(array $values): float
    {
        if (count($values) < 2) return 0.0;
        $mean = $this->mean($values);
        $variance = 0.0;
        foreach ($values as $v) {
            $variance += ($v - $mean) ** 2;
        }
        return sqrt($variance / (count($values) - 1));
    }

    public function min(array $values): float
    {
        if (empty($values)) return 0.0;
        return (float)min($values);
    }

    public function max(array $values): float
    {
        if (empty($values)) return 0.0;
        return (float)max($values);
    }

    public function distribution(array $values, int $buckets = 5): array
    {
        if (empty($values)) return [];

        $min = $this->min($values);
        $max = $this->max($values);
        if ($min === $max) {
            return [$min => count($values)];
        }

        $range = $max - $min;
        $step = $range / $buckets;
        $dist = [];
        for ($i = 0; $i < $buckets; $i++) {
            $low = $min + $i * $step;
            $high = $min + ($i + 1) * $step;
            if ($i === $buckets - 1) $high += 0.01;
            $key = round($low, 2) . ' - ' . round($high, 2);
            $dist[$key] = 0;
        }
        foreach ($values as $v) {
            for ($i = 0; $i < $buckets; $i++) {
                $low = $min + $i * $step;
                $high = $min + ($i + 1) * $step;
                if ($v >= $low && $v < $high) {
                    $key = round($low, 2) . ' - ' . round($high, 2);
                    if ($i === $buckets - 1) {
                        $key = round($low, 2) . ' - ' . round($high - 0.01, 2);
                    }
                    $dist[$key]++;
                    break;
                }
                if ($i === $buckets - 1 && $v == $high) {
                    $key = round($low, 2) . ' - ' . round($high - 0.01, 2);
                    $dist[$key]++;
                }
            }
        }
        return $dist;
    }

    /**
     * Get survey statistics
     */
    public function getSurveyStatistics(int $surveyId): array
    {
        $survey = $this->db->fetchOne('SELECT * FROM surveys WHERE id = ?', [$surveyId]);
        if (!$survey) return [];

        $questions = $this->db->fetchAll(
            'SELECT * FROM survey_questions WHERE survey_id = ? ORDER BY sort_order, id',
            [$surveyId]
        );

        $result = [
            'survey' => $survey,
            'response_count' => (int)$this->db->fetchValue(
                "SELECT COUNT(*) FROM survey_responses WHERE survey_id = ? AND status = 'submitted'",
                [$surveyId]
            ),
            'questions' => [],
        ];

        foreach ($questions as $q) {
            $answers = $this->db->fetchAll(
                'SELECT sa.* FROM survey_answers sa
                 INNER JOIN survey_responses sr ON sa.response_id = sr.id
                 WHERE sa.question_id = ? AND sr.status = "submitted" AND sa.score IS NOT NULL',
                [$q['id']]
            );

            $scores = array_column($answers, 'score');

            $stat = [
                'question'    => $q,
                'count'       => count($scores),
                'mean'        => $this->mean($scores),
                'median'      => $this->median($scores),
                'min'         => $this->min($scores),
                'max'         => $this->max($scores),
                'std_dev'     => $this->stdDev($scores),
                'distribution'=> $this->distribution($scores, 5),
            ];

            $result['questions'][] = $stat;
        }

        return $result;
    }

    /**
     * Trend over time
     */
    public function getTrend(int $kpiId, string $interval = 'month'): array
    {
        $dateFormat = match($interval) {
            'day'     => '%Y-%m-%d',
            'week'    => '%Y-%u',
            'month'   => '%Y-%m',
            'quarter' => '%Y-Q%q',
            default   => '%Y-%m',
        };

        $sql = "SELECT DATE_FORMAT(e.calculated_at, '{$dateFormat}') AS period,
                       AVG(e.normalized_score) AS avg_score,
                       COUNT(*) AS eval_count
                FROM evaluations e
                WHERE e.kpi_id = ? AND e.normalized_score IS NOT NULL
                GROUP BY period
                ORDER BY period ASC";

        $rows = $this->db->fetchAll($sql, [$kpiId]);
        return $rows;
    }

    public function getCompletionRate(int $surveyId): float
    {
        $total = (int)$this->db->fetchValue("SELECT COUNT(*) FROM survey_responses WHERE survey_id = ?", [$surveyId]);
        $completed = (int)$this->db->fetchValue("SELECT COUNT(*) FROM survey_responses WHERE survey_id = ? AND status = 'submitted'", [$surveyId]);
        return $total > 0 ? round(($completed / $total) * 100, 2) : 0.0;
    }
}