<?php
/**
 * RankingService
 */

declare(strict_types=1);

class RankingService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Get ranking by KPI
     */
    public function getRankingByKpi(string $period = null, int $limit = 20): array
    {
        $where = 'e.normalized_score IS NOT NULL';
        $params = [];
        if ($period) {
            $where .= ' AND e.period = ?';
            $params[] = $period;
        }

        $rows = $this->db->fetchAll(
            "SELECT e.kpi_id, k.name AS kpi_name,
                    AVG(e.normalized_score) AS avg_score,
                    COUNT(*) AS eval_count
             FROM evaluations e
             INNER JOIN kpis k ON e.kpi_id = k.id
             WHERE {$where}
             GROUP BY e.kpi_id, k.name
             ORDER BY avg_score DESC
             LIMIT ?",
            array_merge($params, [$limit])
        );

        $rank = 1;
        foreach ($rows as &$r) {
            $r['rank'] = $rank++;
            $r['avg_score'] = round((float)$r['avg_score'], 2);
        }
        return $rows;
    }

    /**
     * Get ranking by criterion
     */
    public function getRankingByCriterion(int $kpiId, int $limit = 20): array
    {
        $rows = $this->db->fetchAll(
            "SELECT c.id, c.name, c.code, c.weight,
                    AVG(es.normalized_score) AS avg_score
             FROM criteria c
             LEFT JOIN evaluation_scores es ON c.id = es.criterion_id
             LEFT JOIN evaluations e ON es.evaluation_id = e.id
             WHERE c.kpi_id = ? AND c.deleted_at IS NULL
             GROUP BY c.id, c.name, c.code, c.weight
             ORDER BY avg_score DESC
             LIMIT ?",
            [$kpiId, $limit]
        );

        $rank = 1;
        foreach ($rows as &$r) {
            $r['rank'] = $rank++;
            $r['avg_score'] = round((float)($r['avg_score'] ?? 0), 2);
        }
        return $rows;
    }

    public function getOverallRanking(int $limit = 20, string $period = null): array
    {
        $where = '1=1';
        $params = [];
        if ($period) {
            $where .= ' AND e.period = ?';
            $params[] = $period;
        }

        $rows = $this->db->fetchAll(
            "SELECT e.id, e.name, e.target_type, e.target_id, e.normalized_score, e.classification,
                    k.name AS kpi_name
             FROM evaluations e
             LEFT JOIN kpis k ON e.kpi_id = k.id
             WHERE {$where} AND e.normalized_score IS NOT NULL
             ORDER BY e.normalized_score DESC
             LIMIT ?",
            array_merge($params, [$limit])
        );

        $rank = 1;
        foreach ($rows as &$r) {
            $r['rank'] = $rank++;
            $r['normalized_score'] = round((float)$r['normalized_score'], 2);
        }
        return $rows;
    }
}