<?php
/**
 * ReportService
 */

declare(strict_types=1);

class ReportService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function exportToCSV(array $data, array $headers, string $filename): string
    {
        $dir = STORAGE_PATH . '/exports';
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        $filepath = $dir . '/' . $filename;
        $file = fopen($filepath, 'w');

        // BOM for UTF-8
        fwrite($file, "\xEF\xBB\xBF");
        fputcsv($file, $headers);

        foreach ($data as $row) {
            $line = [];
            foreach ($headers as $h) {
                $line[] = $row[$h] ?? '';
            }
            fputcsv($file, $line);
        }

        fclose($file);
        return $filepath;
    }

    public function exportToExcel(array $data, array $headers, string $filename): string
    {
        // Excel-compatible HTML
        $dir = STORAGE_PATH . '/exports';
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        $filepath = $dir . '/' . $filename;

        $html = '<html><head><meta charset="UTF-8"></head><body>';
        $html .= '<table border="1"><thead><tr>';
        foreach ($headers as $h) {
            $html .= '<th>' . htmlspecialchars($h) . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        foreach ($data as $row) {
            $html .= '<tr>';
            foreach ($headers as $h) {
                $html .= '<td>' . htmlspecialchars($row[$h] ?? '') . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table></body></html>';

        file_put_contents($filepath, $html);
        return $filepath;
    }

    public function exportToPDF(array $data, array $headers, string $title, string $filename): string
    {
        // Simple HTML-based PDF (no external lib required)
        $dir = STORAGE_PATH . '/exports';
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        $filepath = $dir . '/' . $filename;

        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($title) . '</title>';
        $html .= '<style>body{font-family:Arial;font-size:12px;}table{width:100%;border-collapse:collapse;}th,td{border:1px solid #ddd;padding:6px;text-align:left;}th{background:#f3f4f6;font-weight:600;}h1{font-size:18px;}</style>';
        $html .= '</head><body>';
        $html .= '<h1>' . htmlspecialchars($title) . '</h1>';
        $html .= '<p>Ngày xuất: ' . date('d/m/Y H:i') . '</p>';
        $html .= '<table><thead><tr>';
        foreach ($headers as $h) {
            $html .= '<th>' . htmlspecialchars($h) . '</th>';
        }
        $html .= '</tr></thead><tbody>';
        foreach ($data as $row) {
            $html .= '<tr>';
            foreach ($headers as $h) {
                $html .= '<td>' . htmlspecialchars($row[$h] ?? '') . '</td>';
            }
            $html .= '</tr>';
        }
        $html .= '</tbody></table></body></html>';

        file_put_contents($filepath, $html);
        return $filepath;
    }

    public function getReportData(string $type, array $params = []): array
    {
        switch ($type) {
            case 'survey_results':
                return $this->getSurveyResultsData($params);
            case 'evaluations':
                return $this->getEvaluationsData($params);
            case 'rankings':
                return $this->getRankingsData($params);
            case 'users':
                return $this->getUsersData($params);
            default:
                return [];
        }
    }

    private function getSurveyResultsData(array $params): array
    {
        $surveyId = (int)($params['survey_id'] ?? 0);
        if (!$surveyId) return [];

        $rows = $this->db->fetchAll(
            "SELECT sr.id, sr.submitted_at, u.full_name AS respondent,
                    COUNT(sa.id) AS answer_count
             FROM survey_responses sr
             LEFT JOIN users u ON sr.respondent_id = u.id
             LEFT JOIN survey_answers sa ON sr.id = sa.response_id
             WHERE sr.survey_id = ? AND sr.status = 'submitted'
             GROUP BY sr.id, sr.submitted_at, u.full_name
             ORDER BY sr.submitted_at DESC",
            [$surveyId]
        );

        return $rows;
    }

    private function getEvaluationsData(array $params): array
    {
        $where = '1=1';
        $sqlParams = [];
        if (!empty($params['kpi_id'])) {
            $where .= ' AND e.kpi_id = ?';
            $sqlParams[] = (int)$params['kpi_id'];
        }
        if (!empty($params['period'])) {
            $where .= ' AND e.period = ?';
            $sqlParams[] = $params['period'];
        }

        return $this->db->fetchAll(
            "SELECT e.id, e.name, e.period, e.target_type, e.total_score, e.normalized_score, e.classification,
                    e.calculated_at, k.name AS kpi_name
             FROM evaluations e
             LEFT JOIN kpis k ON e.kpi_id = k.id
             WHERE {$where}
             ORDER BY e.calculated_at DESC",
            $sqlParams
        );
    }

    private function getRankingsData(array $params): array
    {
        $rows = $this->db->fetchAll(
            "SELECT e.id, e.name, e.target_type, e.normalized_score, e.classification,
                    k.name AS kpi_name
             FROM evaluations e
             LEFT JOIN kpis k ON e.kpi_id = k.id
             WHERE e.normalized_score IS NOT NULL
             ORDER BY e.normalized_score DESC
             LIMIT 50"
        );
        $rank = 1;
        foreach ($rows as &$r) {
            $r['rank'] = $rank++;
        }
        return $rows;
    }

    private function getUsersData(array $params): array
    {
        return $this->db->fetchAll(
            "SELECT u.username, u.email, u.full_name, u.user_type, u.phone, u.status, u.created_at
             FROM users u
             WHERE u.deleted_at IS NULL
             ORDER BY u.created_at DESC"
        );
    }

    public function getReportHeaders(string $type): array
    {
        switch ($type) {
            case 'survey_results':
                return ['id' => 'Mã', 'respondent' => 'Người trả lời', 'answer_count' => 'Số câu trả lời', 'submitted_at' => 'Thời gian'];
            case 'evaluations':
                return ['id' => 'Mã', 'name' => 'Tên', 'kpi_name' => 'KPI', 'period' => 'Kỳ', 'normalized_score' => 'Điểm', 'classification' => 'Xếp loại', 'calculated_at' => 'Ngày tính'];
            case 'rankings':
                return ['rank' => 'Hạng', 'name' => 'Tên', 'kpi_name' => 'KPI', 'normalized_score' => 'Điểm', 'classification' => 'Xếp loại'];
            case 'users':
                return ['username' => 'Username', 'email' => 'Email', 'full_name' => 'Họ tên', 'user_type' => 'Loại', 'phone' => 'SĐT', 'status' => 'Trạng thái', 'created_at' => 'Ngày tạo'];
            default:
                return [];
        }
    }

    public function recordExport(int $userId, string $type, string $format, string $filePath): int
    {
        return $this->db->insert('report_exports', [
            'name'         => $type . '_' . date('Ymd_His'),
            'report_type'  => $type,
            'format'       => $format,
            'file_path'    => $filePath,
            'file_size'    => file_exists($filePath) ? filesize($filePath) : 0,
            'requested_by' => $userId,
            'status'       => 'completed',
            'completed_at' => date('Y-m-d H:i:s'),
            'expires_at'   => date('Y-m-d H:i:s', time() + 7 * 24 * 3600),
        ]);
    }

    public function listExports(int $userId, int $limit = 50): array
    {
        return $this->db->fetchAll(
            'SELECT * FROM report_exports WHERE requested_by = ? ORDER BY created_at DESC LIMIT ?',
            [$userId, $limit]
        );
    }
}