<?php
/**
 * CriterionService
 */

declare(strict_types=1);

class CriterionService
{
    private CriterionRepository $repo;
    private KpiRepository $kpiRepo;

    public function __construct()
    {
        $this->repo = new CriterionRepository();
        $this->kpiRepo = new KpiRepository();
    }

    public function list(int $page, int $perPage, array $filters): array
    {
        $db = Database::getInstance();
        $where = ['c.deleted_at IS NULL'];
        $params = [];

        if (!empty($filters['search'])) {
            $where[] = '(c.code LIKE ? OR c.name LIKE ?)';
            $term = '%' . $filters['search'] . '%';
            $params[] = $term;
            $params[] = $term;
        }
        if (!empty($filters['kpi_id'])) {
            $where[] = 'c.kpi_id = ?';
            $params[] = (int)$filters['kpi_id'];
        }
        if (!empty($filters['category_id'])) {
            $where[] = 'c.category_id = ?';
            $params[] = (int)$filters['category_id'];
        }

        $whereSql = implode(' AND ', $where);
        $total = (int)$db->fetchValue("SELECT COUNT(*) FROM criteria c WHERE {$whereSql}", $params);
        $offset = ($page - 1) * $perPage;

        $items = $db->fetchAll(
            "SELECT c.*, k.name AS kpi_name, kg.name AS group_name, cc.name AS category_name
             FROM criteria c
             INNER JOIN kpis k ON c.kpi_id = k.id
             INNER JOIN kpi_groups kg ON k.kpi_group_id = kg.id
             LEFT JOIN criterion_categories cc ON c.category_id = cc.id
             WHERE {$whereSql}
             ORDER BY c.kpi_id, c.sort_order, c.id
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return [
            'items' => $items,
            'total' => $total,
            'pagination' => paginate($total, $page, $perPage),
        ];
    }

    public function create(array $data): array
    {
        $validator = Validator::make($data, [
            'kpi_id' => 'required|integer',
            'code'   => 'required|string|max:50|unique:criteria,code',
            'name'   => 'required|string|max:200',
            'weight' => 'required|numeric|between:0,100',
            'min_score' => 'required|numeric',
            'max_score' => 'required|numeric',
        ]);

        if ($validator->fails()) {
            $errors = $validator->errors();
            $first = reset($errors);
            return ['success' => false, 'message' => $first[0] ?? 'Dữ liệu không hợp lệ', 'errors' => $errors];
        }

        if ((float)$data['max_score'] <= (float)$data['min_score']) {
            return ['success' => false, 'message' => 'Điểm tối đa phải lớn hơn điểm tối thiểu'];
        }

        try {
            $id = $this->repo->create([
                'kpi_id'         => (int)$data['kpi_id'],
                'category_id'    => !empty($data['category_id']) ? (int)$data['category_id'] : null,
                'code'           => Security::sanitize($data['code']),
                'name'           => Security::sanitize($data['name']),
                'description'    => Security::sanitize($data['description'] ?? ''),
                'evaluation_type'=> $data['evaluation_type'] ?? 'score',
                'weight'         => (float)$data['weight'],
                'min_score'      => (float)$data['min_score'],
                'max_score'      => (float)$data['max_score'],
                'score_step'     => (float)($data['score_step'] ?? 1),
                'sort_order'     => (int)($data['sort_order'] ?? 0),
                'status'         => 1,
            ]);

            Logger::getInstance()->audit(AUDIT_CREATE, 'criteria', Auth::id(), $id, null, $data, 'Tạo tiêu chí');
            return ['success' => true, 'message' => 'Đã tạo tiêu chí', 'id' => $id];
        } catch (Throwable $e) {
            ErrorLog::error('[CriterionService::create] failed', $data, $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra'];
        }
    }

    public function update(int $id, array $data): array
    {
        $criterion = $this->repo->find($id);
        if (!$criterion) return ['success' => false, 'message' => 'Tiêu chí không tồn tại'];

        if ((float)$data['max_score'] <= (float)$data['min_score']) {
            return ['success' => false, 'message' => 'Điểm tối đa phải lớn hơn điểm tối thiểu'];
        }

        try {
            $this->repo->update($id, [
                'kpi_id'         => (int)$data['kpi_id'],
                'category_id'    => !empty($data['category_id']) ? (int)$data['category_id'] : null,
                'name'           => Security::sanitize($data['name']),
                'description'    => Security::sanitize($data['description'] ?? ''),
                'evaluation_type'=> $data['evaluation_type'] ?? 'score',
                'weight'         => (float)$data['weight'],
                'min_score'      => (float)$data['min_score'],
                'max_score'      => (float)$data['max_score'],
                'score_step'     => (float)($data['score_step'] ?? 1),
                'sort_order'     => (int)($data['sort_order'] ?? 0),
                'status'         => (int)($data['status'] ?? 1),
            ]);

            Logger::getInstance()->audit(AUDIT_UPDATE, 'criteria', Auth::id(), $id, $criterion, $data, 'Cập nhật tiêu chí');
            return ['success' => true, 'message' => 'Đã cập nhật tiêu chí'];
        } catch (Throwable $e) {
            ErrorLog::error('[CriterionService::update] failed', ['id' => $id], $e);
            return ['success' => false, 'message' => 'Có lỗi xảy ra'];
        }
    }

    public function delete(int $id): array
    {
        $criterion = $this->repo->find($id);
        if (!$criterion) return ['success' => false, 'message' => 'Tiêu chí không tồn tại'];

        // Check if used in survey question
        $used = (int)Database::getInstance()->fetchValue(
            'SELECT COUNT(*) FROM survey_questions WHERE criterion_id = ?',
            [$id]
        );
        if ($used > 0) {
            return ['success' => false, 'message' => 'Tiêu chí đang được sử dụng trong khảo sát, không thể xóa'];
        }

        $this->repo->softDelete($id);
        Logger::getInstance()->audit(AUDIT_DELETE, 'criteria', Auth::id(), $id, $criterion, null, 'Xóa tiêu chí');
        return ['success' => true, 'message' => 'Đã xóa tiêu chí'];
    }

    public function getByKpi(int $kpiId): array
    {
        return $this->repo->getByKpi($kpiId);
    }
}