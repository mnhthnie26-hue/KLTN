<?php
/**
 * EvaluationService
 */

declare(strict_types=1);

class EvaluationService
{
    private Database $db;
    private array $classificationThresholds;

    public function __construct()
    {
        $this->db = Database::getInstance();
        $this->classificationThresholds = getSetting('score.classification_thresholds', [
            'excellent' => 90,
            'good'      => 80,
            'fair'      => 65,
            'average'   => 50,
            'poor'      => 0,
        ]);
    }

    public function classify(float $score): string
    {
        $t = $this->classificationThresholds;
        if ($score >= ($t['excellent'] ?? 90)) return CLASSIFICATION_EXCELLENT;
        if ($score >= ($t['good'] ?? 80)) return CLASSIFICATION_GOOD;
        if ($score >= ($t['fair'] ?? 65)) return CLASSIFICATION_FAIR;
        if ($score >= ($t['average'] ?? 50)) return CLASSIFICATION_AVERAGE;
        return CLASSIFICATION_POOR;
    }

    public function calculateForSurvey(int $surveyId, string $period = null, string $targetType = 'overall', ?int $targetId = null): ?array
    {
        $survey = $this->db->fetchOne('SELECT * FROM surveys WHERE id = ? AND deleted_at IS NULL', [$surveyId]);
        if (!$survey) return null;

        $kpiId = $survey['kpi_id'];
        if (!$kpiId) return null;

        $criteria = (new CriterionRepository())->getByKpi($kpiId);
        if (empty($criteria)) return null;

        $evalId = $this->db->transaction(function() use ($survey, $kpiId, $criteria, $period, $targetType, $targetId) {
            // Get all submitted responses
            $responseIds = $this->db->fetchAll(
                "SELECT id FROM survey_responses WHERE survey_id = ? AND status = 'submitted'",
                [$survey['id']]
            );

            $responseCount = count($responseIds);

            $evaluationId = $this->db->insert('evaluations', [
                'name'                => 'Đánh giá từ ' . $survey['title'],
                'survey_id'           => $survey['id'],
                'kpi_id'              => $kpiId,
                'period'              => $period,
                'target_type'         => $targetType,
                'target_id'           => $targetId,
                'calculation_method'  => 'weighted',
                'calculated_at'       => date('Y-m-d H:i:s'),
                'status'              => 'calculated',
                'created_by'          => Auth::id(),
            ]);

            $totalNormalized = 0;

            foreach ($criteria as $c) {
                // Get average score for this criterion across all responses
                $avgRaw = $this->db->fetchValue(
                    "SELECT AVG(sa.score) FROM survey_answers sa
                     INNER JOIN survey_questions sq ON sa.question_id = sq.id
                     WHERE sq.criterion_id = ? AND sa.response_id IN (
                        SELECT id FROM survey_responses WHERE survey_id = ? AND status = 'submitted'
                     ) AND sa.score IS NOT NULL",
                    [$c['id'], $survey['id']]
                );

                $rawScore = (float)($avgRaw ?? 0);
                $normalized = $this->normalize($rawScore, (float)$c['min_score'], (float)$c['max_score']);
                $weighted = $normalized * ((float)$c['weight'] / 100);

                $this->db->insert('evaluation_scores', [
                    'evaluation_id'    => $evaluationId,
                    'criterion_id'     => $c['id'],
                    'raw_score'        => $rawScore,
                    'normalized_score' => $normalized,
                    'weight'           => (float)$c['weight'],
                    'weighted_score'   => $weighted,
                    'response_count'   => $responseCount,
                ]);

                $totalNormalized += $weighted;
            }

            $classification = $this->classify($totalNormalized);

            $this->db->update('evaluations', [
                'total_score'      => $totalNormalized,
                'normalized_score' => $totalNormalized,
                'classification'   => $classification,
            ], 'id = :id', ['id' => $evaluationId]);

            Logger::getInstance()->audit(AUDIT_CREATE, 'evaluation', Auth::id(), $evaluationId, null, [
                'survey_id' => $survey['id'],
                'kpi_id'    => $kpiId,
                'score'     => $totalNormalized,
            ], 'Tính điểm đánh giá');

            return $evaluationId;
        });

        return $this->get($evalId);
    }

    public function get(int $id): ?array
    {
        $evaluation = $this->db->fetchOne(
            'SELECT e.*, k.name AS kpi_name, s.title AS survey_title
             FROM evaluations e
             LEFT JOIN kpis k ON e.kpi_id = k.id
             LEFT JOIN surveys s ON e.survey_id = s.id
             WHERE e.id = ?',
            [$id]
        );
        if (!$evaluation) return null;

        $evaluation['scores'] = $this->db->fetchAll(
            'SELECT es.*, c.name AS criterion_name, c.code AS criterion_code
             FROM evaluation_scores es
             INNER JOIN criteria c ON es.criterion_id = c.id
             WHERE es.evaluation_id = ?
             ORDER BY c.sort_order, c.id',
            [$id]
        );

        return $evaluation;
    }

    public function list(int $page, int $perPage, array $filters = []): array
    {
        $where = ['1=1'];
        $params = [];

        if (!empty($filters['kpi_id'])) {
            $where[] = 'e.kpi_id = ?';
            $params[] = (int)$filters['kpi_id'];
        }
        if (!empty($filters['period'])) {
            $where[] = 'e.period = ?';
            $params[] = $filters['period'];
        }

        $whereSql = implode(' AND ', $where);
        $total = (int)$this->db->fetchValue("SELECT COUNT(*) FROM evaluations e WHERE {$whereSql}", $params);
        $offset = ($page - 1) * $perPage;

        $items = $this->db->fetchAll(
            "SELECT e.*, k.name AS kpi_name, s.title AS survey_title
             FROM evaluations e
             LEFT JOIN kpis k ON e.kpi_id = k.id
             LEFT JOIN surveys s ON e.survey_id = s.id
             WHERE {$whereSql}
             ORDER BY e.created_at DESC
             LIMIT {$perPage} OFFSET {$offset}",
            $params
        );

        return [
            'items' => $items,
            'total' => $total,
            'pagination' => paginate($total, $page, $perPage),
        ];
    }

    public function normalize(float $raw, float $min, float $max): float
    {
        if ($max <= $min) return 0.0;
        $normalized = (($raw - $min) / ($max - $min)) * 100;
        return max(0, min(100, $normalized));
    }

    public function getStats(): array
    {
        return [
            'total'    => (int)$this->db->fetchValue('SELECT COUNT(*) FROM evaluations'),
            'calculated' => (int)$this->db->fetchValue("SELECT COUNT(*) FROM evaluations WHERE status = 'calculated'"),
            'avg_score' => (float)($this->db->fetchValue("SELECT AVG(normalized_score) FROM evaluations WHERE normalized_score IS NOT NULL") ?? 0),
        ];
    }
}