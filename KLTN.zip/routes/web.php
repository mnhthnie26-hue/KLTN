<?php
/**
 * Web Routes
 *
 * All web routes are defined here.
 * Routes use middleware classes for authentication and authorization.
 */

declare(strict_types=1);

// ============================================================
// Public Routes (no auth required)
// ============================================================

$router->get('/', function ($params, $request, $response) {
    if (Auth::check()) {
        $response->redirect(url('dashboard'))->send();
        return;
    }
    $response->redirect(url('login'))->send();
});

// ============================================================
// Authentication Routes
// ============================================================

$router->get('/login', 'AuthController@showLogin');
$router->post('/login', 'AuthController@login', [
    new RateLimitMiddleware('login', 5, 60),
]);
$router->get('/logout', 'AuthController@logout');
$router->post('/logout', 'AuthController@logout');

// ============================================================
// Authenticated Routes
// ============================================================

$router->get('/change-password', 'AuthController@showChangePassword', [AuthMiddleware::class]);
$router->post('/change-password', 'AuthController@changePassword', [AuthMiddleware::class]);

// ============================================================
// Dashboard
// ============================================================

$router->get('/dashboard', 'DashboardController@index', [AuthMiddleware::class]);

// ============================================================
// Users Management
// ============================================================

$router->get('/users', 'UserController@index', [AuthMiddleware::class, new PermissionMiddleware('users.view')]);
$router->get('/users/create', 'UserController@create', [AuthMiddleware::class, new PermissionMiddleware('users.create')]);
$router->post('/users', 'UserController@store', [AuthMiddleware::class, new PermissionMiddleware('users.create')]);
$router->get('/users/{id}', 'UserController@show', [AuthMiddleware::class, new PermissionMiddleware('users.view')]);
$router->get('/users/{id}/edit', 'UserController@edit', [AuthMiddleware::class, new PermissionMiddleware('users.update')]);
$router->post('/users/{id}', 'UserController@update', [AuthMiddleware::class, new PermissionMiddleware('users.update')]);
$router->post('/users/{id}/delete', 'UserController@destroy', [AuthMiddleware::class, new PermissionMiddleware('users.delete')]);
$router->post('/users/{id}/reset-password', 'UserController@resetPassword', [AuthMiddleware::class, new PermissionMiddleware('users.reset_password')]);
$router->post('/users/{id}/lock', 'UserController@lock', [AuthMiddleware::class, new PermissionMiddleware('users.lock')]);
$router->post('/users/{id}/unlock', 'UserController@unlock', [AuthMiddleware::class, new PermissionMiddleware('users.lock')]);

// ============================================================
// Roles & Permissions
// ============================================================

$router->get('/roles', 'RoleController@index', [AuthMiddleware::class, new PermissionMiddleware('roles.view')]);
$router->get('/roles/create', 'RoleController@create', [AuthMiddleware::class, new PermissionMiddleware('roles.create')]);
$router->post('/roles', 'RoleController@store', [AuthMiddleware::class, new PermissionMiddleware('roles.create')]);
$router->get('/roles/{id}/edit', 'RoleController@edit', [AuthMiddleware::class, new PermissionMiddleware('roles.update')]);
$router->post('/roles/{id}', 'RoleController@update', [AuthMiddleware::class, new PermissionMiddleware('roles.update')]);
$router->post('/roles/{id}/delete', 'RoleController@destroy', [AuthMiddleware::class, new PermissionMiddleware('roles.delete')]);
$router->get('/permissions', 'RoleController@permissions', [AuthMiddleware::class, new PermissionMiddleware('permissions.assign')]);

// ============================================================
// KPI Groups
// ============================================================

$router->get('/kpi-groups', 'KpiGroupController@index', [AuthMiddleware::class, new PermissionMiddleware('kpi_group.view')]);
$router->get('/kpi-groups/create', 'KpiGroupController@create', [AuthMiddleware::class, new PermissionMiddleware('kpi_group.create')]);
$router->post('/kpi-groups', 'KpiGroupController@store', [AuthMiddleware::class, new PermissionMiddleware('kpi_group.create')]);
$router->get('/kpi-groups/{id}/edit', 'KpiGroupController@edit', [AuthMiddleware::class, new PermissionMiddleware('kpi_group.update')]);
$router->post('/kpi-groups/{id}', 'KpiGroupController@update', [AuthMiddleware::class, new PermissionMiddleware('kpi_group.update')]);
$router->post('/kpi-groups/{id}/delete', 'KpiGroupController@destroy', [AuthMiddleware::class, new PermissionMiddleware('kpi_group.delete')]);

// ============================================================
// KPIs
// ============================================================

$router->get('/kpis', 'KpiController@index', [AuthMiddleware::class, new PermissionMiddleware('kpi.view')]);
$router->get('/kpis/create', 'KpiController@create', [AuthMiddleware::class, new PermissionMiddleware('kpi.create')]);
$router->post('/kpis', 'KpiController@store', [AuthMiddleware::class, new PermissionMiddleware('kpi.create')]);
$router->get('/kpis/{id}', 'KpiController@show', [AuthMiddleware::class, new PermissionMiddleware('kpi.view')]);
$router->get('/kpis/{id}/edit', 'KpiController@edit', [AuthMiddleware::class, new PermissionMiddleware('kpi.update')]);
$router->post('/kpis/{id}', 'KpiController@update', [AuthMiddleware::class, new PermissionMiddleware('kpi.update')]);
$router->post('/kpis/{id}/delete', 'KpiController@destroy', [AuthMiddleware::class, new PermissionMiddleware('kpi.delete')]);

// ============================================================
// Criteria
// ============================================================

$router->get('/criteria', 'CriterionController@index', [AuthMiddleware::class, new PermissionMiddleware('criteria.view')]);
$router->get('/criteria/create', 'CriterionController@create', [AuthMiddleware::class, new PermissionMiddleware('criteria.create')]);
$router->post('/criteria', 'CriterionController@store', [AuthMiddleware::class, new PermissionMiddleware('criteria.create')]);
$router->get('/criteria/{id}/edit', 'CriterionController@edit', [AuthMiddleware::class, new PermissionMiddleware('criteria.update')]);
$router->post('/criteria/{id}', 'CriterionController@update', [AuthMiddleware::class, new PermissionMiddleware('criteria.update')]);
$router->post('/criteria/{id}/delete', 'CriterionController@destroy', [AuthMiddleware::class, new PermissionMiddleware('criteria.delete')]);

// ============================================================
// Surveys
// ============================================================

$router->get('/surveys', 'SurveyController@index', [AuthMiddleware::class, new PermissionMiddleware('survey.view')]);
$router->get('/surveys/create', 'SurveyController@create', [AuthMiddleware::class, new PermissionMiddleware('survey.create')]);
$router->post('/surveys', 'SurveyController@store', [AuthMiddleware::class, new PermissionMiddleware('survey.create')]);
$router->get('/surveys/{id}', 'SurveyController@show', [AuthMiddleware::class, new PermissionMiddleware('survey.view')]);
$router->get('/surveys/{id}/edit', 'SurveyController@edit', [AuthMiddleware::class, new PermissionMiddleware('survey.update')]);
$router->post('/surveys/{id}', 'SurveyController@update', [AuthMiddleware::class, new PermissionMiddleware('survey.update')]);
$router->post('/surveys/{id}/delete', 'SurveyController@destroy', [AuthMiddleware::class, new PermissionMiddleware('survey.delete')]);
$router->post('/surveys/{id}/publish', 'SurveyController@publish', [AuthMiddleware::class, new PermissionMiddleware('survey.publish')]);
$router->post('/surveys/{id}/close', 'SurveyController@close', [AuthMiddleware::class, new PermissionMiddleware('survey.update')]);
$router->get('/surveys/{id}/preview', 'SurveyController@preview', [AuthMiddleware::class, new PermissionMiddleware('survey.view')]);
$router->post('/surveys/{id}/duplicate', 'SurveyController@duplicate', [AuthMiddleware::class, new PermissionMiddleware('survey.create')]);
$router->get('/surveys/{id}/questions', 'SurveyController@questions', [AuthMiddleware::class, new PermissionMiddleware('survey.update')]);
$router->post('/surveys/{id}/questions', 'SurveyController@saveQuestions', [AuthMiddleware::class, new PermissionMiddleware('survey.update')]);
$router->get('/surveys/{id}/results', 'SurveyController@results', [AuthMiddleware::class, new PermissionMiddleware('survey.view_result')]);

// Survey submission (public-ish)
$router->get('/survey/{id}/take', 'SurveyController@take', [AuthMiddleware::class]);
$router->post('/survey/{id}/submit', 'SurveyController@submitResponse', [AuthMiddleware::class, new RateLimitMiddleware('survey_submit', 5, 60)]);

// ============================================================
// Evaluations
// ============================================================

$router->get('/evaluations', 'EvaluationController@index', [AuthMiddleware::class, new PermissionMiddleware('evaluation.view')]);
$router->get('/evaluations/create', 'EvaluationController@create', [AuthMiddleware::class, new PermissionMiddleware('evaluation.create')]);
$router->post('/evaluations', 'EvaluationController@store', [AuthMiddleware::class, new PermissionMiddleware('evaluation.create')]);
$router->post('/evaluations/{id}/calculate', 'EvaluationController@calculate', [AuthMiddleware::class, new PermissionMiddleware('evaluation.calculate')]);
$router->get('/evaluations/{id}', 'EvaluationController@show', [AuthMiddleware::class, new PermissionMiddleware('evaluation.view')]);

// ============================================================
// Analysis
// ============================================================

$router->get('/analysis/statistics', 'AnalysisController@statistics', [AuthMiddleware::class, new PermissionMiddleware('analysis.statistics')]);
$router->get('/analysis/ahp', 'AnalysisController@ahp', [AuthMiddleware::class, new PermissionMiddleware('analysis.ahp')]);
$router->post('/analysis/ahp', 'AnalysisController@calculateAhp', [AuthMiddleware::class, new PermissionMiddleware('analysis.ahp')]);
$router->get('/analysis/ranking', 'AnalysisController@ranking', [AuthMiddleware::class, new PermissionMiddleware('ranking.view')]);
$router->get('/analysis/dashboard-data', 'DashboardController@getChartData', [AuthMiddleware::class]);

// ============================================================
// Reports
// ============================================================

$router->get('/reports', 'ReportController@index', [AuthMiddleware::class, new PermissionMiddleware('report.view')]);
$router->post('/reports/export', 'ReportController@export', [AuthMiddleware::class, new PermissionMiddleware('report.export')]);
$router->get('/reports/download/{id}', 'ReportController@download', [AuthMiddleware::class, new PermissionMiddleware('report.export')]);

// ============================================================
// Audit Log
// ============================================================

$router->get('/audit', 'AuditController@index', [AuthMiddleware::class, new PermissionMiddleware('audit.view')]);

// ============================================================
// Settings
// ============================================================

$router->get('/settings', 'SettingController@index', [AuthMiddleware::class, new PermissionMiddleware('settings.view')]);
$router->post('/settings', 'SettingController@update', [AuthMiddleware::class, new PermissionMiddleware('settings.update')]);