-- ============================================================
-- COMBINED DATABASE SCRIPT
-- Database: kypcbhvj_manager_student (or your custom name)
-- Version: 1.0.0
--
-- This file is the single SQL source of truth (schema + seed).
-- Just import this file in phpMyAdmin.
--
-- Default admin: admin / 123456
-- (bcrypt hash for 123456 is pre-baked; no install.php step needed)
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+07:00";

-- ============================================================
-- PART 1: SCHEMA (Tables)
-- ============================================================

-- ============================================================
-- 1. USERS & AUTHENTICATION
-- ============================================================

CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(100) NOT NULL,
    `email` VARCHAR(150) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `full_name` VARCHAR(200) NOT NULL,
    `phone` VARCHAR(20) DEFAULT NULL,
    `avatar` VARCHAR(255) DEFAULT NULL,
    `user_type` ENUM('admin','manager','lecturer','student') NOT NULL DEFAULT 'student',
    `student_code` VARCHAR(50) DEFAULT NULL,
    `lecturer_code` VARCHAR(50) DEFAULT NULL,
    `faculty_id` INT UNSIGNED DEFAULT NULL,
    `department_id` INT UNSIGNED DEFAULT NULL,
    `class_name` VARCHAR(100) DEFAULT NULL,
    `position` VARCHAR(100) DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1 COMMENT '1=active, 0=locked',
    `last_login_at` DATETIME DEFAULT NULL,
    `last_login_ip` VARCHAR(45) DEFAULT NULL,
    `failed_login_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `locked_until` DATETIME DEFAULT NULL,
    `must_change_password` TINYINT(1) NOT NULL DEFAULT 0,
    `remember_token` VARCHAR(255) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` DATETIME DEFAULT NULL,
    UNIQUE KEY `uk_users_username` (`username`),
    UNIQUE KEY `uk_users_email` (`email`),
    KEY `idx_users_user_type` (`user_type`),
    KEY `idx_users_status` (`status`),
    KEY `idx_users_faculty` (`faculty_id`),
    KEY `idx_users_department` (`department_id`),
    KEY `idx_users_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `roles` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(50) NOT NULL,
    `display_name` VARCHAR(150) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `is_system` TINYINT(1) NOT NULL DEFAULT 0 COMMENT 'system roles cannot be deleted',
    `sort_order` INT NOT NULL DEFAULT 0,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_roles_name` (`name`),
    KEY `idx_roles_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `permissions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(100) NOT NULL,
    `display_name` VARCHAR(200) NOT NULL,
    `module` VARCHAR(50) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_permissions_name` (`name`),
    KEY `idx_permissions_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `user_roles` (
    `user_id` INT UNSIGNED NOT NULL,
    `role_id` INT UNSIGNED NOT NULL,
    `assigned_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `assigned_by` INT UNSIGNED DEFAULT NULL,
    PRIMARY KEY (`user_id`,`role_id`),
    KEY `idx_user_roles_role` (`role_id`),
    CONSTRAINT `fk_user_roles_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_user_roles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `role_permissions` (
    `role_id` INT UNSIGNED NOT NULL,
    `permission_id` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`role_id`,`permission_id`),
    KEY `idx_role_permissions_permission` (`permission_id`),
    CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `access_tokens` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `token_hash` VARCHAR(255) NOT NULL,
    `token_name` VARCHAR(100) DEFAULT NULL,
    `abilities` TEXT DEFAULT NULL COMMENT 'JSON array',
    `last_used_at` DATETIME DEFAULT NULL,
    `expires_at` DATETIME NOT NULL,
    `revoked_at` DATETIME DEFAULT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(255) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_access_tokens_hash` (`token_hash`),
    KEY `idx_access_tokens_user` (`user_id`),
    KEY `idx_access_tokens_expires` (`expires_at`),
    CONSTRAINT `fk_access_tokens_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `refresh_tokens` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `access_token_id` INT UNSIGNED NOT NULL,
    `token_hash` VARCHAR(255) NOT NULL,
    `expires_at` DATETIME NOT NULL,
    `revoked_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_refresh_tokens_hash` (`token_hash`),
    KEY `idx_refresh_tokens_access` (`access_token_id`),
    CONSTRAINT `fk_refresh_tokens_access` FOREIGN KEY (`access_token_id`) REFERENCES `access_tokens` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `login_logs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT NULL,
    `username` VARCHAR(100) DEFAULT NULL,
    `ip_address` VARCHAR(45) NOT NULL,
    `user_agent` VARCHAR(255) DEFAULT NULL,
    `success` TINYINT(1) NOT NULL,
    `failure_reason` VARCHAR(100) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_login_logs_user` (`user_id`),
    KEY `idx_login_logs_success` (`success`),
    KEY `idx_login_logs_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 2. ORGANIZATION: FACULTIES & DEPARTMENTS
-- ============================================================

CREATE TABLE IF NOT EXISTS `faculties` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(50) NOT NULL,
    `name` VARCHAR(200) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` DATETIME DEFAULT NULL,
    UNIQUE KEY `uk_faculties_code` (`code`),
    KEY `idx_faculties_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `departments` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `faculty_id` INT UNSIGNED NOT NULL,
    `code` VARCHAR(50) NOT NULL,
    `name` VARCHAR(200) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` DATETIME DEFAULT NULL,
    UNIQUE KEY `uk_departments_code` (`code`),
    KEY `idx_departments_faculty` (`faculty_id`),
    KEY `idx_departments_status` (`status`),
    CONSTRAINT `fk_departments_faculty` FOREIGN KEY (`faculty_id`) REFERENCES `faculties` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 3. KPI SYSTEM
-- ============================================================

CREATE TABLE IF NOT EXISTS `kpi_groups` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(50) NOT NULL,
    `name` VARCHAR(200) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `sort_order` INT NOT NULL DEFAULT 0,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` DATETIME DEFAULT NULL,
    UNIQUE KEY `uk_kpi_groups_code` (`code`),
    KEY `idx_kpi_groups_status` (`status`),
    KEY `idx_kpi_groups_deleted_at` (`deleted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `kpis` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `kpi_group_id` INT UNSIGNED NOT NULL,
    `code` VARCHAR(50) NOT NULL,
    `name` VARCHAR(200) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `min_score` DECIMAL(5,2) NOT NULL DEFAULT 1.00,
    `max_score` DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    `score_step` DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    `sort_order` INT NOT NULL DEFAULT 0,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_by` INT UNSIGNED DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` DATETIME DEFAULT NULL,
    UNIQUE KEY `uk_kpis_code` (`code`),
    KEY `idx_kpis_group` (`kpi_group_id`),
    KEY `idx_kpis_status` (`status`),
    KEY `idx_kpis_deleted_at` (`deleted_at`),
    CONSTRAINT `fk_kpis_group` FOREIGN KEY (`kpi_group_id`) REFERENCES `kpi_groups` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_kpis_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `criterion_categories` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `kpi_id` INT UNSIGNED NOT NULL,
    `code` VARCHAR(50) NOT NULL,
    `name` VARCHAR(200) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `sort_order` INT NOT NULL DEFAULT 0,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_criterion_categories_code` (`code`),
    KEY `idx_criterion_categories_kpi` (`kpi_id`),
    CONSTRAINT `fk_criterion_categories_kpi` FOREIGN KEY (`kpi_id`) REFERENCES `kpis` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `criteria` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `kpi_id` INT UNSIGNED NOT NULL,
    `category_id` INT UNSIGNED DEFAULT NULL,
    `code` VARCHAR(50) NOT NULL,
    `name` VARCHAR(200) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `evaluation_type` ENUM('score','rating','yesno','text','number') NOT NULL DEFAULT 'score',
    `weight` DECIMAL(5,2) NOT NULL DEFAULT 0.00 COMMENT 'percentage 0-100',
    `min_score` DECIMAL(5,2) NOT NULL DEFAULT 1.00,
    `max_score` DECIMAL(5,2) NOT NULL DEFAULT 5.00,
    `score_step` DECIMAL(3,2) NOT NULL DEFAULT 1.00,
    `sort_order` INT NOT NULL DEFAULT 0,
    `status` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` DATETIME DEFAULT NULL,
    UNIQUE KEY `uk_criteria_code` (`code`),
    KEY `idx_criteria_kpi` (`kpi_id`),
    KEY `idx_criteria_category` (`category_id`),
    KEY `idx_criteria_status` (`status`),
    KEY `idx_criteria_deleted_at` (`deleted_at`),
    CONSTRAINT `fk_criteria_kpi` FOREIGN KEY (`kpi_id`) REFERENCES `kpis` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_criteria_category` FOREIGN KEY (`category_id`) REFERENCES `criterion_categories` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 4. SURVEY SYSTEM
-- ============================================================

CREATE TABLE IF NOT EXISTS `surveys` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `code` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `kpi_id` INT UNSIGNED DEFAULT NULL,
    `target_type` ENUM('all','student','lecturer','manager','specific') NOT NULL DEFAULT 'all',
    `start_date` DATETIME DEFAULT NULL,
    `end_date` DATETIME DEFAULT NULL,
    `one_response_per_user` TINYINT(1) NOT NULL DEFAULT 1,
    `allow_anonymous` TINYINT(1) NOT NULL DEFAULT 0,
    `status` ENUM('draft','published','closed','archived') NOT NULL DEFAULT 'draft',
    `created_by` INT UNSIGNED NOT NULL,
    `published_at` DATETIME DEFAULT NULL,
    `closed_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` DATETIME DEFAULT NULL,
    UNIQUE KEY `uk_surveys_code` (`code`),
    KEY `idx_surveys_kpi` (`kpi_id`),
    KEY `idx_surveys_status` (`status`),
    KEY `idx_surveys_dates` (`start_date`,`end_date`),
    KEY `idx_surveys_created_by` (`created_by`),
    KEY `idx_surveys_deleted_at` (`deleted_at`),
    CONSTRAINT `fk_surveys_kpi` FOREIGN KEY (`kpi_id`) REFERENCES `kpis` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_surveys_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `survey_questions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `survey_id` INT UNSIGNED NOT NULL,
    `criterion_id` INT UNSIGNED DEFAULT NULL,
    `question_text` TEXT NOT NULL,
    `question_type` ENUM('single_choice','multiple_choice','rating','scale','number','text','textarea') NOT NULL,
    `is_required` TINYINT(1) NOT NULL DEFAULT 1,
    `min_value` DECIMAL(5,2) DEFAULT NULL,
    `max_value` DECIMAL(5,2) DEFAULT NULL,
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_survey_questions_survey` (`survey_id`),
    KEY `idx_survey_questions_criterion` (`criterion_id`),
    KEY `idx_survey_questions_sort` (`sort_order`),
    CONSTRAINT `fk_survey_questions_survey` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_survey_questions_criterion` FOREIGN KEY (`criterion_id`) REFERENCES `criteria` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `survey_options` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `question_id` INT UNSIGNED NOT NULL,
    `option_text` VARCHAR(500) NOT NULL,
    `option_value` DECIMAL(7,2) DEFAULT NULL COMMENT 'numeric value if any',
    `sort_order` INT NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_survey_options_question` (`question_id`),
    KEY `idx_survey_options_sort` (`sort_order`),
    CONSTRAINT `fk_survey_options_question` FOREIGN KEY (`question_id`) REFERENCES `survey_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `survey_targets` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `survey_id` INT UNSIGNED NOT NULL,
    `target_type` ENUM('role','user_type','faculty','department','user') NOT NULL,
    `target_id` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_survey_targets_survey` (`survey_id`),
    KEY `idx_survey_targets_target` (`target_type`,`target_id`),
    CONSTRAINT `fk_survey_targets_survey` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `survey_responses` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `survey_id` INT UNSIGNED NOT NULL,
    `respondent_id` INT UNSIGNED DEFAULT NULL COMMENT 'null if anonymous',
    `respondent_type` VARCHAR(50) DEFAULT NULL,
    `started_at` DATETIME DEFAULT NULL,
    `submitted_at` DATETIME DEFAULT NULL,
    `status` ENUM('in_progress','submitted','cancelled') NOT NULL DEFAULT 'in_progress',
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(255) DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_survey_responses_survey` (`survey_id`),
    KEY `idx_survey_responses_respondent` (`respondent_id`),
    KEY `idx_survey_responses_status` (`status`),
    KEY `idx_survey_responses_submitted` (`submitted_at`),
    CONSTRAINT `fk_survey_responses_survey` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_survey_responses_respondent` FOREIGN KEY (`respondent_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `survey_answers` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `response_id` INT UNSIGNED NOT NULL,
    `question_id` INT UNSIGNED NOT NULL,
    `option_id` INT UNSIGNED DEFAULT NULL,
    `answer_text` TEXT DEFAULT NULL,
    `answer_number` DECIMAL(10,2) DEFAULT NULL,
    `score` DECIMAL(7,2) DEFAULT NULL COMMENT 'computed score for this answer',
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_survey_answers_response` (`response_id`),
    KEY `idx_survey_answers_question` (`question_id`),
    KEY `idx_survey_answers_option` (`option_id`),
    CONSTRAINT `fk_survey_answers_response` FOREIGN KEY (`response_id`) REFERENCES `survey_responses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_survey_answers_question` FOREIGN KEY (`question_id`) REFERENCES `survey_questions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_survey_answers_option` FOREIGN KEY (`option_id`) REFERENCES `survey_options` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 5. EVALUATION
-- ============================================================

CREATE TABLE IF NOT EXISTS `evaluations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `survey_id` INT UNSIGNED DEFAULT NULL,
    `kpi_id` INT UNSIGNED DEFAULT NULL,
    `period` VARCHAR(50) DEFAULT NULL COMMENT 'e.g., 2025-H1, 2025-Q1',
    `target_type` ENUM('student','lecturer','manager','department','faculty','overall') NOT NULL DEFAULT 'overall',
    `target_id` INT UNSIGNED DEFAULT NULL,
    `total_score` DECIMAL(7,2) DEFAULT NULL,
    `normalized_score` DECIMAL(5,2) DEFAULT NULL COMMENT '0-100',
    `classification` VARCHAR(50) DEFAULT NULL COMMENT 'Xuất sắc, Tốt, Khá, Trung bình, Cần cải thiện',
    `calculation_method` ENUM('average','weighted','ahp') NOT NULL DEFAULT 'weighted',
    `calculated_at` DATETIME DEFAULT NULL,
    `status` ENUM('pending','calculated','archived') NOT NULL DEFAULT 'pending',
    `created_by` INT UNSIGNED DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_evaluations_survey` (`survey_id`),
    KEY `idx_evaluations_kpi` (`kpi_id`),
    KEY `idx_evaluations_target` (`target_type`,`target_id`),
    KEY `idx_evaluations_period` (`period`),
    KEY `idx_evaluations_status` (`status`),
    CONSTRAINT `fk_evaluations_survey` FOREIGN KEY (`survey_id`) REFERENCES `surveys` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_evaluations_kpi` FOREIGN KEY (`kpi_id`) REFERENCES `kpis` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `evaluation_scores` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `evaluation_id` INT UNSIGNED NOT NULL,
    `criterion_id` INT UNSIGNED NOT NULL,
    `raw_score` DECIMAL(7,2) DEFAULT NULL COMMENT 'average of valid responses',
    `normalized_score` DECIMAL(5,2) DEFAULT NULL COMMENT '0-100',
    `weight` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    `weighted_score` DECIMAL(7,2) DEFAULT NULL,
    `response_count` INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_evaluation_scores_eval_crit` (`evaluation_id`,`criterion_id`),
    KEY `idx_evaluation_scores_criterion` (`criterion_id`),
    CONSTRAINT `fk_evaluation_scores_evaluation` FOREIGN KEY (`evaluation_id`) REFERENCES `evaluations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_evaluation_scores_criterion` FOREIGN KEY (`criterion_id`) REFERENCES `criteria` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 6. ANALYSIS (AHP)
-- ============================================================

CREATE TABLE IF NOT EXISTS `ahp_matrices` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `kpi_id` INT UNSIGNED DEFAULT NULL,
    `criteria_ids` TEXT NOT NULL COMMENT 'JSON array of criterion ids',
    `matrix_data` LONGTEXT NOT NULL COMMENT 'JSON pairwise matrix',
    `created_by` INT UNSIGNED NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_ahp_matrices_kpi` (`kpi_id`),
    KEY `idx_ahp_matrices_created_by` (`created_by`),
    CONSTRAINT `fk_ahp_matrices_kpi` FOREIGN KEY (`kpi_id`) REFERENCES `kpis` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_ahp_matrices_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ahp_weights` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `matrix_id` INT UNSIGNED NOT NULL,
    `criterion_id` INT UNSIGNED NOT NULL,
    `weight` DECIMAL(7,4) NOT NULL DEFAULT 0.0000,
    `rank` INT NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_ahp_weights_matrix_crit` (`matrix_id`,`criterion_id`),
    KEY `idx_ahp_weights_criterion` (`criterion_id`),
    CONSTRAINT `fk_ahp_weights_matrix` FOREIGN KEY (`matrix_id`) REFERENCES `ahp_matrices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_ahp_weights_criterion` FOREIGN KEY (`criterion_id`) REFERENCES `criteria` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `ahp_consistency` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `matrix_id` INT UNSIGNED NOT NULL,
    `lambda_max` DECIMAL(7,4) NOT NULL DEFAULT 0.0000,
    `consistency_index` DECIMAL(7,4) NOT NULL DEFAULT 0.0000,
    `consistency_ratio` DECIMAL(7,4) NOT NULL DEFAULT 0.0000,
    `random_index` DECIMAL(5,4) NOT NULL DEFAULT 0.0000,
    `is_consistent` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_ahp_consistency_matrix` (`matrix_id`),
    CONSTRAINT `fk_ahp_consistency_matrix` FOREIGN KEY (`matrix_id`) REFERENCES `ahp_matrices` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `analysis_results` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `survey_id` INT UNSIGNED DEFAULT NULL,
    `kpi_id` INT UNSIGNED DEFAULT NULL,
    `period` VARCHAR(50) DEFAULT NULL,
    `result_type` ENUM('statistics','distribution','trend','comparison') NOT NULL DEFAULT 'statistics',
    `result_data` LONGTEXT NOT NULL COMMENT 'JSON data',
    `created_by` INT UNSIGNED DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_analysis_results_survey` (`survey_id`),
    KEY `idx_analysis_results_kpi` (`kpi_id`),
    KEY `idx_analysis_results_type` (`result_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 7. RANKINGS
-- ============================================================

CREATE TABLE IF NOT EXISTS `rankings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `rank_type` ENUM('kpi','criterion','faculty','department','lecturer','student','overall') NOT NULL,
    `period` VARCHAR(50) DEFAULT NULL,
    `kpi_id` INT UNSIGNED DEFAULT NULL,
    `data` LONGTEXT NOT NULL COMMENT 'JSON ranking data',
    `created_by` INT UNSIGNED DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_rankings_type` (`rank_type`),
    KEY `idx_rankings_period` (`period`),
    KEY `idx_rankings_kpi` (`kpi_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- 8. SYSTEM & AUDIT
-- ============================================================

CREATE TABLE IF NOT EXISTS `system_settings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(100) NOT NULL,
    `setting_value` LONGTEXT DEFAULT NULL,
    `setting_group` VARCHAR(50) NOT NULL DEFAULT 'general',
    `description` TEXT DEFAULT NULL,
    `is_public` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_system_settings_key` (`setting_key`),
    KEY `idx_system_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `audit_logs` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED DEFAULT NULL,
    `action` VARCHAR(100) NOT NULL,
    `module` VARCHAR(50) NOT NULL,
    `target_id` INT UNSIGNED DEFAULT NULL,
    `old_data` LONGTEXT DEFAULT NULL COMMENT 'JSON',
    `new_data` LONGTEXT DEFAULT NULL COMMENT 'JSON',
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `user_agent` VARCHAR(255) DEFAULT NULL,
    `description` TEXT DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_audit_logs_user` (`user_id`),
    KEY `idx_audit_logs_action` (`action`),
    KEY `idx_audit_logs_module` (`module`),
    KEY `idx_audit_logs_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `report_exports` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `report_type` ENUM('survey_result','evaluation','ranking','statistics','custom') NOT NULL,
    `format` ENUM('csv','excel','pdf','print') NOT NULL,
    `parameters` LONGTEXT DEFAULT NULL COMMENT 'JSON',
    `file_path` VARCHAR(500) DEFAULT NULL,
    `file_size` INT UNSIGNED DEFAULT NULL,
    `requested_by` INT UNSIGNED NOT NULL,
    `status` ENUM('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
    `error_message` TEXT DEFAULT NULL,
    `expires_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `completed_at` DATETIME DEFAULT NULL,
    KEY `idx_report_exports_type` (`report_type`),
    KEY `idx_report_exports_status` (`status`),
    KEY `idx_report_exports_user` (`requested_by`),
    CONSTRAINT `fk_report_exports_user` FOREIGN KEY (`requested_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `rate_limits` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `key_hash` VARCHAR(128) NOT NULL,
    `action` VARCHAR(50) NOT NULL,
    `ip_address` VARCHAR(45) DEFAULT NULL,
    `attempts` INT UNSIGNED NOT NULL DEFAULT 1,
    `expires_at` DATETIME NOT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_rate_limits_key_action` (`key_hash`,`action`),
    KEY `idx_rate_limits_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `notifications` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NOT NULL,
    `type` VARCHAR(50) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT DEFAULT NULL,
    `data` LONGTEXT DEFAULT NULL COMMENT 'JSON',
    `read_at` DATETIME DEFAULT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_notifications_user` (`user_id`),
    KEY `idx_notifications_read` (`read_at`),
    CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `schema_version` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `version` VARCHAR(20) NOT NULL,
    `description` TEXT DEFAULT NULL,
    `applied_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- PART 2: SEED DATA
-- ============================================================

-- Roles
INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `is_system`, `sort_order`, `status`) VALUES
(1, 'admin', 'Quản trị viên', 'Toàn quyền quản trị hệ thống', 1, 1, 1),
(2, 'manager', 'Quản lý', 'Quản lý và điều hành chung', 1, 2, 1),
(3, 'lecturer', 'Giảng viên', 'Giảng viên trong hệ thống', 1, 3, 1),
(4, 'student', 'Sinh viên', 'Sinh viên tham gia khảo sát', 1, 4, 1);

-- Permissions
INSERT INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
('dashboard.view', 'Xem dashboard', 'dashboard', 'Xem trang dashboard'),
('dashboard.analytics', 'Xem phân tích dashboard', 'dashboard', 'Xem phân tích nâng cao'),
('users.view', 'Xem người dùng', 'users', 'Xem danh sách người dùng'),
('users.create', 'Tạo người dùng', 'users', 'Tạo người dùng mới'),
('users.update', 'Sửa người dùng', 'users', 'Cập nhật thông tin người dùng'),
('users.delete', 'Xóa người dùng', 'users', 'Xóa người dùng'),
('users.reset_password', 'Reset mật khẩu', 'users', 'Đặt lại mật khẩu người dùng'),
('users.lock', 'Khóa/Mở khóa', 'users', 'Khóa hoặc mở khóa tài khoản'),
('roles.view', 'Xem vai trò', 'roles', 'Xem danh sách vai trò'),
('roles.create', 'Tạo vai trò', 'roles', 'Tạo vai trò mới'),
('roles.update', 'Sửa vai trò', 'roles', 'Cập nhật vai trò'),
('roles.delete', 'Xóa vai trò', 'roles', 'Xóa vai trò'),
('permissions.assign', 'Phân quyền', 'roles', 'Phân quyền cho vai trò và người dùng'),
('kpi_group.view', 'Xem nhóm KPI', 'kpi', 'Xem nhóm KPI'),
('kpi_group.create', 'Tạo nhóm KPI', 'kpi', 'Tạo nhóm KPI mới'),
('kpi_group.update', 'Sửa nhóm KPI', 'kpi', 'Cập nhật nhóm KPI'),
('kpi_group.delete', 'Xóa nhóm KPI', 'kpi', 'Xóa nhóm KPI'),
('kpi.view', 'Xem KPI', 'kpi', 'Xem danh sách KPI'),
('kpi.create', 'Tạo KPI', 'kpi', 'Tạo KPI mới'),
('kpi.update', 'Sửa KPI', 'kpi', 'Cập nhật KPI'),
('kpi.delete', 'Xóa KPI', 'kpi', 'Xóa KPI'),
('kpi.publish', 'Publish KPI', 'kpi', 'Xuất bản bộ KPI'),
('criteria.view', 'Xem tiêu chí', 'criteria', 'Xem tiêu chí'),
('criteria.create', 'Tạo tiêu chí', 'criteria', 'Tạo tiêu chí mới'),
('criteria.update', 'Sửa tiêu chí', 'criteria', 'Cập nhật tiêu chí'),
('criteria.delete', 'Xóa tiêu chí', 'criteria', 'Xóa tiêu chí'),
('survey.view', 'Xem khảo sát', 'survey', 'Xem danh sách khảo sát'),
('survey.create', 'Tạo khảo sát', 'survey', 'Tạo khảo sát mới'),
('survey.update', 'Sửa khảo sát', 'survey', 'Cập nhật khảo sát'),
('survey.delete', 'Xóa khảo sát', 'survey', 'Xóa khảo sát'),
('survey.publish', 'Publish khảo sát', 'survey', 'Xuất bản khảo sát'),
('survey.submit', 'Tham gia khảo sát', 'survey', 'Gửi phản hồi khảo sát'),
('survey.view_result', 'Xem kết quả khảo sát', 'survey', 'Xem kết quả khảo sát'),
('evaluation.view', 'Xem đánh giá', 'evaluation', 'Xem kết quả đánh giá'),
('evaluation.create', 'Tạo đánh giá', 'evaluation', 'Tạo đánh giá mới'),
('evaluation.calculate', 'Tính điểm đánh giá', 'evaluation', 'Tính toán điểm đánh giá'),
('analysis.view', 'Xem phân tích', 'analysis', 'Xem phân tích thống kê'),
('analysis.statistics', 'Xem thống kê', 'analysis', 'Xem thống kê'),
('analysis.ahp', 'Xem AHP', 'analysis', 'Xem phân tích AHP'),
('ranking.view', 'Xem xếp hạng', 'ranking', 'Xem bảng xếp hạng'),
('report.view', 'Xem báo cáo', 'report', 'Xem báo cáo'),
('report.export', 'Xuất báo cáo', 'report', 'Xuất báo cáo'),
('settings.view', 'Xem cài đặt', 'settings', 'Xem cài đặt hệ thống'),
('settings.update', 'Cập nhật cài đặt', 'settings', 'Cập nhật cài đặt hệ thống'),
('audit.view', 'Xem audit log', 'audit', 'Xem nhật ký hoạt động'),
('api.access', 'Truy cập API', 'api', 'Truy cập REST API');

-- Role permissions
-- Admin gets ALL permissions
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, id FROM `permissions`;

-- Manager gets most permissions except system settings and audit
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, id FROM `permissions`
WHERE `module` NOT IN ('settings', 'audit');

-- Lecturer permissions
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 3, id FROM `permissions`
WHERE `name` IN (
    'dashboard.view',
    'kpi.view', 'criteria.view',
    'survey.view', 'survey.submit', 'survey.view_result',
    'evaluation.view',
    'analysis.view', 'analysis.statistics', 'analysis.ahp',
    'ranking.view',
    'report.view',
    'api.access'
);

-- Student permissions
INSERT INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 4, id FROM `permissions`
WHERE `name` IN (
    'dashboard.view',
    'survey.view', 'survey.submit',
    'api.access'
);

-- Default admin account
-- Username: admin
-- Password: 123456 (bcrypt pre-hashed, no installer step required)
-- must_change_password = 0 so admin is not forced to change password on first login
INSERT INTO `users` (`id`, `username`, `email`, `password`, `full_name`, `phone`, `user_type`, `position`, `status`, `must_change_password`) VALUES
(1, 'admin', 'admin@manager-student.local', '$2y$10$SWkvwJ/cPj1aexDn4.G4UOAiWFhb3xtu8Xk1ufjvhX2kj4jlY9PIu', 'Quản trị viên hệ thống', '0123456789', 'admin', 'System Administrator', 1, 0);

-- User roles
INSERT INTO `user_roles` (`user_id`, `role_id`) VALUES (1, 1);

-- Faculties
INSERT INTO `faculties` (`id`, `code`, `name`, `description`, `status`) VALUES
(1, 'CNTT', 'Khoa Công nghệ thông tin', 'Khoa Công nghệ thông tin', 1),
(2, 'KT', 'Khoa Kinh tế', 'Khoa Kinh tế và Quản trị', 1),
(3, 'NN', 'Khoa Ngoại ngữ', 'Khoa Ngoại ngữ', 1);

-- Departments
INSERT INTO `departments` (`id`, `faculty_id`, `code`, `name`, `description`, `status`) VALUES
(1, 1, 'CNPM', 'Bộ môn Công nghệ phần mềm', 'Bộ môn Công nghệ phần mềm', 1),
(2, 1, 'KHMT', 'Bộ môn Khoa học máy tính', 'Bộ môn Khoa học máy tính', 1),
(3, 2, 'QTKD', 'Bộ môn Quản trị kinh doanh', 'Bộ môn Quản trị kinh doanh', 1),
(4, 3, 'TA', 'Bộ môn Tiếng Anh', 'Bộ môn Tiếng Anh', 1);

-- KPI Groups
INSERT INTO `kpi_groups` (`id`, `code`, `name`, `description`, `sort_order`, `status`) VALUES
(1, 'CLGD', 'Chất lượng giảng dạy', 'Đánh giá chất lượng giảng dạy của giảng viên', 1, 1),
(2, 'DVSV', 'Dịch vụ sinh viên', 'Đánh giá dịch vụ hỗ trợ sinh viên', 2, 1),
(3, 'CSVC', 'Cơ sở vật chất', 'Đánh giá cơ sở vật chất, thiết bị', 3, 1),
(4, 'CTQL', 'Công tác quản lý', 'Đánh giá công tác quản lý đào tạo', 4, 1),
(5, 'CTDT', 'Chương trình đào tạo', 'Đánh giá chương trình đào tạo', 5, 1);

-- KPIs
INSERT INTO `kpis` (`id`, `kpi_group_id`, `code`, `name`, `description`, `min_score`, `max_score`, `score_step`, `sort_order`, `status`, `created_by`) VALUES
(1, 1, 'KPI_CLGD_GV', 'Đánh giá giảng viên', 'Đánh giá chất lượng giảng viên', 1.00, 5.00, 1.00, 1, 1, 1),
(2, 1, 'KPI_CLGD_MON', 'Đánh giá môn học', 'Đánh giá chất lượng môn học', 1.00, 5.00, 1.00, 2, 1, 1),
(3, 2, 'KPI_DVSV_TU', 'Đánh giá dịch vụ sinh viên', 'Đánh giá tư vấn và hỗ trợ sinh viên', 1.00, 5.00, 1.00, 3, 1, 1),
(4, 3, 'KPI_CSVC_PT', 'Đánh giá cơ sở vật chất', 'Đánh giá phòng học, thiết bị, thư viện', 1.00, 5.00, 1.00, 4, 1, 1),
(5, 4, 'KPI_CTQL_DT', 'Đánh giá công tác quản lý đào tạo', 'Đánh giá công tác tổ chức đào tạo', 1.00, 5.00, 1.00, 5, 1, 1),
(6, 5, 'KPI_CTDT', 'Đánh giá chương trình đào tạo', 'Đánh giá cấu trúc chương trình đào tạo', 1.00, 5.00, 1.00, 6, 1, 1);

-- Criteria for KPI 1 (Đánh giá giảng viên)
INSERT INTO `criteria` (`id`, `kpi_id`, `code`, `name`, `description`, `evaluation_type`, `weight`, `min_score`, `max_score`, `score_step`, `sort_order`, `status`) VALUES
(1, 1, 'ND_MH', 'Nội dung môn học', 'Nội dung giảng dạy có rõ ràng, cập nhật', 'rating', 25.00, 1.00, 5.00, 1.00, 1, 1),
(2, 1, 'KHTD', 'Khả năng truyền đạt', 'Giảng viên truyền đạt dễ hiểu, hấp dẫn', 'rating', 25.00, 1.00, 5.00, 1.00, 2, 1),
(3, 1, 'TLHT', 'Tai liệu học tập', 'Tài liệu đầy đủ, chất lượng', 'rating', 25.00, 1.00, 5.00, 1.00, 3, 1),
(4, 1, 'KHHTSV', 'Hỗ trợ sinh viên', 'Giảng viên hỗ trợ sinh viên nhiệt tình', 'rating', 25.00, 1.00, 5.00, 1.00, 4, 1);

-- Criteria for KPI 2 (Đánh giá môn học)
INSERT INTO `criteria` (`id`, `kpi_id`, `code`, `name`, `description`, `evaluation_type`, `weight`, `min_score`, `max_score`, `score_step`, `sort_order`, `status`) VALUES
(5, 2, 'CTDH', 'Cấu trúc đào tạo', 'Chương trình có cấu trúc logic', 'rating', 30.00, 1.00, 5.00, 1.00, 1, 1),
(6, 2, 'LTUD', 'Liên thực tế', 'Liên hệ thực tế, ứng dụng', 'rating', 35.00, 1.00, 5.00, 1.00, 2, 1),
(7, 2, 'DG_KT', 'Đánh giá kết quả', 'Cách đánh giá kết quả học tập', 'rating', 35.00, 1.00, 5.00, 1.00, 3, 1);

-- Criteria for KPI 3 (Dịch vụ sinh viên)
INSERT INTO `criteria` (`id`, `kpi_id`, `code`, `name`, `description`, `evaluation_type`, `weight`, `min_score`, `max_score`, `score_step`, `sort_order`, `status`) VALUES
(8, 3, 'TV', 'Tư vấn sinh viên', 'Tư vấn học tập, nghề nghiệp', 'rating', 50.00, 1.00, 5.00, 1.00, 1, 1),
(9, 3, 'HD_HK', 'Hoạt động ngoại khóa', 'Các hoạt động ngoại khóa, đoàn thể', 'rating', 50.00, 1.00, 5.00, 1.00, 2, 1);

-- Criteria for KPI 4 (Cơ sở vật chất)
INSERT INTO `criteria` (`id`, `kpi_id`, `code`, `name`, `description`, `evaluation_type`, `weight`, `min_score`, `max_score`, `score_step`, `sort_order`, `status`) VALUES
(10, 4, 'PH', 'Phòng học', 'Phòng học sạch sẽ, đủ ánh sáng', 'rating', 40.00, 1.00, 5.00, 1.00, 1, 1),
(11, 4, 'TB', 'Thiết bị', 'Thiết bị đầy đủ, hiện đại', 'rating', 35.00, 1.00, 5.00, 1.00, 2, 1),
(13, 4, 'TV_CSVC', 'Thư viện', 'Thư viện đủ sách, không gian đọc', 'rating', 25.00, 1.00, 5.00, 1.00, 3, 1);

-- Criteria for KPI 5 (Công tác quản lý)
INSERT INTO `criteria` (`id`, `kpi_id`, `code`, `name`, `description`, `evaluation_type`, `weight`, `min_score`, `max_score`, `score_step`, `sort_order`, `status`) VALUES
(14, 5, 'TKB', 'Thời khóa biểu', 'TKB khoa học, hợp lý', 'rating', 50.00, 1.00, 5.00, 1.00, 1, 1),
(15, 5, 'TT', 'Thông tin', 'Thông tin được cập nhật kịp thời', 'rating', 50.00, 1.00, 5.00, 1.00, 2, 1);

-- Criteria for KPI 6 (Chương trình đào tạo)
INSERT INTO `criteria` (`id`, `kpi_id`, `code`, `name`, `description`, `evaluation_type`, `weight`, `min_score`, `max_score`, `score_step`, `sort_order`, `status`) VALUES
(16, 6, 'CT', 'Cấu trúc CT', 'CT có cấu trúc hợp lý', 'rating', 50.00, 1.00, 5.00, 1.00, 1, 1),
(17, 6, 'TD', 'Tính hiện đại', 'CT cập nhật, hiện đại', 'rating', 50.00, 1.00, 5.00, 1.00, 2, 1);

-- System settings
INSERT INTO `system_settings` (`setting_key`, `setting_value`, `setting_group`, `description`, `is_public`) VALUES
('app.name', 'Manager Student Quality Evaluation', 'app', 'Tên hệ thống', 1),
('app.version', '1.0.0', 'app', 'Phiên bản', 1),
('app.timezone', 'Asia/Ho_Chi_Minh', 'app', 'Múi giờ', 0),
('app.locale', 'vi', 'app', 'Ngôn ngữ mặc định', 1),
('app.items_per_page', '20', 'app', 'Số record trên mỗi trang', 0),
('security.session_lifetime', '1800', 'security', 'Session timeout (giây) - 30 phút', 0),
('security.password_min_length', '6', 'security', 'Độ dài tối thiểu của password', 0),
('security.max_login_attempts', '5', 'security', 'Số lần đăng nhập sai tối đa', 0),
('security.lockout_duration', '900', 'security', 'Thời gian khóa tài khoản (giây)', 0),
('security.rate_limit_login', '10', 'security', 'Rate limit đăng nhập mỗi phút', 0),
('security.rate_limit_api', '60', 'security', 'Rate limit API mỗi phút', 0),
('security.token_lifetime', '3600', 'security', 'Token API tồn tại (giây)', 0),
('security.refresh_token_lifetime', '2592000', 'security', 'Refresh token tồn tại (giây) - 30 ngày', 0),
('security.csrf_token_lifetime', '7200', 'security', 'CSRF token tồn tại (giây)', 0),
('score.classification_thresholds', '{"excellent": 90, "good": 80, "fair": 65, "average": 50, "poor": 0}', 'score', 'Ngưỡng xếp loại', 0),
('score.default_min', '1', 'score', 'Điểm tối thiểu mặc định', 0),
('score.default_max', '5', 'score', 'Điểm tối đa mặc định', 0),
('score.default_step', '1', 'score', 'Bước điểm mặc định', 0),
('ahp.random_index', '{"1":0,"2":0,"3":0.58,"4":0.9,"5":1.12,"6":1.24,"7":1.32,"8":1.41,"9":1.45,"10":1.49,"11":1.51,"12":1.48,"13":1.56,"14":1.57,"15":1.59}', 'ahp', 'Random Index cho AHP', 0),
('ahp.max_consistency_ratio', '0.1', 'ahp', 'CR tối đa cho phép', 0),
('ui.theme', 'light', 'ui', 'Theme mặc định', 1),
('ui.items_per_page', '20', 'ui', 'Số record mỗi trang', 0),
('seo.site_title', 'Manager Student Quality Evaluation', 'seo', 'Tiêu đề site', 1),
('seo.site_description', 'Hệ thống quản lý đánh giá chất lượng đào tạo', 'seo', 'Mô tả site', 1),
('seo.site_keywords', 'quality, evaluation, kpi, manager, student', 'seo', 'Từ khóa', 1);

-- Sample survey
INSERT INTO `surveys` (`id`, `code`, `title`, `description`, `kpi_id`, `target_type`, `start_date`, `end_date`, `one_response_per_user`, `allow_anonymous`, `status`, `created_by`, `published_at`) VALUES
(1, 'KS_CLGD_2025', 'Khảo sát chất lượng giảng dạy 2025', 'Khảo sát đánh giá chất lượng giảng dạy năm 2025', 1, 'all', '2025-01-01 00:00:00', '2025-12-31 23:59:59', 1, 0, 'published', 1, '2025-01-01 00:00:00');

-- Sample questions for survey 1
INSERT INTO `survey_questions` (`id`, `survey_id`, `criterion_id`, `question_text`, `question_type`, `is_required`, `min_value`, `max_value`, `sort_order`) VALUES
(1, 1, 1, 'Nội dung giảng dạy có rõ ràng, cập nhật không?', 'scale', 1, 1.00, 5.00, 1),
(2, 1, 2, 'Giảng viên có khả năng truyền đạt tốt không?', 'scale', 1, 1.00, 5.00, 2),
(3, 1, 3, 'Tai liệu học tập đầy đủ và chất lượng?', 'scale', 1, 1.00, 5.00, 3),
(4, 1, 4, 'Giảng viên có hỗ trợ sinh viên nhiệt tình không?', 'scale', 1, 1.00, 5.00, 4),
(5, 1, NULL, 'Ý kiến thêm của bạn về chất lượng giảng dạy?', 'textarea', 0, NULL, NULL, 5);

-- Sample options for scale questions
INSERT INTO `survey_options` (`question_id`, `option_text`, `option_value`, `sort_order`) VALUES
(1, 'Rất không đồng ý', 1.00, 1),
(1, 'Không đồng ý', 2.00, 2),
(1, 'Trung bình', 3.00, 3),
(1, 'Đồng ý', 4.00, 4),
(1, 'Rất đồng ý', 5.00, 5),
(2, 'Rất không đồng ý', 1.00, 1),
(2, 'Không đồng ý', 2.00, 2),
(2, 'Trung bình', 3.00, 3),
(2, 'Đồng ý', 4.00, 4),
(2, 'Rất đồng ý', 5.00, 5),
(3, 'Rất không đồng ý', 1.00, 1),
(3, 'Không đồng ý', 2.00, 2),
(3, 'Trung bình', 3.00, 3),
(3, 'Đồng ý', 4.00, 4),
(3, 'Rất đồng ý', 5.00, 5),
(4, 'Rất không đồng ý', 1.00, 1),
(4, 'Không đồng ý', 2.00, 2),
(4, 'Trung bình', 3.00, 3),
(4, 'Đồng ý', 4.00, 4),
(4, 'Rất đồng ý', 5.00, 5);

-- Schema version
INSERT INTO `schema_version` (`version`, `description`) VALUES
('1.0.0', 'Initial schema + seed - Manager Student Quality Evaluation System');

SET FOREIGN_KEY_CHECKS = 1;

-- ============================================================
-- DONE!
--
-- Sau khi import xong file này trong phpMyAdmin, hệ thống đã sẵn sàng.
-- Đăng nhập với tài khoản admin mặc định:
--   Username: admin
--   Password: 123456
--
-- Lưu ý: Đổi mật khẩu admin ngay sau khi đăng nhập lần đầu.
-- ============================================================
