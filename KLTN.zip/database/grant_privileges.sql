-- ============================================================
-- GRANT ALL PRIVILEGES - fix "Access denied for user ... to database"
-- ============================================================
--
-- Nếu bạn thấy lỗi:
--   SQLSTATE[42000] [1044] Access denied for user 'kypcbhvj_manager_student'@'localhost'
--   to database 'kypcbhvj_manager_student'
--
-- Hãy chạy lệnh dưới (đăng nhập MySQL bằng user root hoặc user có quyền GRANT):
--
--   GRANT ALL PRIVILEGES ON kypcbhvj_manager_student.* TO 'kypcbhvj_manager_student'@'localhost';
--   FLUSH PRIVILEGES;
--
-- Hoặc trên shared hosting thường user = database, và user đã có toàn quyền.
-- Khi đó vấn đề là do DATABASE trong config chưa đúng tên. Hãy kiểm tra trong cPanel:
--   Databases > MySQL Databases
--   và đảm bảo user có "All Privileges" trên đúng database.
--
-- Trên cPanel > MySQL Databases:
--   1. Tạo database: kypcbhvj_manager_student
--   2. Tạo user: kypcbhvj_manager_student
--   3. Add user to database -> ALL PRIVILEGES
-- ============================================================

GRANT ALL PRIVILEGES ON `kypcbhvj_manager_student`.* TO 'kypcbhvj_manager_student'@'localhost';
FLUSH PRIVILEGES;
