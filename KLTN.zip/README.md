# Manager Student Quality Evaluation System

Hệ thống quản lý đánh giá chất lượng đào tạo - Production-ready PHP 8.0+ + MySQL.

## Tính năng chính

- **Quản lý KPI**: Tạo nhóm KPI, KPI, tiêu chí với trọng số
- **Khảo sát**: Tạo khảo sát với 7 loại câu hỏi, thu thập phản hồi
- **Đánh giá chất lượng**: Tính điểm tự động với phương pháp có trọng số
- **Phân tích AHP**: Phân tích thứ bậc với kiểm tra tính nhất quán
- **Thống kê & Xếp hạng**: Mean, Median, Std Dev, phân bố, ranking
- **Dashboard**: Biểu đồ trực quan với Chart.js
- **Báo cáo**: Xuất CSV, Excel, PDF
- **REST API v1**: Cho Android app và tích hợp
- **RBAC**: Phân quyền chi tiết theo 4 vai trò
- **Bảo mật**: CSRF, XSS, SQL injection prevention, rate limiting, audit log

## Yêu cầu hệ thống

- PHP 8.0 trở lên
- MySQL 5.7+ / MariaDB 10.3+
- Apache với mod_rewrite (cPanel)
- 100MB disk space
- Extensions: PDO, PDO_MySQL, mbstring, openssl, json

## Cài đặt

### 1. Upload source lên hosting

Upload toàn bộ source thẳng vào `public_html/`, không đặt trong thư mục `manager-student/`. Sau khi giải nén, `index.php` và `.htaccess` cần nằm ngay trong `public_html/`. Trang đăng nhập sẽ ở `https://your-domain.com/login`.

### 2. Tạo database

Tạo database trên cPanel với tên: `kypcbhvj_manager_student`

### 3. Import SQL

Truy cập phpMyAdmin → **Import** → chọn file **`database/sql.sql`** → **Go**.

> File `sql.sql` đã gộp sẵn schema (tạo bảng) + seed (dữ liệu mẫu). Bạn chỉ cần import 1 file duy nhất này, không cần chạy thêm bước cài đặt nào khác.

### 4. Cấu hình database

Sửa file `config/database.php`:
```php
return [
    'database' => 'kypcbhvj_manager_student',
    'username' => 'your_db_user',
    'password' => 'your_db_password',
    // ...
];
```

Hoặc dùng biến môi trường:
- `DB_NAME`
- `DB_USER`
- `DB_PASS`
- `APP_URL`
- `APP_SECRET`

### 5. Đăng nhập

Mở trình duyệt và truy cập `https://your-domain.com/login`.

Tài khoản admin mặc định:
- **Username**: `admin`
- **Password**: `123456`

> Lưu ý: Nên đổi mật khẩu admin ngay sau khi đăng nhập lần đầu.

### 6. Cấu hình Apache

Đảm bảo `.htaccess` hoạt động:
- `mod_rewrite` enabled
- `AllowOverride All` trong VirtualHost

### 7. Bật HTTPS (khuyến nghị)

Mở file `.htaccess` và uncomment phần force HTTPS.

## Cấu trúc thư mục

```
public_html/
├── api/                  # REST API endpoints
├── config/               # Database, app config
├── controllers/          # Web controllers
├── core/                 # Core classes (Auth, Database, Router, etc.)
├── database/             # SQL schema + seed
│   └── sql.sql           # File SQL duy nhất
├── middleware/           # Auth, Permission middleware
├── repositories/         # Data access layer
├── routes/               # Web routes
├── services/             # Business logic
├── storage/              # Logs, exports, cache
└── views/                # PHP templates
```

## Truy cập

- **Web Dashboard**: `https://your-domain.com/`
- **API Base**: `https://your-domain.com/api/v1/`
- **API Health**: `https://your-domain.com/api/v1/health`
- **API Login**: `POST /api/v1/auth/login`

## Phát triển

### Quy tắc code

1. PHP 8.0+ syntax (typed properties, match, null safe operator)
2. PDO Prepared Statements 100%
3. Transaction cho thao tác đa bảng
4. Validate server-side mọi input
5. Escape output chống XSS
6. CSRF token cho form POST/PUT/DELETE
7. Không hard-code credentials

### Debug

Đặt `APP_DEBUG=true` để hiển thị errors (chỉ trong development).

## Bảo mật

- Password hash với `password_hash()` (BCRYPT)
- CSRF token cho mọi form
- Session HttpOnly, SameSite, Secure
- Rate limiting cho login, API
- SQL injection prevention với PDO
- XSS prevention với htmlspecialchars
- Audit log cho mọi action quan trọng
- Token-based API auth với refresh token

## License

Copyright © 2025. All rights reserved.


## Nâng cấp giao diện (dashboard)

- Layout dashboard sáng: sidebar trắng có thẻ người dùng, ô tìm menu, nhóm menu đóng/mở; header có ô tìm nhanh chức năng (phím `/`), nút tạo nhanh, toàn màn hình.
- Ẩn toàn bộ thanh cuộn (vẫn cuộn bình thường bằng chuột, cảm ứng, bàn phím).
- Responsive: ≥1025px sidebar cố định (có thể thu gọn, nhớ trạng thái); ≤1024px sidebar là ngăn kéo; hỗ trợ tai thỏ (safe-area), `100dvh`, chống zoom iOS, in ấn.
- SEO: `title`/`description` theo trang (`$pageTitle`, `$pageDescription`), canonical, Open Graph, Twitter Card, JSON-LD, `robots` cấu hình qua setting `seo.robots` (mặc định `noindex,nofollow` cho khu vực quản trị), landmark ngữ nghĩa, script `defer`.
- Sửa lỗi dashboard: biến `API_URL` không tồn tại ở JavaScript khiến 3 biểu đồ (phân bố, xu hướng, hoàn thành) không vẽ; nay dùng `chartDataUrl` do PHP truyền sang.
