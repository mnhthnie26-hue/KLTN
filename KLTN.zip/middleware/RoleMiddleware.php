<?php
/**
 * RoleMiddleware - Requires specific roles
 */

declare(strict_types=1);

class RoleMiddleware
{
    private array $allowedRoles;

    public function __construct(array $allowedRoles = [])
    {
        $this->allowedRoles = $allowedRoles;
    }

    public function handle(Request $request, Response $response): bool
    {
        if (!Auth::check()) {
            if ($request->isAjax() || str_starts_with($request->path(), '/api/')) {
                $response->error('Unauthenticated', null, 401)->send();
                return false;
            }
            $response->redirect(url('login'))->send();
            return false;
        }

        // Admin (user_type='admin') has access to every role-gated route.
        if (Auth::isAdmin()) {
            return true;
        }

        if (empty($this->allowedRoles)) {
            return true;
        }

        if (!Auth::hasAnyRole($this->allowedRoles)) {
            if ($request->isAjax() || str_starts_with($request->path(), '/api/')) {
                $response->error('Forbidden - insufficient role', null, 403)->send();
                return false;
            }

            http_response_code(403);
            echo View::render('errors/403', [], 'app');
            exit;
        }

        return true;
    }
}