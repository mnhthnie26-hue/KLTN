<?php
/**
 * PermissionMiddleware - Requires specific permissions
 */

declare(strict_types=1);

class PermissionMiddleware
{
    private array $requiredPermissions;
    private string $mode; // 'all' or 'any'

    public function __construct(string|array $permissions, string $mode = 'all')
    {
        $this->requiredPermissions = is_array($permissions) ? $permissions : [$permissions];
        $this->mode = $mode;
    }

    public function handle(Request $request, Response $response): bool
    {
        if (!Auth::check()) {
            if ($request->isAjax() || str_starts_with($request->path(), '/api/')) {
                $response->error('Unauthenticated', null, 401)->send();
                return false;
            }
            $response->redirect(url('login'))->send();
            return false;
        }

        // Admin (user_type='admin') has access to everything - bypass permission checks.
        if (Auth::isAdmin()) {
            return true;
        }

        $hasPermission = false;
        if ($this->mode === 'all') {
            // Every required permission must be granted.
            $granted = true;
            foreach ($this->requiredPermissions as $perm) {
                if (!Auth::hasPermission($perm)) {
                    $granted = false;
                    break;
                }
            }
            $hasPermission = empty($this->requiredPermissions) || $granted;
        } else { // 'any'
            foreach ($this->requiredPermissions as $perm) {
                if (Auth::hasPermission($perm)) {
                    $hasPermission = true;
                    break;
                }
            }
            if (empty($this->requiredPermissions)) $hasPermission = true;
        }

        if (!$hasPermission) {
            if ($request->isAjax() || str_starts_with($request->path(), '/api/')) {
                $response->error('Forbidden - insufficient permission', ['required' => $this->requiredPermissions], 403)->send();
                return false;
            }

            http_response_code(403);
            if (file_exists(VIEWS_PATH . '/errors/403.php')) {
                include VIEWS_PATH . '/errors/403.php';
            } else {
                echo '<h1>403 Forbidden</h1>';
            }
            exit;
        }

        return true;
    }
}