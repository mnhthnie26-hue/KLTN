<?php
/**
 * ApiAuthMiddleware - Bearer Token authentication for API
 */

declare(strict_types=1);

class ApiAuthMiddleware
{
    public function handle(Request $request, Response $response): bool
    {
        $token = $request->bearerToken();
        if (!$token) {
            $response->error('Missing access token', null, 401)->send();
            return false;
        }

        try {
            $db = Database::getInstance();
            $row = $db->fetchOne(
                'SELECT t.id AS token_id, t.user_id, t.expires_at, t.last_used_at,
                        u.username, u.email, u.full_name, u.user_type,
                        u.status, u.deleted_at
                 FROM access_tokens t
                 INNER JOIN users u ON t.user_id = u.id
                 WHERE t.token_hash = ? AND t.revoked_at IS NULL
                 LIMIT 1',
                [Security::hashToken($token)]
            );

            if (!$row) {
                $response->error('Invalid access token', null, 401)->send();
                return false;
            }

            if (strtotime((string)$row['expires_at']) < time()) {
                $response->error('Access token expired', null, 401)->send();
                return false;
            }

            if ((int)$row['status'] !== 1 || $row['deleted_at'] !== null) {
                $response->error('User account disabled', null, 401)->send();
                return false;
            }

            // Update last_used_at (best effort, swallow errors).
            try {
                $db->update('access_tokens', [
                    'last_used_at' => date('Y-m-d H:i:s'),
                ], 'id = :id', ['id' => (int)$row['token_id']]);
            } catch (Throwable $e) {
                ErrorLog::warning('[ApiAuth] last_used_at update failed', [
                    'tid' => (int)($row['token_id'] ?? 0),
                ], $e);
            }

            // Hydrate the full user (with roles and permissions).
            $user = Auth::loadUserWithRoles((int)$row['user_id']);
            if (!$user) {
                $response->error('User not found', null, 401)->send();
                return false;
            }

            // Tag every log line with this API user.
            ErrorLog::setUser((int)$user['id']);

            // Set on Request for downstream usage.
            $request->setApiUser($user);
            $GLOBALS['__api_user'] = $user;

            return true;
        } catch (Throwable $e) {
            ErrorLog::error('[ApiAuth] auth failed', [], $e);
            $response->error('Authentication failed', null, 401)->send();
            return false;
        }
    }
}