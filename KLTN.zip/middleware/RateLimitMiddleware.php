<?php
/**
 * RateLimitMiddleware - Rate limiting for sensitive endpoints
 */

declare(strict_types=1);

class RateLimitMiddleware
{
    private string $action;
    private int $maxAttempts;
    private int $decaySeconds;

    public function __construct(string $action, int $maxAttempts = 60, int $decaySeconds = 60)
    {
        $this->action = $action;
        $this->maxAttempts = $maxAttempts;
        $this->decaySeconds = $decaySeconds;
    }

    public function handle(Request $request, Response $response): bool
    {
        $key = $this->resolveKey($request);
        $keyHash = hash('sha256', $key);

        try {
            $db = Database::getInstance();
            $now = date('Y-m-d H:i:s');
            $expiresAt = date('Y-m-d H:i:s', time() + $this->decaySeconds);

            // Cleanup expired
            $db->query("DELETE FROM rate_limits WHERE expires_at < ?", [$now]);

            // Get current
            $row = $db->fetchOne(
                'SELECT * FROM rate_limits WHERE key_hash = ? AND action = ?',
                [$keyHash, $this->action]
            );

            if ($row) {
                if ((int)$row['attempts'] >= $this->maxAttempts) {
                    $remaining = strtotime($row['expires_at']) - time();
                    if ($request->isAjax() || str_starts_with($request->path(), '/api/')) {
                        $response->error('Too many requests', ['retry_after' => $remaining], 429)->send();
                    } else {
                        http_response_code(429);
                        if (file_exists(VIEWS_PATH . '/errors/429.php')) {
                            include VIEWS_PATH . '/errors/429.php';
                        } else {
                            echo '<h1>429 Too Many Requests</h1>';
                        }
                    }
                    return false;
                }

                $db->update('rate_limits', [
                    'attempts' => (int)$row['attempts'] + 1,
                    'expires_at' => $expiresAt,
                ], 'id = :id', ['id' => $row['id']]);
            } else {
                $db->insert('rate_limits', [
                    'key_hash' => $keyHash,
                    'action' => $this->action,
                    'ip_address' => $request->ip(),
                    'attempts' => 1,
                    'expires_at' => $expiresAt,
                ]);
            }

            return true;
        } catch (Throwable $e) {
            // Don't block user if rate limit fails - but always emit a log line.
            ErrorLog::warning('[RateLimitMiddleware] check failed (allowing request)', [
                'key' => $keyHash, 'action' => $action,
            ], $e);
            return true;
        }
    }

    private function resolveKey(Request $request): string
    {
        $ip = $request->ip();
        $user = Auth::user();
        $userId = $user['id'] ?? 'guest';
        return $this->action . '|' . $ip . '|' . $userId;
    }
}