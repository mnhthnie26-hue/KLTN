<?php
/**
 * AuthMiddleware - Requires user authentication
 */

declare(strict_types=1);

class AuthMiddleware
{
    public function handle(Request $request, Response $response): bool
    {
        Session::start();

        if (!Auth::check()) {
            if ($request->isAjax() || str_starts_with($request->path(), '/api/')) {
                $response->error('Unauthenticated', null, 401)->send();
                return false;
            }

            Session::set('redirect_after_login', $request->uri());
            $response->redirect(url('login'))->send();
            return false;
        }

        return true;
    }
}